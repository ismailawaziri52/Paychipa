import { SEO } from "../components/SEO";
import { Link } from "react-router-dom";
import { Shield, Lock, Eye, Fingerprint, Bell, CheckCircle, AlertTriangle, Server, Key, Smartphone } from "lucide-react";

export function SecurityPage() {
  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Security - Paychipa | Bank-Grade Security & Data Protection"
        description="Your security is our priority. Learn about Paychipa's bank-grade encryption, biometric authentication, fraud protection, and compliance measures."
        keywords="security, bank security, data encryption, fraud protection, secure banking, cybersecurity"
        type="website"
      />
      {/* Hero Section */}
      <div className="relative py-20 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full mb-6">
            <Shield className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-gray-300">Bank-Grade Security</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            Security & Trust
          </h1>
          
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Your money and data are protected with military-grade encryption and industry-leading security measures.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Our Commitment */}
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Shield className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h2 className="text-2xl text-white mb-3">Our Security Commitment</h2>
              <p className="text-gray-300 leading-relaxed">
                At Paychipa, security is our top priority. We employ multiple layers of protection to ensure your money and personal information remain safe at all times. Our security infrastructure meets international standards and is regularly audited by independent security experts.
              </p>
            </div>
          </div>
        </div>

        {/* Security Features Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Lock className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">256-Bit SSL Encryption</h3>
            <p className="text-gray-300">
              All data transmitted between your device and our servers is encrypted using 256-bit SSL encryption, the same standard used by major banks worldwide.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Fingerprint className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">Biometric Authentication</h3>
            <p className="text-gray-300">
              Secure your account with fingerprint or face recognition. Your biometric data never leaves your device and is never stored on our servers.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Key className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">Two-Factor Authentication</h3>
            <p className="text-gray-300">
              Add an extra layer of protection with SMS or authenticator app-based 2FA. Every login and transaction requires additional verification.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Server className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">Secure Data Centers</h3>
            <p className="text-gray-300">
              Your data is stored in world-class data centers with 24/7 physical security, redundant power systems, and advanced fire suppression.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Eye className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">Real-Time Fraud Monitoring</h3>
            <p className="text-gray-300">
              Our AI-powered systems monitor transactions 24/7 to detect and prevent fraudulent activity before it affects your account.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center mb-4">
              <Bell className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl text-white mb-3">Instant Alerts</h3>
            <p className="text-gray-300">
              Receive immediate notifications for every transaction, login attempt, and account change via push notification, SMS, or email.
            </p>
          </div>
        </div>

        {/* Data Protection */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Lock className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">How We Protect Your Data</h2>
          </div>
          
          <div className="space-y-6 ml-16">
            <div>
              <h3 className="text-lg text-white mb-3">Encryption at Rest</h3>
              <p className="text-gray-300">
                All sensitive data stored in our databases is encrypted using AES-256 encryption. This includes your personal information, financial data, and transaction history.
              </p>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Encryption in Transit</h3>
              <p className="text-gray-300">
                Every communication between your device and our servers uses TLS 1.3 protocol, ensuring that no one can intercept or read your data during transmission.
              </p>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Secure Card Storage</h3>
              <p className="text-gray-300">
                We never store your full card details. All payment card information is tokenized and stored securely by our PCI-DSS compliant payment processors (Stripe and Flutterwave).
              </p>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">PIN Protection</h3>
              <p className="text-gray-300">
                Your transaction PIN is encrypted using one-way hashing with salt. This means even our employees cannot access your PIN—only you know it.
              </p>
            </div>
          </div>
        </div>

        {/* Fraud Prevention */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Eye className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">Fraud Detection & Prevention</h2>
          </div>
          
          <div className="space-y-4 ml-16 text-gray-300">
            <p>Our multi-layered fraud prevention system includes:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Machine learning algorithms that analyze transaction patterns</li>
              <li>Device fingerprinting to detect suspicious devices</li>
              <li>Geolocation verification for unusual location changes</li>
              <li>Velocity checks to prevent rapid-fire transactions</li>
              <li>Blacklist screening against known fraudulent accounts</li>
              <li>Manual review by our security team for high-risk transactions</li>
            </ul>
            
            <div className="bg-green-500/10 border border-green-400/30 rounded-xl p-4 mt-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm">
                  If we detect suspicious activity on your account, we'll immediately freeze affected transactions and contact you for verification.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Compliance */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Regulatory Compliance</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>We comply with all applicable Nigerian and international security standards:</p>
            
            <div className="grid gap-4 mt-4">
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-white mb-1">PCI-DSS Compliance</h3>
                    <p className="text-sm">Payment Card Industry Data Security Standard certified for handling card data</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-white mb-1">NDPR Compliance</h3>
                    <p className="text-sm">Nigeria Data Protection Regulation compliant for data privacy</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-white mb-1">AML/KYC Standards</h3>
                    <p className="text-sm">Anti-Money Laundering and Know Your Customer procedures as per CBN guidelines</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-white mb-1">ISO 27001</h3>
                    <p className="text-sm">Information security management system certification (in progress)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Account Security Tips */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Smartphone className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">Keep Your Account Safe</h2>
          </div>
          
          <div className="space-y-6 ml-16">
            <div>
              <h3 className="text-lg text-white mb-3">Do's ✓</h3>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Enable biometric authentication on your device</li>
                <li>Use a strong, unique password that you don't use elsewhere</li>
                <li>Enable two-factor authentication (2FA)</li>
                <li>Keep your app updated to the latest version</li>
                <li>Review your transaction history regularly</li>
                <li>Log out when using public or shared devices</li>
                <li>Report suspicious activity immediately</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Don'ts ✗</h3>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Never share your PIN, password, or OTP with anyone</li>
                <li>Don't click on suspicious links in emails or SMS</li>
                <li>Never install apps from untrusted sources</li>
                <li>Don't save your password in browsers on public devices</li>
                <li>Never respond to unsolicited calls asking for account details</li>
                <li>Don't use public Wi-Fi for financial transactions without a VPN</li>
              </ul>
            </div>
          </div>
        </div>

        {/* What We Don't Do */}
        <div className="bg-red-500/10 backdrop-blur-xl border border-red-400/30 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-red-500/20 border border-red-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="h-6 w-6 text-red-400" />
            </div>
            <h2 className="text-2xl text-white">What Paychipa Will Never Do</h2>
          </div>
          
          <div className="space-y-3 ml-16 text-gray-300">
            <div className="flex items-start gap-2">
              <span className="text-red-400 mt-1">✗</span>
              <p>We will NEVER call, email, or text you asking for your password, PIN, or OTP</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-400 mt-1">✗</span>
              <p>We will NEVER ask you to transfer money to a "safe account"</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-400 mt-1">✗</span>
              <p>We will NEVER send you a link asking you to verify your account urgently</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-400 mt-1">✗</span>
              <p>We will NEVER ask for remote access to your device</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-400 mt-1">✗</span>
              <p>We will NEVER ask you to download apps from unofficial sources</p>
            </div>
          </div>

          <div className="mt-6 ml-16 bg-black/30 border border-red-400/20 rounded-xl p-4">
            <p className="text-sm text-gray-300">
              <strong className="text-white">Important:</strong> If you receive any communication claiming to be from Paychipa asking for sensitive information, do not respond. Report it immediately to <a href="mailto:security@paychipa.com" className="text-purple-400 hover:text-purple-300">security@paychipa.com</a>
            </p>
          </div>
        </div>

        {/* Report Security Issues */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Report Security Issues</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>
              If you discover a security vulnerability or suspect fraud, please contact us immediately:
            </p>
            
            <div className="grid md:grid-cols-2 gap-4 mt-4">
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Security Vulnerabilities</h3>
                <p className="text-sm mb-2">Found a bug or security issue?</p>
                <a href="mailto:security@paychipa.com" className="text-purple-400 hover:text-purple-300 text-sm">
                  security@paychipa.com
                </a>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Fraud & Suspicious Activity</h3>
                <p className="text-sm mb-2">Report unauthorized transactions</p>
                <a href="mailto:fraud@paychipa.com" className="text-purple-400 hover:text-purple-300 text-sm">
                  fraud@paychipa.com
                </a>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4 mt-4">
              <h3 className="text-white mb-2">24/7 Emergency Support</h3>
              <p className="text-sm mb-2">For urgent security issues, call us anytime:</p>
              <a href="tel:+2349012345678" className="text-purple-400 hover:text-purple-300">
                +234 901 234 5678
              </a>
            </div>
          </div>
        </div>

        {/* Insurance Note */}
        <div className="bg-yellow-500/10 backdrop-blur-xl border border-yellow-400/30 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 border border-yellow-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="h-6 w-6 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-2xl text-white mb-3">Important Notice</h2>
              <p className="text-gray-300 leading-relaxed">
                Paychipa is currently in pre-launch phase. We are working towards obtaining full licensing from the Central Bank of Nigeria (CBN). At this time, deposits are not insured by the Nigeria Deposit Insurance Corporation (NDIC). We are partnering with Stripe and Flutterwave, both of which are fully licensed and regulated payment service providers, to ensure your transactions are secure and compliant.
              </p>
            </div>
          </div>
        </div>

        {/* Contact */}
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
          <h2 className="text-2xl text-white mb-4">Security Questions?</h2>
          <p className="text-gray-300 mb-4">
            Have questions about our security practices? We're here to help.
          </p>
          <div className="space-y-2 text-gray-300">
            <p><strong className="text-white">Security Team:</strong> <a href="mailto:security@paychipa.com" className="text-purple-400 hover:text-purple-300">security@paychipa.com</a></p>
            <p><strong className="text-white">General Inquiries:</strong> <a href="mailto:info@paychipa.com" className="text-purple-400 hover:text-purple-300">info@paychipa.com</a></p>
            <p><strong className="text-white">Phone:</strong> <a href="tel:+2349012345678" className="text-purple-400 hover:text-purple-300">+234 901 234 5678</a></p>
          </div>
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
