import { SEO } from "../components/SEO";
import { useState, useEffect } from "react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Users, Mail, TrendingUp, Download, RefreshCw, Eye, Calendar } from "lucide-react";
import { projectId, publicAnonKey } from "../utils/supabase/info";
import { toast } from "sonner@2.0.3";

export function AdminDashboardPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [waitlistData, setWaitlistData] = useState<any[]>([]);
  const [contactData, setContactData] = useState<any[]>([]);
  const [analyticsData, setAnalyticsData] = useState<any>(null);

  const fetchWaitlist = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-8addffcd/export/all`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }

      const data = await response.json();
      setWaitlistData(data.data.waitlist || []);
      setContactData(data.data.contacts || []);
      
      // Get analytics summary
      const analyticsResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-8addffcd/analytics/summary`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (analyticsResponse.ok) {
        const analyticsData = await analyticsResponse.json();
        setAnalyticsData(analyticsData);
      }

      toast.success('Data refreshed successfully');
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to fetch data');
    } finally {
      setIsLoading(false);
    }
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      toast.error('No data to export');
      return;
    }

    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(item => 
      Object.values(item).map(val => 
        typeof val === 'string' && val.includes(',') ? `"${val}"` : val
      ).join(',')
    );

    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success(`Exported ${data.length} records`);
  };

  useEffect(() => {
    fetchWaitlist();
  }, []);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Admin Dashboard - Paychipa"
        description="Paychipa admin dashboard for managing waitlist and contact submissions"
      />

      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl text-white mb-2">
                Admin Dashboard
              </h1>
              <p className="text-gray-400">
                Manage waitlist signups and contact submissions
              </p>
            </div>
            
            <Button 
              onClick={fetchWaitlist}
              disabled={isLoading}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh Data
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-purple-900/40 to-purple-800/40 border-purple-500/20 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">Waitlist Signups</p>
                <p className="text-3xl text-white">{waitlistData.length}</p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-400" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-pink-900/40 to-pink-800/40 border-pink-500/20 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">Contact Messages</p>
                <p className="text-3xl text-white">{contactData.length}</p>
              </div>
              <div className="w-12 h-12 bg-pink-500/20 rounded-xl flex items-center justify-center">
                <Mail className="w-6 h-6 text-pink-400" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/40 to-blue-800/40 border-blue-500/20 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">Total Engagement</p>
                <p className="text-3xl text-white">{analyticsData?.summary?.engagement || 0}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-400" />
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Data Tables */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <Tabs defaultValue="waitlist" className="space-y-6">
          <TabsList className="bg-white/5 border border-white/10">
            <TabsTrigger value="waitlist" className="data-[state=active]:bg-purple-600">
              Waitlist ({waitlistData.length})
            </TabsTrigger>
            <TabsTrigger value="contacts" className="data-[state=active]:bg-purple-600">
              Contacts ({contactData.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="waitlist" className="space-y-4">
            <div className="flex justify-end">
              <Button 
                onClick={() => exportToCSV(waitlistData, 'paychipa-waitlist')}
                variant="outline"
                className="border-white/20 hover:bg-white/5"
              >
                <Download className="w-4 h-4 mr-2" />
                Export to CSV
              </Button>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-white/5 border-b border-white/10">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm text-gray-300">Name</th>
                      <th className="px-6 py-4 text-left text-sm text-gray-300">Email</th>
                      <th className="px-6 py-4 text-left text-sm text-gray-300">Phone</th>
                      <th className="px-6 py-4 text-left text-sm text-gray-300">Date Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {waitlistData.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                          No waitlist signups yet
                        </td>
                      </tr>
                    ) : (
                      waitlistData.map((item, index) => (
                        <tr key={index} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4 text-white">{item.name || 'N/A'}</td>
                          <td className="px-6 py-4 text-gray-300">{item.email}</td>
                          <td className="px-6 py-4 text-gray-300">{item.phone || 'N/A'}</td>
                          <td className="px-6 py-4 text-gray-400 text-sm">
                            {new Date(item.joinedAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="contacts" className="space-y-4">
            <div className="flex justify-end">
              <Button 
                onClick={() => exportToCSV(contactData, 'paychipa-contacts')}
                variant="outline"
                className="border-white/20 hover:bg-white/5"
              >
                <Download className="w-4 h-4 mr-2" />
                Export to CSV
              </Button>
            </div>

            <div className="space-y-4">
              {contactData.length === 0 ? (
                <div className="bg-white/5 border border-white/10 rounded-xl p-12 text-center">
                  <p className="text-gray-500">No contact messages yet</p>
                </div>
              ) : (
                contactData.map((item, index) => (
                  <Card key={index} className="bg-white/5 border-white/10 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-white mb-1">{item.name}</h3>
                        <p className="text-sm text-gray-400">{item.email}</p>
                        {item.phone && (
                          <p className="text-sm text-gray-400">{item.phone}</p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">
                          {new Date(item.submittedAt).toLocaleDateString()}
                        </p>
                        <p className="text-xs text-gray-600">
                          {new Date(item.submittedAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm text-purple-400 mb-1">Subject:</p>
                      <p className="text-white">{item.subject}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-purple-400 mb-1">Message:</p>
                      <p className="text-gray-300">{item.message}</p>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
