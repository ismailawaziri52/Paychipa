import { Hero } from "../components/Hero";
import { Features } from "../components/Features";
import { ProductShowcase } from "../components/ProductShowcase";
import { Testimonials } from "../components/Testimonials";
import { DownloadApp } from "../components/DownloadApp";

export function HomePage() {
  return (
    <div className="bg-black">
      <Hero />
      <Features />
      <ProductShowcase />
      <Testimonials />
      <DownloadApp />
    </div>
  );
}
