import { SEO } from "../components/SEO";
import { useParams, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Calendar, Clock, ArrowLeft, Share2, Twitter, Facebook, Linkedin } from "lucide-react";

export function BlogPostPage() {
  const { slug } = useParams();

  const posts: Record<string, any> = {
    "introducing-paychipa": {
      title: "Introducing Paychipa: The Future of Digital Banking in Nigeria",
      content: `
        <p>We're thrilled to announce Paychipa - a revolutionary digital banking platform designed specifically for everyday Nigerians. After months of development and planning, we're excited to share our vision for making banking simple, accessible, and truly powerful.</p>

        <h2>Why Paychipa?</h2>
        <p>Nigeria's financial landscape is evolving rapidly, but many Nigerians still struggle with accessing basic banking services. Traditional banks often come with hidden fees, long queues, and complex processes. We believe banking should be different - it should be instant, transparent, and designed around your needs.</p>

        <h2>Our Mission</h2>
        <p>At Paychipa, our mission is simple: make payments simple and accessible for everyone in Nigeria. We're building a comprehensive platform that combines the best of traditional banking with cutting-edge fintech innovation.</p>

        <h2>What We're Building</h2>
        <p>Paychipa isn't just another banking app. We're creating an entire ecosystem of financial services:</p>

        <ul>
          <li><strong>Free POS Terminals:</strong> Get your business accepting card payments instantly with our free POS terminals delivered within 48 hours.</li>
          <li><strong>Virtual & Physical Cards:</strong> Mastercard debit cards that work everywhere, online and offline, with instant issuance.</li>
          <li><strong>Instant Transfers:</strong> Send money to any Nigerian bank account in seconds, completely free.</li>
          <li><strong>Bill Payments:</strong> Pay for airtime, data, electricity, and subscriptions all in one place.</li>
          <li><strong>High-Yield Savings:</strong> Earn up to 15% annual interest on your savings with daily interest calculations.</li>
          <li><strong>Quick Loans:</strong> Access instant loans when you need them, with transparent terms and competitive rates.</li>
          <li><strong>Escrow Services:</strong> Buy and sell with confidence using our secure escrow system.</li>
        </ul>

        <h2>Powered by the Best</h2>
        <p>We've partnered with Stripe and Flutterwave - two of the world's leading payment processors - to ensure your transactions are always secure, fast, and reliable. Our infrastructure is built on enterprise-grade technology that handles millions of transactions daily.</p>

        <h2>Security First</h2>
        <p>Your security is our top priority. We use bank-level 256-bit encryption, two-factor authentication, biometric login, and real-time fraud detection to keep your money safe. Every transaction is monitored and protected.</p>

        <h2>Coming in 2026</h2>
        <p>We're working hard to launch Paychipa in 2026. We're currently in the pre-launch phase, building our platform, securing partnerships, and preparing for regulatory approvals. Join our waitlist today to be among the first to experience the future of banking in Nigeria.</p>

        <h2>Join Our Journey</h2>
        <p>This is just the beginning. We're building Paychipa for you - for every Nigerian who wants better banking, simpler payments, and financial services that actually work. Join our waitlist, follow us on social media, and be part of this exciting journey.</p>

        <p>Together, we're not just changing banking - we're making it work for everyone.</p>
      `,
      author: "Paychipa Team",
      date: "January 15, 2025",
      readTime: "5 min read",
      category: "Company News",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=600&fit=crop"
    },
    "choosing-pos-terminal": {
      title: "How to Choose the Right POS Terminal for Your Business",
      content: `
        <p>Selecting the right POS terminal is crucial for your business success. Whether you're running a small shop, restaurant, or service business, having the right payment solution can make all the difference in customer satisfaction and operational efficiency.</p>

        <h2>Understanding POS Terminals</h2>
        <p>A Point of Sale (POS) terminal is more than just a card reader - it's the hub of your business transactions. Modern POS terminals accept multiple payment methods, generate receipts, track sales, and provide valuable business insights.</p>

        <h2>Key Features to Consider</h2>

        <h3>1. Payment Method Support</h3>
        <p>Your POS terminal should accept various payment methods including:</p>
        <ul>
          <li>Chip cards (EMV)</li>
          <li>Contactless payments (NFC)</li>
          <li>Magnetic stripe cards</li>
          <li>Mobile wallets (Apple Pay, Google Pay)</li>
          <li>QR code payments</li>
        </ul>

        <h3>2. Connectivity Options</h3>
        <p>Consider how the terminal connects to process payments:</p>
        <ul>
          <li><strong>WiFi:</strong> Best for fixed locations with reliable internet</li>
          <li><strong>3G/4G:</strong> Ideal for mobile businesses or areas with poor WiFi</li>
          <li><strong>Bluetooth:</strong> Great for pairing with tablets or smartphones</li>
          <li><strong>Ethernet:</strong> Most stable for high-volume businesses</li>
        </ul>

        <h3>3. Battery Life</h3>
        <p>If you're on the go, battery life is crucial. Look for terminals that can handle at least 200-300 transactions on a single charge. Paychipa's POS terminals offer all-day battery life for mobile businesses.</p>

        <h3>4. Receipt Options</h3>
        <p>Modern customers appreciate choices:</p>
        <ul>
          <li>Thermal receipt printing</li>
          <li>SMS receipts</li>
          <li>Email receipts</li>
          <li>Digital receipts via app</li>
        </ul>

        <h2>Business Type Considerations</h2>

        <h3>Retail Stores</h3>
        <p>For retail, you need a terminal that's fast, reliable, and can handle high transaction volumes. Countertop terminals with WiFi or ethernet connectivity work best.</p>

        <h3>Restaurants & Cafes</h3>
        <p>Portable terminals that servers can bring to tables enhance customer experience. Look for devices with good battery life and easy tip entry.</p>

        <h3>Service Businesses</h3>
        <p>If you visit clients, a compact mobile terminal with 4G connectivity is essential. It should be lightweight and fit in your work bag.</p>

        <h3>Market Vendors</h3>
        <p>Battery life and 4G connectivity are non-negotiable. You need a rugged device that can handle outdoor conditions.</p>

        <h2>Cost Considerations</h2>

        <h3>Upfront Costs</h3>
        <p>Traditional POS terminals can cost anywhere from ₦50,000 to ₦200,000. However, with Paychipa, you get a free POS terminal when you sign up - saving you significant upfront investment.</p>

        <h3>Transaction Fees</h3>
        <p>Beyond the hardware, consider:</p>
        <ul>
          <li>Per-transaction fees (typically 1-3%)</li>
          <li>Monthly service fees</li>
          <li>Chargeback fees</li>
          <li>Settlement times (how quickly you get your money)</li>
        </ul>

        <h2>Why Choose Paychipa POS?</h2>

        <p>Paychipa offers the complete package:</p>
        <ul>
          <li><strong>Free Terminal:</strong> No upfront costs - we deliver your POS terminal free</li>
          <li><strong>Competitive Rates:</strong> Transparent pricing with no hidden fees</li>
          <li><strong>Fast Settlement:</strong> Get your money within 24 hours</li>
          <li><strong>All Payment Methods:</strong> Accept cards, contactless, and mobile payments</li>
          <li><strong>Built-in Receipt Printer:</strong> Thermal printing included</li>
          <li><strong>Long Battery Life:</strong> All-day operation on a single charge</li>
          <li><strong>Real-time Reporting:</strong> Track sales via our mobile app</li>
          <li><strong>24/7 Support:</strong> We're always here to help</li>
        </ul>

        <h2>Getting Started</h2>
        <p>Ready to get your free POS terminal? Join our waitlist today. When we launch in 2026, you'll be among the first businesses to receive your terminal and start accepting payments the modern way.</p>

        <p>The right POS terminal can transform your business - making transactions faster, customers happier, and giving you insights to grow. Choose wisely, choose Paychipa.</p>
      `,
      author: "Product Team",
      date: "January 10, 2025",
      readTime: "8 min read",
      category: "Business Tips",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=600&fit=crop"
    },
    "save-money-digital-banking": {
      title: "5 Ways to Save Money with Digital Banking",
      content: `
        <p>Digital banking isn't just convenient - it can actually help you save significant money. Here's how switching from traditional banks to digital platforms like Paychipa can put more money in your pocket.</p>

        <h2>1. Eliminate Monthly Maintenance Fees</h2>
        <p>Traditional banks often charge monthly maintenance fees ranging from ₦500 to ₦5,000 just for keeping your account open. Over a year, that's up to ₦60,000 gone!</p>

        <p><strong>Paychipa Solution:</strong> Zero monthly maintenance fees. Your money stays yours, period.</p>

        <h2>2. Free Transfers</h2>
        <p>Banks typically charge ₦50-₦100 per transfer. If you make just 10 transfers a month, that's ₦6,000-₦12,000 annually.</p>

        <p><strong>Paychipa Solution:</strong> Completely free transfers to any Nigerian bank account. Send money as often as you need, no charges.</p>

        <h2>3. Higher Interest on Savings</h2>
        <p>Most traditional savings accounts offer 2-4% annual interest - barely keeping up with inflation.</p>

        <p><strong>Paychipa Solution:</strong> Earn up to 15% annual interest on your savings. On a ₦100,000 balance, that's ₦15,000 vs just ₦4,000 with traditional banks.</p>

        <h2>4. No Card Maintenance Fees</h2>
        <p>Many banks charge annual card maintenance fees of ₦1,000-₦3,000 per card.</p>

        <p><strong>Paychipa Solution:</strong> Free virtual and physical Mastercard debit cards with no annual fees. Order multiple cards at no extra cost.</p>

        <h2>5. Lower Transaction Costs</h2>
        <p>ATM withdrawals at other banks, international transactions, and bill payment fees all add up.</p>

        <p><strong>Paychipa Solution:</strong> Reduced transaction costs across the board, with many services completely free.</p>

        <h2>The Math: Annual Savings</h2>
        <p>Let's calculate what an average Nigerian could save by switching to Paychipa:</p>
        
        <ul>
          <li>Monthly maintenance fees saved: ₦24,000</li>
          <li>Transfer fees saved (20 transfers/month): ₦24,000</li>
          <li>Extra interest earned (₦200,000 average balance): ₦22,000</li>
          <li>Card fees saved: ₦2,000</li>
          <li>Other transaction fees: ₦8,000</li>
        </ul>

        <p><strong>Total Annual Savings: ₦80,000+</strong></p>

        <h2>Additional Benefits</h2>

        <h3>Real-time Notifications</h3>
        <p>Avoid overdraft fees by getting instant notifications for every transaction. Stay in control of your spending.</p>

        <h3>Automated Savings</h3>
        <p>Set up automatic savings transfers and watch your money grow without thinking about it.</p>

        <h3>Better Budgeting Tools</h3>
        <p>Digital banks provide spending insights and budgeting tools that help you identify where you can save more.</p>

        <h2>Making the Switch</h2>
        <p>Switching to digital banking with Paychipa is simple:</p>
        <ol>
          <li>Join our waitlist (takes 2 minutes)</li>
          <li>Download the app when we launch in 2026</li>
          <li>Open your account (takes 5 minutes)</li>
          <li>Start saving money immediately</li>
        </ol>

        <h2>Your Money, Your Future</h2>
        <p>Every naira counts. The money you save by switching to digital banking can go toward your goals - emergency fund, investment, business, or that dream vacation.</p>

        <p>Don't let traditional banks keep taking your hard-earned money. Join the digital banking revolution with Paychipa and start saving today.</p>
      `,
      author: "Finance Team",
      date: "January 8, 2025",
      readTime: "6 min read",
      category: "Personal Finance",
      image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=1200&h=600&fit=crop"
    }
  };

  const post = slug ? posts[slug] : null;

  if (!post) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl text-white mb-4">Post Not Found</h1>
          <Link to="/blog">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full">
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title={`${post.title} - Paychipa Blog`}
        description={post.content.substring(0, 160).replace(/<[^>]*>/g, '')}
        type="article"
        author={post.author}
        publishedTime={new Date(post.date).toISOString()}
        image={post.image}
        keywords={`paychipa blog, ${post.category.toLowerCase()}, digital banking, fintech nigeria`}
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/blog" className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Blog
          </Link>

          <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 rounded-full border border-purple-400/30 mb-6">
            <span className="text-xs text-purple-300">{post.category}</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            {post.title}
          </h1>

          <div className="flex items-center gap-6 text-gray-400 mb-8">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {post.date}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {post.readTime}
            </div>
            <div className="text-gray-300">By {post.author}</div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-full">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-full">
              <Twitter className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-full">
              <Facebook className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-full">
              <Linkedin className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Featured Image */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 mb-16">
        <div className="rounded-3xl overflow-hidden border border-white/10">
          <img src={post.image} alt={post.title} className="w-full h-[400px] object-cover" />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div 
          className="prose prose-invert prose-lg max-w-none
            prose-headings:text-white prose-headings:font-semibold
            prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-6
            prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4
            prose-p:text-gray-300 prose-p:leading-relaxed prose-p:mb-6
            prose-ul:text-gray-300 prose-ul:my-6
            prose-li:my-2
            prose-strong:text-white
            prose-a:text-purple-400 prose-a:no-underline hover:prose-a:text-purple-300"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        {/* CTA */}
        <div className="mt-16 bg-gradient-to-r from-purple-900/20 to-pink-900/20 backdrop-blur-xl rounded-3xl p-8 border border-white/10 text-center">
          <h3 className="text-2xl text-white mb-4">Ready to join Paychipa?</h3>
          <p className="text-gray-300 mb-6">Be among the first to experience the future of banking in Nigeria.</p>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8">
            Join Waitlist
          </Button>
        </div>
      </div>
    </div>
  );
}
