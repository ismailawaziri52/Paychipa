import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, Smartphone, Shield, Zap, CreditCard, BarChart3, Headphones } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";
import posImage from "figma:asset/fb38f2d0070b359e13036a84d99c5f1a42758171.png";

export function POSTerminalsPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Free POS Terminals - Paychipa | Accept Card Payments for Your Business"
        description="Get a free POS terminal for your business. Accept card payments, contactless payments, and transfers. 24-hour delivery, 1.5% transaction fee, instant settlement."
        keywords="free pos terminal nigeria, pos machine, card payment, contactless payment, merchant services, payment terminal"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
                <CreditCard className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-purple-300">POS Terminals</span>
              </div>
              
              <h1 className="text-5xl sm:text-6xl text-white">
                Accept payments
                <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                  anywhere, anytime
                </span>
              </h1>
              
              <p className="text-xl text-gray-300 leading-relaxed">
                Get a free POS terminal and start accepting card payments from your customers. Zero setup costs, instant settlements, and 24/7 support.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => setIsWaitlistOpen(true)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
                >
                  Request Free POS
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <Button 
                  size="lg" 
                  className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
                >
                  Learn More
                </Button>
              </div>

              <div className="flex flex-wrap gap-4 pt-4">
                <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                  <Check className="h-5 w-5 text-green-400" />
                  <span className="text-sm text-gray-300">Free terminal</span>
                </div>
                <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                  <Check className="h-5 w-5 text-green-400" />
                  <span className="text-sm text-gray-300">Instant settlement</span>
                </div>
                <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                  <Check className="h-5 w-5 text-green-400" />
                  <span className="text-sm text-gray-300">1.5% transaction fee</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>
              <img
                src={posImage}
                alt="POS Terminal"
                className="relative rounded-3xl shadow-2xl shadow-purple-500/30 w-full h-auto border border-white/10"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Why choose Paychipa POS?
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Everything you need to accept payments and grow your business
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">All Card Types Supported</h3>
              <p className="text-gray-400 mb-4">
                Accept Mastercard, Visa, Verve, and all major Nigerian bank cards.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Contactless payments
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Chip & PIN
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Magnetic stripe
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Instant Settlements</h3>
              <p className="text-gray-400 mb-4">
                Get your money immediately. No waiting periods, no delays.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Real-time deposits
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  24/7 availability
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  No settlement fees
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/50">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Bank-Level Security</h3>
              <p className="text-gray-400 mb-4">
                Your transactions are protected with end-to-end encryption and fraud detection.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  PCI-DSS certified
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Fraud monitoring
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Encrypted transactions
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-gray-600 to-slate-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-gray-500/50">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Real-Time Tracking</h3>
              <p className="text-gray-400 mb-4">
                Monitor all transactions from your phone with detailed analytics and reports.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Live dashboard
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Sales reports
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Export to Excel
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-rose-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/50">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Mobile Companion App</h3>
              <p className="text-gray-400 mb-4">
                Manage your POS terminals, track sales, and print receipts from your phone.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  iOS & Android
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Digital receipts
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Remote management
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all group">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/50">
                <Headphones className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">24/7 Support</h3>
              <p className="text-gray-400 mb-4">
                Get help anytime with our dedicated support team and free maintenance.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Phone & chat support
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Free repairs
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Free replacement
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl text-white mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-xl text-gray-400">
              No hidden fees. Pay only when you make a sale.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl">
            <div className="text-center mb-8">
              <div className="text-5xl text-white mb-2">1.5%</div>
              <p className="text-gray-400">per successful transaction</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">POS Terminal</span>
                <span className="text-white">Free</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Setup Fee</span>
                <span className="text-white">₦0</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Monthly Fee</span>
                <span className="text-white">₦0</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Settlement</span>
                <span className="text-white">Instant & Free</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Support & Maintenance</span>
                <span className="text-white">Free</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-6">
              <h4 className="text-white mb-3">Example Calculation</h4>
              <p className="text-sm text-gray-400 mb-3">
                For a ₦10,000 transaction:
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Transaction amount</span>
                  <span className="text-white">₦10,000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Fee (1.5%)</span>
                  <span className="text-white">₦150</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-purple-500/20">
                  <span className="text-white">You receive</span>
                  <span className="text-white">₦9,850</span>
                </div>
              </div>
            </div>

            <div className="text-center mt-8">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
              >
                Request Your Free POS
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Get started in 3 easy steps
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="text-xl text-white mb-3">Request Your POS</h3>
              <p className="text-gray-400">
                Fill out a simple form and tell us about your business
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="text-xl text-white mb-3">Receive & Activate</h3>
              <p className="text-gray-400">
                Get your POS terminal delivered free within 48 hours
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-emerald-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/50">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="text-xl text-white mb-3">Start Accepting Payments</h3>
              <p className="text-gray-400">
                Begin taking card payments and watch your business grow
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Ready to start accepting payments?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Get your free POS terminal today and start growing your business
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8 shadow-xl shadow-purple-500/50"
          >
            Request Free POS Terminal
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
