import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Briefcase, Heart, Zap, Users, TrendingUp } from "lucide-react";

export function CareersPage() {
  const futureRoles = [
    {
      title: "Engineering",
      description: "Backend engineers, mobile developers, and DevOps specialists to build our payment infrastructure"
    },
    {
      title: "Product & Design",
      description: "Product managers and designers to create beautiful, intuitive experiences"
    },
    {
      title: "Business Development",
      description: "Sales and partnership professionals to drive merchant adoption"
    },
    {
      title: "Customer Success",
      description: "Support specialists to ensure exceptional customer experiences"
    },
    {
      title: "Legal & Compliance",
      description: "Compliance officers to navigate regulatory requirements"
    },
    {
      title: "Marketing",
      description: "Marketing professionals to build our brand and go-to-market strategy"
    }
  ];

  const values = [
    {
      icon: Heart,
      title: "Customer First",
      description: "Every decision we make starts with how it impacts our customers"
    },
    {
      icon: Zap,
      title: "Move Fast",
      description: "We ship quickly, learn fast, and iterate constantly"
    },
    {
      icon: Users,
      title: "Better Together",
      description: "We win as a team and celebrate each other's successes"
    },
    {
      icon: TrendingUp,
      title: "Own It",
      description: "We take ownership of our work and deliver exceptional results"
    }
  ];

  const benefits = [
    "Competitive salary and equity packages",
    "Health insurance for you and your family",
    "Flexible remote work options",
    "Learning and development budget",
    "Latest tech equipment",
    "Unlimited paid time off",
    "Team retreats and social events",
    "Parental leave"
  ];

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Careers - Paychipa | Join Our Team & Build the Future"
        description="Join Paychipa and help build the future of digital banking in Nigeria. We're hiring engineers, designers, product managers, and more. Launching 2025."
        keywords="paychipa careers, fintech jobs nigeria, startup jobs abuja, engineering jobs nigeria, join paychipa"
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full border border-white/10">
              <Briefcase className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">Pre-Launch Phase</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Building the future of
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                payments in Nigeria
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              We're preparing for our 2026 launch. While we're not currently hiring, we'd love to hear from talented individuals who want to be part of our journey.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
                onClick={() => document.getElementById('future-opportunities')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Join Our Talent Network
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Values */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Our Values
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-all group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <value.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl text-white mb-3">{value.title}</h3>
                <p className="text-gray-400">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Benefits */}
      <div className="py-24 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Benefits & Perks
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              We take care of our team so they can do their best work
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10 flex items-center gap-3"
              >
                <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex-shrink-0"></div>
                <p className="text-gray-300">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Future Opportunities */}
      <div id="future-opportunities" className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-500/10 backdrop-blur-sm rounded-full border border-yellow-500/20 mb-6">
              <span className="text-sm text-yellow-400">Not Currently Hiring</span>
            </div>
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Future Opportunities
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              As we prepare for our 2026 launch, we'll be building teams across these areas
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {futureRoles.map((role, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-all group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-4">
                  <Briefcase className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl text-white mb-3">{role.title}</h3>
                <p className="text-gray-400">{role.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-24 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Want to be part of our journey?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join our talent network and be the first to know when we start hiring. Send us your resume and we'll reach out when opportunities open up.
          </p>
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
          >
            Join Talent Network
          </Button>
        </div>
      </div>
    </div>
  );
}
