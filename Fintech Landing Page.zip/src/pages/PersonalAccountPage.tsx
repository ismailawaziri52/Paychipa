import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, Zap, Shield, CreditCard, PiggyBank, TrendingUp, Smartphone, Send, Receipt, Wallet } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";

export function PersonalAccountPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Personal Account - Paychipa | Your Digital Banking Solution"
        description="Open a free Paychipa personal account and enjoy instant transfers, virtual cards, savings up to 15%, bill payments, and more. 100% digital, no paperwork required."
        keywords="personal account nigeria, digital banking, virtual card, instant transfer, bill payment, mobile banking nigeria"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
              <Smartphone className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-purple-300">Personal Banking</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Banking made simple
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                for everyday life
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Open a free account in minutes. Send money, pay bills, save automatically, and manage your finances all in one place.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
              >
                Open Free Account
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
              >
                Learn More
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">No minimum balance</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Free transfers</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Instant setup</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Everything you need for modern banking
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              All your financial needs in one powerful app
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Send className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Instant Transfers</h3>
              <p className="text-gray-400 mb-4">
                Send money to any Nigerian bank account instantly for free. No charges, no delays.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Free to all banks
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Instant delivery
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  24/7 availability
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Receipt className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Bill Payments</h3>
              <p className="text-gray-400 mb-4">
                Pay for airtime, data, electricity, cable TV, and more with instant confirmation.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  All billers supported
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Instant processing
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Payment history
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/50">
                <PiggyBank className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Automated Savings</h3>
              <p className="text-gray-400 mb-4">
                Save automatically with our smart savings plans and earn up to 15% interest.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Up to 15% interest
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Auto-save daily
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Goal tracking
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-gray-600 to-slate-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-gray-500/50">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Virtual & Physical Cards</h3>
              <p className="text-gray-400 mb-4">
                Get instant virtual cards and physical debit cards for all your spending needs.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Instant virtual cards
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Free delivery
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Global acceptance
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-rose-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/50">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Instant Loans</h3>
              <p className="text-gray-400 mb-4">
                Access quick loans up to ₦5M with low interest rates and flexible repayment.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Up to ₦5M
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Instant approval
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Low interest
                </li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/50">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Budget Tracking</h3>
              <p className="text-gray-400 mb-4">
                Track your spending, set budgets, and get insights into your financial habits.
              </p>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Smart analytics
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Spending insights
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-400" />
                  Budget alerts
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758519290801-c07424a5142a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYnVzaW5lc3MlMjBwZXJzb24lMjBoYXBweXxlbnwxfHx8fDE3NjExNDY5ODN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Happy African person using mobile banking"
                  className="rounded-2xl w-full h-auto"
                />
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl text-white">
                Built for modern Nigerians
              </h2>
              <p className="text-xl text-gray-400">
                Experience banking the way it should be - simple, fast, and reliable
              </p>
              
              <div className="space-y-4">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/50">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Lightning Fast</h3>
                      <p className="text-gray-400">
                        Open an account in 3 minutes. Send money in seconds. No paperwork, no delays.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/50">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Totally Secure</h3>
                      <p className="text-gray-400">
                        Bank-level encryption, biometric login, and instant fraud alerts keep your money safe.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-500/50">
                      <Smartphone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Always Available</h3>
                      <p className="text-gray-400">
                        Access your account 24/7 from anywhere. Get help anytime with our support team.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Get started in minutes
            </h2>
            <p className="text-xl text-gray-400">
              Opening your account is quick and easy
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="text-xl text-white mb-3">Download App</h3>
              <p className="text-gray-400">
                Get the Paychipa app from App Store or Google Play
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="text-xl text-white mb-3">Create Account</h3>
              <p className="text-gray-400">
                Sign up with your phone number and verify your identity
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-emerald-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/50">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="text-xl text-white mb-3">Start Banking</h3>
              <p className="text-gray-400">
                Fund your account and start enjoying all our features
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Ready to experience better banking?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of Nigerians already banking smarter with Paychipa
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8 shadow-xl shadow-purple-500/50"
          >
            Open Your Free Account
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
