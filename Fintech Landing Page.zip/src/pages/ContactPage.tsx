import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Mail, Phone, MapPin, MessageSquare, Clock, Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../utils/supabase/info";

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Call Supabase backend to save contact form
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-8addffcd/contact`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify(formData)
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to send message');
      }

      toast.success(data.message);
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error(error.message || 'Failed to send message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-50/30">
      <SEO 
        title="Contact Us - Paychipa | Get in Touch with Our Support Team"
        description="Have questions? Contact Paychipa support team. Email: hello@paychipa.com, Phone: +234 901 234 5678. Based in Abuja, Nigeria. We're here to help 24/7."
        keywords="contact paychipa, paychipa support, customer service, help, contact us"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-white to-blue-50 pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-300/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-300/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full">
              <MessageSquare className="w-4 h-4 text-[#2D1E36]" />
              <span className="text-sm text-[#2D1E36]">Get in Touch</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-[#2D1E36]">
              We'd love to
              <span className="block bg-gradient-to-r from-purple-600 via-[#2D1E36] to-blue-600 bg-clip-text text-transparent">
                hear from you
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Have questions about Paychipa? Want to partner with us? Or just want to say hi? Drop us a message and we'll get back to you as soon as possible.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Info Cards */}
      <div className="py-16 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-purple-50 to-white p-6 rounded-2xl border border-purple-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Email Us</h3>
              <a href="mailto:hello@paychipa.com" className="text-[#2D1E36] hover:text-purple-600 transition-colors">
                hello@paychipa.com
              </a>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-white p-6 rounded-2xl border border-blue-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Call Us</h3>
              <a href="tel:+2349012345678" className="text-[#2D1E36] hover:text-blue-600 transition-colors">
                +234 901 234 5678
              </a>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-white p-6 rounded-2xl border border-green-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Visit Us</h3>
              <p className="text-[#2D1E36] text-sm">
                Abuja, Nigeria
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-2xl border border-gray-100 text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-gray-600 to-slate-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Support Hours</h3>
              <p className="text-[#2D1E36] text-sm">
                24/7 Available
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Form */}
      <div className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl text-[#2D1E36] mb-4">
              Send us a message
            </h2>
            <p className="text-xl text-gray-600">
              Fill out the form below and we'll respond within 24 hours
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-3xl p-8 md:p-12 border border-purple-100">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-[#2D1E36]">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-white border-gray-200 focus:border-[#2D1E36] h-12 rounded-xl"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[#2D1E36]">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-white border-gray-200 focus:border-[#2D1E36] h-12 rounded-xl"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-[#2D1E36]">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="08012345678"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-white border-gray-200 focus:border-[#2D1E36] h-12 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject" className="text-[#2D1E36]">
                    Subject
                  </Label>
                  <Input
                    id="subject"
                    placeholder="How can we help?"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="bg-white border-gray-200 focus:border-[#2D1E36] h-12 rounded-xl"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-[#2D1E36]">
                  Message *
                </Label>
                <Textarea
                  id="message"
                  placeholder="Tell us more about your inquiry..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="bg-white border-gray-200 focus:border-[#2D1E36] rounded-xl min-h-[150px]"
                  required
                />
              </div>

              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full h-14 bg-gradient-to-r from-[#2D1E36] to-purple-900 hover:from-[#1F1426] hover:to-purple-950 text-white rounded-xl shadow-lg shadow-[#2D1E36]/30 transition-all hover:shadow-xl hover:shadow-[#2D1E36]/40"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Sending...</span>
                  </div>
                ) : (
                  <>
                    Send Message
                    <Send className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>

              <p className="text-xs text-center text-gray-600">
                We typically respond within 24 hours during business days
              </p>
            </form>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="py-24 bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-[#2D1E36] mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600">
              Quick answers to common questions
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl text-[#2D1E36] mb-3">When will Paychipa launch?</h3>
              <p className="text-gray-600">
                We're planning to launch in 2026. Join our waitlist to be notified when we go live and get early access benefits.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl text-[#2D1E36] mb-3">Is Paychipa licensed?</h3>
              <p className="text-gray-600">
                We're working with regulatory bodies including the CBN to obtain all necessary licenses before launch to ensure full compliance and protection for our users.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl text-[#2D1E36] mb-3">How can I get a POS terminal?</h3>
              <p className="text-gray-600">
                Once we launch, you can request a free POS terminal through the app. We'll deliver it to your location within 48 hours.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl text-[#2D1E36] mb-3">Do you have customer support?</h3>
              <p className="text-gray-600">
                Yes! We'll offer 24/7 customer support via phone, email, and in-app chat when we launch.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Social Media */}
      <div className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-2xl text-[#2D1E36] mb-6">
            Follow us on social media
          </h3>
          <div className="flex justify-center gap-4 flex-wrap">
            <Button 
              variant="outline" 
              className="border-2 border-[#2D1E36] text-[#2D1E36] hover:bg-[#2D1E36] hover:text-white rounded-full px-6"
            >
              Twitter
            </Button>
            <Button 
              variant="outline" 
              className="border-2 border-[#2D1E36] text-[#2D1E36] hover:bg-[#2D1E36] hover:text-white rounded-full px-6"
            >
              Instagram
            </Button>
            <Button 
              variant="outline" 
              className="border-2 border-[#2D1E36] text-[#2D1E36] hover:bg-[#2D1E36] hover:text-white rounded-full px-6"
            >
              Facebook
            </Button>
            <Button 
              variant="outline" 
              className="border-2 border-[#2D1E36] text-[#2D1E36] hover:bg-[#2D1E36] hover:text-white rounded-full px-6"
            >
              LinkedIn
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
