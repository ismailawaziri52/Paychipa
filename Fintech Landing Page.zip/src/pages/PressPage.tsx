import { SEO } from "../components/SEO";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Download, Calendar, Mail, FileText, Newspaper } from "lucide-react";

export function PressPage() {
  const pressReleases = [
    {
      slug: "2026-launch-announcement",
      title: "Paychipa Announces 2026 Launch Plans for Revolutionary Digital Banking Platform",
      date: "January 15, 2025",
      excerpt: "Paychipa, a new fintech startup, today announced plans to launch its comprehensive digital banking platform in 2026, bringing simplified financial services to everyday Nigerians."
    },
    {
      slug: "stripe-flutterwave-partnership",
      title: "Paychipa Secures Strategic Partnership with Stripe and Flutterwave",
      date: "December 20, 2024",
      excerpt: "Pre-launch fintech startup Paychipa has partnered with leading payment processors Stripe and Flutterwave to power its upcoming digital banking platform."
    },
    {
      slug: "building-nigerian-fintech",
      title: "Building the Future: Paychipa's Vision for Nigerian Fintech",
      date: "November 15, 2024",
      excerpt: "Paychipa shares its ambitious vision to transform digital banking in Nigeria with innovative products including POS terminals, cards, savings, loans, and escrow services."
    }
  ];

  const mediaKit = [
    {
      title: "Company Logo Pack",
      description: "PNG, SVG, and vector formats",
      size: "2.4 MB"
    },
    {
      title: "Brand Guidelines",
      description: "Complete brand identity guide",
      size: "8.1 MB"
    },
    {
      title: "Product Screenshots",
      description: "High-resolution app screenshots",
      size: "12.5 MB"
    },
    {
      title: "Executive Bios",
      description: "Leadership team information",
      size: "156 KB"
    }
  ];

  const coverage = [
    {
      outlet: "TechCrunch Africa",
      title: "Nigerian Fintech Startup Paychipa Aims to Simplify Digital Banking",
      date: "January 2025"
    },
    {
      outlet: "Techpoint Africa",
      title: "Meet Paychipa: The New Player in Nigeria's Fintech Space",
      date: "December 2024"
    },
    {
      outlet: "Nairametrics",
      title: "Paychipa Prepares to Challenge Traditional Banking in Nigeria",
      date: "December 2024"
    },
    {
      outlet: "The Guardian Nigeria",
      title: "Digital Banking Startup Targets 2026 Launch",
      date: "November 2024"
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Press & Media - Paychipa | News & Press Releases"
        description="Latest press releases and media coverage about Paychipa. Download our press kit, media assets, and company information for journalists."
        keywords="paychipa press, press releases, media coverage, press kit, fintech news nigeria"
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full border border-white/10">
              <Newspaper className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">Press & Media</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Paychipa
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                Press Room
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Latest news, press releases, and media resources about Paychipa.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
              >
                <Mail className="w-5 h-5 mr-2" />
                Contact Press Team
              </Button>
              <Button 
                size="lg" 
                className="bg-white/10 backdrop-blur-xl border border-white/20 hover:bg-white/20 text-white px-8 rounded-full"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Media Kit
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Press Releases */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Press Releases
            </h2>
            <p className="text-xl text-gray-400">
              Official announcements and company news
            </p>
          </div>

          <div className="space-y-6 max-w-4xl mx-auto">
            {pressReleases.map((release, index) => (
              <Link to={`/press/${release.slug}`} key={index}>
                <div 
                  className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
                >
                  <div className="flex items-start gap-2 text-sm text-gray-400 mb-4">
                    <Calendar className="w-4 h-4 mt-0.5 text-purple-400" />
                    {release.date}
                  </div>
                  <h3 className="text-2xl text-white mb-4 group-hover:text-purple-400 transition-colors">
                    {release.title}
                  </h3>
                  <p className="text-gray-400 mb-6">
                    {release.excerpt}
                  </p>
                  <div className="text-purple-400 hover:text-purple-300">
                    Read full release →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Media Kit */}
      <div className="py-24 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 text-center">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Media Kit
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Download our brand assets and company information
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mediaKit.map((item, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-3xl p-6 border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg text-white mb-2">{item.title}</h3>
                <p className="text-sm text-gray-400 mb-1">{item.description}</p>
                <p className="text-xs text-gray-500">{item.size}</p>
                <Button 
                  variant="ghost"
                  className="text-purple-400 hover:text-purple-300 p-0 mt-4"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Complete Media Kit
            </Button>
          </div>
        </div>
      </div>

      {/* Media Coverage */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              In the News
            </h2>
            <p className="text-xl text-gray-400">
              Recent media coverage and mentions
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {coverage.map((item, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
              >
                <div className="text-sm text-purple-400 mb-2">{item.outlet}</div>
                <h3 className="text-lg text-white mb-3 group-hover:text-purple-400 transition-colors">
                  {item.title}
                </h3>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Calendar className="w-4 h-4" />
                  {item.date}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="py-24 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/5 backdrop-blur-xl rounded-3xl p-12 border border-white/10 text-center">
            <h2 className="text-4xl text-white mb-6">
              Press Inquiries
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              For press inquiries, interview requests, or additional information, please contact our press team.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center justify-center gap-3 text-gray-300">
                <Mail className="w-5 h-5 text-purple-400" />
                <a href="mailto:press@paychipa.com" className="hover:text-white transition-colors">
                  press@paychipa.com
                </a>
              </div>
            </div>

            <Button 
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
            >
              Send Press Inquiry
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
