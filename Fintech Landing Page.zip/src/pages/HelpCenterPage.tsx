import { SEO } from "../components/SEO";
import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Search, HelpCircle, CreditCard, Smartphone, Building2, Shield, DollarSign, MessageCircle, ChevronDown } from "lucide-react";

export function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const categories = [
    {
      icon: Smartphone,
      title: "Getting Started",
      description: "Learn the basics of using Paychipa",
      articles: 12,
      slug: "open-account"
    },
    {
      icon: CreditCard,
      title: "Cards & Payments",
      description: "Managing your cards and making payments",
      articles: 18,
      slug: "virtual-card-guide"
    },
    {
      icon: Building2,
      title: "Business Accounts",
      description: "Business features and merchant services",
      articles: 15,
      slug: "request-pos-terminal"
    },
    {
      icon: DollarSign,
      title: "Savings & Loans",
      description: "Growing your money with us",
      articles: 10,
      slug: "savings-account-guide"
    },
    {
      icon: Shield,
      title: "Security & Privacy",
      description: "Keeping your account safe",
      articles: 14,
      slug: "two-factor-authentication"
    },
    {
      icon: HelpCircle,
      title: "Troubleshooting",
      description: "Fixing common issues",
      articles: 20,
      slug: "troubleshooting-guide"
    }
  ];

  const faqs = [
    {
      question: "When will Paychipa launch?",
      answer: "Paychipa is scheduled to launch in 2025. Join our waitlist to be notified when we go live and get early access to our platform."
    },
    {
      question: "How do I get a free POS terminal?",
      answer: "Once we launch in 2025, you'll be able to request a free POS terminal through our app. Simply create a business account, complete the verification process, and we'll deliver your terminal within 48 hours to your location in Nigeria."
    },
    {
      question: "Are my funds safe with Paychipa?",
      answer: "Yes. We use bank-level security measures including 256-bit encryption, two-factor authentication, and secure data storage. While we are preparing for regulatory approvals ahead of our 2025 launch, security is our top priority."
    },
    {
      question: "What are the fees for transfers?",
      answer: "We offer free transfers to all Nigerian banks. There are no hidden charges for sending money within Nigeria through Paychipa."
    },
    {
      question: "Can I use Paychipa cards internationally?",
      answer: "Yes! Our Mastercard debit cards work globally at ATMs, POS terminals, and for online purchases worldwide. Standard international transaction fees apply."
    },
    {
      question: "How do I join the waitlist?",
      answer: "You can join our waitlist by clicking the 'Join Waitlist' button on our homepage and filling out the registration form with your details. You'll receive updates about our launch and exclusive early access."
    },
    {
      question: "What interest rate do you offer on savings?",
      answer: "We plan to offer up to 15% annual interest on savings accounts. Final rates will be confirmed closer to our launch date and may vary based on account type and balance."
    },
    {
      question: "Do you offer business loans?",
      answer: "Yes, we will offer business loans to verified merchants and businesses. Loan amounts, terms, and interest rates will be based on your business profile and transaction history with Paychipa."
    },
    {
      question: "What payment processors do you use?",
      answer: "Paychipa is powered by Stripe and Flutterwave, two of the world's leading payment processing platforms, ensuring reliable and secure transactions."
    },
    {
      question: "Will I need to visit a branch to open an account?",
      answer: "No! Paychipa is 100% digital. You can open an account entirely from your phone in minutes, with no need to visit a physical branch."
    }
  ];

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Help Center - Paychipa | FAQs & Support Articles"
        description="Find answers to your questions about Paychipa. Browse our help articles, FAQs, guides on accounts, cards, savings, loans, POS terminals, and more."
        keywords="paychipa help, support, faq, help center, customer support, how to use paychipa"
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full border border-white/10">
              <HelpCircle className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">We're Here to Help</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              How can we
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                help you?
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Search our knowledge base or browse categories to find answers to your questions.
            </p>

            {/* Search */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search for help articles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-14 pr-6 py-6 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full text-white placeholder:text-gray-400 text-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 text-center">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Browse by Category
            </h2>
            <p className="text-xl text-gray-400">
              Find answers organized by topic
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Link to={`/help/${category.slug}`} key={index}>
                <div 
                  className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <category.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl text-white mb-2 group-hover:text-purple-400 transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-gray-400 mb-4">{category.description}</p>
                  <div className="text-sm text-purple-400">
                    {category.articles} articles
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* FAQs */}
      <div className="py-24 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 text-center">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-400">
              Quick answers to common questions
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-6 flex items-center justify-between text-left hover:bg-white/5 transition-all"
                >
                  <span className="text-lg text-white pr-8">{faq.question}</span>
                  <ChevronDown 
                    className={`w-5 h-5 text-purple-400 flex-shrink-0 transition-transform ${
                      openFaq === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-6 text-gray-400 leading-relaxed border-t border-white/10 pt-6">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Popular Articles */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 text-center">
            <h2 className="text-4xl sm:text-5xl text-white mb-4">
              Popular Articles
            </h2>
            <p className="text-xl text-gray-400">
              Most viewed help articles
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              { title: "How to open a Paychipa account", slug: "open-account" },
              { title: "Setting up two-factor authentication", slug: "two-factor-authentication" },
              { title: "Requesting your first POS terminal", slug: "request-pos-terminal" },
              { title: "Understanding transaction limits", slug: "transaction-limits" },
              { title: "How to reset your password", slug: "reset-password" },
              { title: "Linking your bank account", slug: "link-bank-account" }
            ].map((article, index) => (
              <Link to={`/help/${article.slug}`} key={index}>
                <div 
                  className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <HelpCircle className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-white group-hover:text-purple-400 transition-colors">
                      {article.title}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Support */}
      <div className="py-24 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/5 backdrop-blur-xl rounded-3xl p-12 border border-white/10 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <MessageCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl text-white mb-6">
              Still need help?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Can't find what you're looking for? Our support team is ready to assist you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
              >
                Contact Support
              </Button>
              <Button 
                size="lg"
                className="bg-white/10 backdrop-blur-xl border border-white/20 hover:bg-white/20 text-white px-8 rounded-full"
              >
                Send us an Email
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
