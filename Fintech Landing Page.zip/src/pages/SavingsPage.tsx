import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, PiggyBank, TrendingUp, Calendar, Target, Shield, Sparkles } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function SavingsPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="High-Interest Savings - Paychipa | Earn Up to 15% Annual Interest"
        description="Save smarter with Paychipa. Earn up to 15% annual interest on savings, fixed deposits, and target savings. Auto-save features, flexible withdrawals, and secure funds."
        keywords="high interest savings nigeria, fixed deposit nigeria, target savings, auto save, savings account nigeria, 15% interest"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-green-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
              <PiggyBank className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-300">Smart Savings</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Save automatically
              <span className="block bg-gradient-to-r from-green-400 via-emerald-400 to-teal-400 bg-clip-text text-transparent">
                earn up to 15% interest
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Reach your financial goals faster with automated savings and guaranteed high-interest returns. No hidden fees, withdraw anytime.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white group px-8 rounded-full shadow-xl shadow-green-500/50"
              >
                Start Saving Today
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
              >
                Calculate Returns
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Up to 15% interest</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Withdraw anytime</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">No hidden fees</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Savings Plans */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Choose your savings plan
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Flexible savings options designed to help you achieve your financial goals
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Target Savings */}
            <div className="bg-gradient-to-br from-green-600/10 to-emerald-600/10 backdrop-blur-xl border border-green-500/20 rounded-3xl p-8 hover:from-green-600/20 hover:to-emerald-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/50">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Target Savings</h3>
              <div className="text-3xl text-green-400 mb-2">12% p.a.</div>
              <p className="text-gray-400 mb-6">
                Save towards a specific goal with a set target amount and date.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Set your own target</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Automated deposits</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Early withdrawal allowed</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Interest paid monthly</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-full shadow-lg shadow-green-500/50"
              >
                Start Target Savings
              </Button>
            </div>

            {/* Fixed Savings */}
            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 hover:from-purple-600/20 hover:to-pink-600/20 transition-all relative">
              <div className="absolute top-4 right-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs px-3 py-1 rounded-full">
                Most Popular
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Fixed Savings</h3>
              <div className="text-3xl text-purple-400 mb-2">15% p.a.</div>
              <p className="text-gray-400 mb-6">
                Lock your funds for a fixed period and earn higher interest rates.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Highest interest rate</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">3, 6, or 12 months</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Guaranteed returns</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Auto-renewal option</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full shadow-lg shadow-purple-500/50"
              >
                Start Fixed Savings
              </Button>
            </div>

            {/* Flex Savings */}
            <div className="bg-gradient-to-br from-blue-600/10 to-cyan-600/10 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-8 hover:from-blue-600/20 hover:to-cyan-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Flex Savings</h3>
              <div className="text-3xl text-blue-400 mb-2">10% p.a.</div>
              <p className="text-gray-400 mb-6">
                Save and withdraw anytime with no lock-in period or penalties.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Complete flexibility</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">No minimum balance</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Instant withdrawals</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Interest calculated daily</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-full shadow-lg shadow-blue-500/50"
              >
                Start Flex Savings
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-green-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <h2 className="text-4xl text-white">
                Why save with Paychipa?
              </h2>
              <p className="text-xl text-gray-400">
                We make saving money simple, secure, and rewarding
              </p>
              
              <div className="space-y-4">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-500/50">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">High Interest Rates</h3>
                      <p className="text-gray-400">
                        Earn up to 15% annual interest - higher than traditional banks
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/50">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">100% Secure</h3>
                      <p className="text-gray-400">
                        Your savings are protected with advanced security measures
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/50">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Automated Savings</h3>
                      <p className="text-gray-400">
                        Set it and forget it - automatically save from your salary or daily
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-green-600/20 to-purple-600/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1562173512-79ce9a4577b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwd29tYW4lMjBzYXZpbmclMjBtb25leXxlbnwxfHx8fDE3NjExNDY5ODN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="African woman saving money"
                  className="rounded-2xl w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Start building your future today
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of Nigerians already saving smarter with Paychipa
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-full px-8 shadow-xl shadow-green-500/50"
          >
            Start Saving Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
