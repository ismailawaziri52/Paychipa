import { SEO } from "../components/SEO";
import { useParams, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Calendar, ArrowLeft, Share2, Download } from "lucide-react";

export function PressReleasePage() {
  const { slug } = useParams();

  const releases: Record<string, any> = {
    "2026-launch-announcement": {
      title: "Paychipa Announces 2026 Launch Plans for Revolutionary Digital Banking Platform",
      date: "January 15, 2025",
      location: "Abuja, Nigeria",
      content: `
        <p><strong>FOR IMMEDIATE RELEASE</strong></p>

        <p>Paychipa, a new fintech startup, today announced plans to launch its comprehensive digital banking platform in 2026, bringing simplified financial services to everyday Nigerians. The company aims to revolutionize how Nigerians manage money, make payments, and access financial services.</p>

        <h2>Comprehensive Financial Services Platform</h2>
        <p>Paychipa will offer a full suite of financial products designed specifically for the Nigerian market:</p>

        <ul>
          <li><strong>Free POS Terminals:</strong> Business owners can request free point-of-sale terminals delivered within 48 hours</li>
          <li><strong>Virtual and Physical Cards:</strong> Mastercard debit cards available instantly for both online and in-person transactions</li>
          <li><strong>Instant Transfers:</strong> Free, instant money transfers to all Nigerian banks</li>
          <li><strong>Bill Payments:</strong> Unified platform for airtime, data, electricity, and subscription payments</li>
          <li><strong>High-Yield Savings:</strong> Up to 15% annual interest on savings accounts</li>
          <li><strong>Quick Loans:</strong> Instant loan approval with transparent terms</li>
          <li><strong>Escrow Services:</strong> Secure transactions for buyers and sellers</li>
        </ul>

        <h2>Mission-Driven Innovation</h2>
        <p>"Our mission is simple: make payments simple and accessible for everyone in Nigeria," said the Paychipa team. "Too many Nigerians are underserved by traditional banking. We're building a platform that combines the trust of traditional banking with the innovation and accessibility of modern fintech."</p>

        <h2>Strategic Technology Partnerships</h2>
        <p>Paychipa has secured partnerships with Stripe and Flutterwave, two of the world's leading payment processing platforms. These partnerships ensure that Paychipa users benefit from enterprise-grade security, reliability, and global payment capabilities.</p>

        <h2>Pre-Launch Waitlist Now Open</h2>
        <p>Nigerians interested in being among the first to access Paychipa can join the company's waitlist at paychipa.com. Waitlist members will receive exclusive updates, early access to the platform, and special launch benefits.</p>

        <h2>Security and Compliance</h2>
        <p>Paychipa is committed to the highest standards of security and regulatory compliance. The platform features bank-level 256-bit encryption, two-factor authentication, biometric login options, and real-time fraud detection. The company is working toward obtaining all necessary regulatory approvals ahead of its 2026 launch.</p>

        <h2>About Paychipa</h2>
        <p>Paychipa is a pre-launch fintech startup based in Abuja, Nigeria, dedicated to making banking simple and accessible for all Nigerians. The company is building a comprehensive digital banking platform that combines innovative technology with user-friendly design to deliver financial services that work for everyday people and businesses. Paychipa is powered by Stripe and Flutterwave.</p>

        <h2>Contact Information</h2>
        <p>
          <strong>Press Contact:</strong><br />
          Email: press@paychipa.com<br />
          Website: paychipa.com<br />
          Social Media: @paychipa (all platforms)
        </p>

        <p>###</p>
      `
    },
    "stripe-flutterwave-partnership": {
      title: "Paychipa Secures Strategic Partnership with Stripe and Flutterwave",
      date: "December 20, 2024",
      location: "Abuja, Nigeria",
      content: `
        <p><strong>FOR IMMEDIATE RELEASE</strong></p>

        <p>Pre-launch fintech startup Paychipa today announced strategic partnerships with Stripe and Flutterwave, two of the world's most trusted payment processing platforms. These partnerships will power Paychipa's digital banking platform, ensuring secure, reliable, and seamless transactions for Nigerian users when the platform launches in 2026.</p>

        <h2>World-Class Payment Infrastructure</h2>
        <p>By partnering with both Stripe and Flutterwave, Paychipa will leverage best-in-class payment infrastructure that processes billions of dollars in transactions annually. This dual-partnership approach ensures maximum reliability, redundancy, and coverage across different payment methods and use cases.</p>

        <h2>Enhanced Security and Reliability</h2>
        <p>"Security and reliability are non-negotiable when it comes to handling people's money," said the Paychipa team. "By partnering with Stripe and Flutterwave, we're building on proven infrastructure that's trusted by millions of businesses and consumers worldwide."</p>

        <p>The partnerships bring several key benefits to Paychipa users:</p>

        <ul>
          <li><strong>Enterprise-Grade Security:</strong> PCI DSS Level 1 compliance, the highest level of payment security</li>
          <li><strong>Global Payment Acceptance:</strong> Support for international cards and payment methods</li>
          <li><strong>99.99% Uptime:</strong> Redundant systems ensure services are always available</li>
          <li><strong>Fraud Prevention:</strong> Advanced machine learning algorithms detect and prevent fraudulent transactions</li>
          <li><strong>Instant Settlements:</strong> Fast access to funds for businesses and individuals</li>
          <li><strong>Multi-Currency Support:</strong> Ability to handle international transactions seamlessly</li>
        </ul>

        <h2>Empowering Nigerian Businesses</h2>
        <p>The partnerships will particularly benefit Nigerian businesses using Paychipa's free POS terminals and merchant services. Businesses will be able to accept all major payment methods, receive instant settlements, and access detailed analytics - all backed by the robust infrastructure of Stripe and Flutterwave.</p>

        <h2>About the Partners</h2>
        <p><strong>Stripe</strong> is a global technology company that builds economic infrastructure for the internet. Businesses of every size—from new startups to public companies—use Stripe's software to accept payments and manage their businesses online.</p>

        <p><strong>Flutterwave</strong> is Africa's leading payments technology company, processing over 200 million transactions worth more than $16 billion for businesses across the continent.</p>

        <h2>Launch Timeline</h2>
        <p>Paychipa continues to prepare for its 2026 launch. The company is currently accepting waitlist registrations and building out its platform infrastructure. Nigerians interested in early access can join the waitlist at paychipa.com.</p>

        <h2>About Paychipa</h2>
        <p>Paychipa is a pre-launch fintech startup based in Abuja, Nigeria, dedicated to making banking simple and accessible for all Nigerians. Powered by Stripe and Flutterwave, Paychipa is building a comprehensive digital banking platform featuring POS terminals, cards, transfers, savings, loans, and escrow services.</p>

        <h2>Contact Information</h2>
        <p>
          <strong>Press Contact:</strong><br />
          Email: press@paychipa.com<br />
          Website: paychipa.com<br />
          Social Media: @paychipa (all platforms)
        </p>

        <p>###</p>
      `
    },
    "building-nigerian-fintech": {
      title: "Building the Future: Paychipa's Vision for Nigerian Fintech",
      date: "November 15, 2024",
      location: "Abuja, Nigeria",
      content: `
        <p><strong>FOR IMMEDIATE RELEASE</strong></p>

        <p>Paychipa today shared its ambitious vision for transforming digital banking in Nigeria, outlining plans to launch a comprehensive fintech platform in 2026 that addresses the unique needs of Nigerian consumers and businesses.</p>

        <h2>Understanding the Nigerian Market</h2>
        <p>"Nigeria has a young, tech-savvy population that's ready for better financial services," the Paychipa team explained. "We've spent months researching the Nigerian market, talking to potential users, and understanding the pain points of current banking solutions."</p>

        <p>Key insights that shaped Paychipa's development include:</p>

        <ul>
          <li>High fees and hidden charges frustrate users</li>
          <li>Long processing times for basic transactions</li>
          <li>Difficulty accessing credit and savings products</li>
          <li>Complex onboarding processes</li>
          <li>Poor customer service and support</li>
          <li>Limited accessibility for small businesses</li>
        </ul>

        <h2>Designed for Nigerians, by Nigerians</h2>
        <p>Paychipa's product suite has been specifically designed to address these challenges:</p>

        <h3>For Individuals</h3>
        <ul>
          <li>Zero monthly maintenance fees</li>
          <li>Free unlimited transfers to any Nigerian bank</li>
          <li>Instant virtual cards for online shopping</li>
          <li>High-yield savings accounts up to 15% annual interest</li>
          <li>Quick loan approval based on transaction history</li>
          <li>Easy bill payments for all utilities and services</li>
        </ul>

        <h3>For Businesses</h3>
        <ul>
          <li>Free POS terminals with 48-hour delivery</li>
          <li>Competitive merchant rates</li>
          <li>Same-day settlement of funds</li>
          <li>Detailed sales analytics and reporting</li>
          <li>Multiple payment method acceptance</li>
          <li>Business loans for working capital</li>
        </ul>

        <h2>Innovation Through Technology</h2>
        <p>Paychipa leverages cutting-edge technology to deliver superior user experiences:</p>

        <ul>
          <li><strong>Mobile-First Design:</strong> Every feature optimized for smartphones</li>
          <li><strong>AI-Powered Insights:</strong> Smart spending analysis and savings recommendations</li>
          <li><strong>Biometric Security:</strong> Fingerprint and face recognition for secure access</li>
          <li><strong>Offline Capabilities:</strong> Access key features even without internet</li>
          <li><strong>Real-Time Notifications:</strong> Instant alerts for all transactions</li>
          <li><strong>24/7 Chatbot Support:</strong> Get help anytime, instantly</li>
        </ul>

        <h2>Financial Inclusion Mission</h2>
        <p>"We believe every Nigerian deserves access to quality financial services," the team stated. "Paychipa is designed to serve everyone - from students opening their first account to established businesses processing thousands of transactions monthly."</p>

        <h2>Environmental and Social Responsibility</h2>
        <p>As a digital-first platform, Paychipa contributes to environmental sustainability by eliminating paper-based processes. The company also plans to launch financial literacy programs to help Nigerians make better financial decisions.</p>

        <h2>Road to Launch</h2>
        <p>Paychipa is currently in intensive development, with the full platform scheduled to launch in 2026. The company is building its team, securing regulatory approvals, and refining its products based on feedback from waitlist members.</p>

        <h2>Join the Movement</h2>
        <p>Nigerians interested in being part of this financial revolution can join Paychipa's waitlist at paychipa.com. Waitlist members will receive exclusive updates, early platform access, and special launch benefits.</p>

        <h2>About Paychipa</h2>
        <p>Based in Abuja, Nigeria, Paychipa is a pre-launch fintech startup on a mission to make banking simple and accessible for all Nigerians. Powered by Stripe and Flutterwave, Paychipa is building a comprehensive digital banking platform featuring POS terminals, virtual and physical cards, instant transfers, bill payments, high-yield savings, loans, and escrow services.</p>

        <h2>Contact Information</h2>
        <p>
          <strong>Press Contact:</strong><br />
          Email: press@paychipa.com<br />
          Website: paychipa.com<br />
          Social Media: @paychipa (all platforms)
        </p>

        <p>###</p>
      `
    }
  };

  const release = slug ? releases[slug] : null;

  if (!release) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <SEO title="Press Release Not Found - Paychipa" />
        <div className="text-center">
          <h1 className="text-4xl text-white mb-4">Press Release Not Found</h1>
          <Link to="/press">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full">
              Back to Press Room
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title={`${release.title} - Paychipa Press Release`}
        description={release.content.substring(0, 160).replace(/<[^>]*>/g, '')}
        type="article"
        publishedTime={new Date(release.date).toISOString()}
        keywords="paychipa press release, fintech news nigeria, digital banking announcement"
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/press" className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Press Room
          </Link>

          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full border border-white/10 mb-6">
            <span className="text-sm text-gray-200">Press Release</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            {release.title}
          </h1>

          <div className="flex items-center gap-6 text-gray-400 mb-8">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {release.date}
            </div>
            <div>{release.location}</div>
          </div>

          <div className="flex gap-3">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full">
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
            <Button variant="outline" size="sm" className="bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-full">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div 
          className="prose prose-invert prose-lg max-w-none
            prose-headings:text-white prose-headings:font-semibold
            prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-6
            prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4
            prose-p:text-gray-300 prose-p:leading-relaxed prose-p:mb-6
            prose-ul:text-gray-300 prose-ul:my-6
            prose-li:my-2
            prose-strong:text-white
            prose-a:text-purple-400 prose-a:no-underline hover:prose-a:text-purple-300"
          dangerouslySetInnerHTML={{ __html: release.content }}
        />
      </div>

      {/* Press Contact CTA */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 backdrop-blur-xl rounded-3xl p-8 border border-white/10 text-center">
          <h3 className="text-2xl text-white mb-4">Media Inquiries</h3>
          <p className="text-gray-300 mb-6">For additional information or interview requests, please contact our press team.</p>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8">
            Contact Press Team
          </Button>
        </div>
      </div>
    </div>
  );
}
