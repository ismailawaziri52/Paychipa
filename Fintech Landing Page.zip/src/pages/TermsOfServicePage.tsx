import { SEO } from "../components/SEO";
import { Link } from "react-router-dom";
import { FileText, Scale, AlertTriangle, CheckCircle, XCircle, Shield } from "lucide-react";

export function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Terms of Service - Paychipa | User Agreement"
        description="Read Paychipa's terms of service and user agreement. Understand your rights and responsibilities when using our digital banking platform."
        keywords="terms of service, user agreement, terms and conditions, paychipa terms, legal"
        type="website"
      />
      {/* Hero Section */}
      <div className="relative py-20 overflow-hidden">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full mb-6">
            <Scale className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-gray-300">Last Updated: January 15, 2025</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            Terms of Service
          </h1>
          
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Please read these terms carefully before using Paychipa's services. By using our platform, you agree to be bound by these terms.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Agreement to Terms */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <FileText className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h2 className="text-2xl text-white mb-3">Agreement to Terms</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                These Terms of Service ("Terms") constitute a legally binding agreement between you and Paychipa Technologies Limited ("Paychipa," "we," "us," or "our") regarding your access to and use of the Paychipa mobile application and related services (collectively, the "Services").
              </p>
              <p className="text-gray-300 leading-relaxed">
                By creating an account or using our Services, you agree to comply with and be bound by these Terms. If you do not agree to these Terms, you must not access or use our Services.
              </p>
            </div>
          </div>
        </div>

        {/* Eligibility */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Eligibility</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>To use our Services, you must:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Be at least 18 years of age</li>
              <li>Be a resident of Nigeria</li>
              <li>Have the legal capacity to enter into binding contracts</li>
              <li>Provide accurate and complete registration information</li>
              <li>Have a valid Bank Verification Number (BVN) or National Identification Number (NIN)</li>
              <li>Not be prohibited from using financial services under Nigerian law</li>
            </ul>
            <div className="bg-red-500/10 border border-red-400/30 rounded-xl p-4 mt-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  We reserve the right to refuse service or terminate accounts that do not meet eligibility requirements.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Account Registration */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Account Registration and Security</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg text-white mb-3">Registration</h3>
              <p className="text-gray-300 mb-3">
                When you create an account, you agree to:
              </p>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Provide accurate, current, and complete information</li>
                <li>Maintain and update your information to keep it accurate</li>
                <li>Complete our KYC (Know Your Customer) verification process</li>
                <li>Not create multiple accounts or share your account with others</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Account Security</h3>
              <p className="text-gray-300 mb-3">You are responsible for:</p>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Maintaining the confidentiality of your password and account credentials</li>
                <li>All activities that occur under your account</li>
                <li>Notifying us immediately of any unauthorized access</li>
                <li>Not sharing your PIN, password, or OTP with anyone</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Services */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Our Services</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>Paychipa provides the following financial services:</p>
            
            <div className="grid gap-4">
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Payment Services</h3>
                <p className="text-sm">Money transfers, bill payments, airtime and data purchases</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Card Services</h3>
                <p className="text-sm">Virtual and physical debit cards for online and offline transactions</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">POS Terminals</h3>
                <p className="text-sm">Point of sale devices for merchants to accept card payments</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Savings & Investment</h3>
                <p className="text-sm">High-yield savings accounts and investment opportunities</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Loans</h3>
                <p className="text-sm">Quick loans subject to credit approval and terms</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <h3 className="text-white mb-2">Escrow Services</h3>
                <p className="text-sm">Secure holding of funds for marketplace transactions</p>
              </div>
            </div>
          </div>
        </div>

        {/* Fees and Charges */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Fees and Charges</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>
              We may charge fees for certain services. All applicable fees will be clearly displayed before you complete a transaction. Fees may include:
            </p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Transfer fees for certain transaction types</li>
              <li>Card maintenance fees for physical cards</li>
              <li>POS terminal transaction fees</li>
              <li>Late payment fees on loans</li>
              <li>Early withdrawal penalties on fixed savings</li>
            </ul>
            <p className="pt-2">
              We reserve the right to change our fee structure with 30 days' advance notice. Updated fees will be communicated via email and in-app notifications.
            </p>
          </div>
        </div>

        {/* Prohibited Activities */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-red-500/20 border border-red-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <XCircle className="h-6 w-6 text-red-400" />
            </div>
            <h2 className="text-2xl text-white">Prohibited Activities</h2>
          </div>
          
          <div className="space-y-4 ml-16 text-gray-300">
            <p>You agree NOT to use our Services for:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Fraudulent transactions or money laundering</li>
              <li>Financing illegal activities or terrorism</li>
              <li>Gambling or betting services (unless licensed)</li>
              <li>Purchase of illegal goods or services</li>
              <li>Circumventing KYC or identity verification</li>
              <li>Creating fake or duplicate accounts</li>
              <li>Reverse engineering or tampering with our software</li>
              <li>Sending spam or unsolicited communications</li>
              <li>Violating any Nigerian or international laws</li>
            </ul>
            
            <div className="bg-red-500/10 border border-red-400/30 rounded-xl p-4 mt-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm">
                  Violation of these prohibitions may result in immediate account suspension, transaction reversal, and reporting to law enforcement authorities.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Transactions */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Transactions and Disputes</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg text-white mb-3">Transaction Authorization</h3>
              <p className="text-gray-300">
                By initiating a transaction, you authorize us to debit your account for the transaction amount plus any applicable fees. All transactions are final once processed, except as required by law or our refund policy.
              </p>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Transaction Limits</h3>
              <p className="text-gray-300 mb-3">
                We may impose transaction limits based on:
              </p>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Your account verification level</li>
                <li>Regulatory requirements</li>
                <li>Risk management policies</li>
                <li>Account history and behavior</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Disputes and Errors</h3>
              <p className="text-gray-300 mb-3">
                If you believe a transaction is unauthorized or incorrect, you must notify us within 30 days. We will investigate and respond within 10 business days. To report a dispute, contact <a href="mailto:disputes@paychipa.com" className="text-purple-400 hover:text-purple-300">disputes@paychipa.com</a>.
              </p>
            </div>
          </div>
        </div>

        {/* Liability */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Limitation of Liability</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>
              To the fullest extent permitted by law, Paychipa shall not be liable for:
            </p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Service interruptions or downtime</li>
              <li>Losses resulting from unauthorized access to your account</li>
              <li>Delays in processing transactions due to third-party service providers</li>
              <li>Indirect, incidental, or consequential damages</li>
              <li>Total liability exceeding the fees paid by you in the 12 months prior to the claim</li>
            </ul>
            <p className="pt-4">
              <strong className="text-white">Note:</strong> Paychipa is currently in pre-launch phase. We are not yet licensed by the Central Bank of Nigeria (CBN) and deposits are not insured by the Nigeria Deposit Insurance Corporation (NDIC). By joining our waitlist, you acknowledge this status.
            </p>
          </div>
        </div>

        {/* Termination */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Account Termination</h2>
          
          <div className="space-y-4 text-gray-300">
            <div>
              <h3 className="text-lg text-white mb-3">Your Right to Terminate</h3>
              <p>
                You may close your account at any time by contacting customer support. Upon closure, you must withdraw all funds and settle any outstanding balances.
              </p>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Our Right to Terminate</h3>
              <p className="mb-2">We may suspend or terminate your account immediately if:</p>
              <ul className="space-y-2 list-disc list-inside">
                <li>You violate these Terms</li>
                <li>We suspect fraudulent or illegal activity</li>
                <li>Required by law or regulatory authorities</li>
                <li>Your account is inactive for 12 consecutive months</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Governing Law */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Governing Law and Dispute Resolution</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>
              These Terms are governed by the laws of the Federal Republic of Nigeria. Any disputes arising from these Terms or your use of our Services shall be resolved through:
            </p>
            <ol className="space-y-2 list-decimal list-inside">
              <li>Good faith negotiation between the parties</li>
              <li>Mediation, if negotiation fails</li>
              <li>Arbitration under the Arbitration and Mediation Act of Nigeria</li>
              <li>Nigerian courts, as a last resort</li>
            </ol>
          </div>
        </div>

        {/* Changes to Terms */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Changes to Terms</h2>
          <p className="text-gray-300 leading-relaxed">
            We may modify these Terms at any time. Material changes will be communicated at least 30 days in advance via email or in-app notification. Your continued use of our Services after changes take effect constitutes acceptance of the modified Terms. If you do not agree to the changes, you must stop using our Services and close your account.
          </p>
        </div>

        {/* Contact */}
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
          <h2 className="text-2xl text-white mb-4">Contact Us</h2>
          <p className="text-gray-300 mb-4">
            For questions about these Terms of Service, please contact us:
          </p>
          <div className="space-y-2 text-gray-300">
            <p><strong className="text-white">Email:</strong> <a href="mailto:legal@paychipa.com" className="text-purple-400 hover:text-purple-300">legal@paychipa.com</a></p>
            <p><strong className="text-white">Phone:</strong> <a href="tel:+2349012345678" className="text-purple-400 hover:text-purple-300">+234 901 234 5678</a></p>
            <p><strong className="text-white">Address:</strong> Abuja, Nigeria</p>
          </div>
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
