import { useParams, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { ArrowLeft, ThumbsUp, ThumbsDown, HelpCircle } from "lucide-react";
import { useState } from "react";

export function HelpArticlePage() {
  const { slug } = useParams();
  const [helpful, setHelpful] = useState<boolean | null>(null);

  const articles: Record<string, any> = {
    "open-account": {
      title: "How to Open a Paychipa Account",
      category: "Getting Started",
      content: `
        <p>Opening a Paychipa account is quick and easy. Follow these simple steps to get started with better banking.</p>

        <h2>Requirements</h2>
        <p>Before you begin, make sure you have:</p>
        <ul>
          <li>A valid Nigerian phone number</li>
          <li>A government-issued ID (NIN, Driver's License, International Passport, or Voter's Card)</li>
          <li>A clear selfie photo</li>
          <li>Your BVN (Bank Verification Number)</li>
        </ul>

        <h2>Step-by-Step Guide</h2>

        <h3>Step 1: Download the App</h3>
        <p>Download the Paychipa app from the Google Play Store or Apple App Store. The app is free and takes less than a minute to download.</p>

        <h3>Step 2: Enter Your Phone Number</h3>
        <p>Open the app and enter your Nigerian phone number. You'll receive an OTP (One-Time Password) via SMS to verify your number.</p>

        <h3>Step 3: Create Your Profile</h3>
        <p>Enter your basic information:</p>
        <ul>
          <li>Full name (as it appears on your ID)</li>
          <li>Date of birth</li>
          <li>Email address</li>
          <li>Residential address</li>
        </ul>

        <h3>Step 4: Verify Your Identity</h3>
        <p>Upload a clear photo of your government-issued ID. Make sure all corners are visible and the text is readable. Then, take a selfie for facial verification. Our system will automatically verify that your selfie matches your ID photo.</p>

        <h3>Step 5: Link Your BVN</h3>
        <p>Enter your 11-digit Bank Verification Number. This is required by the Central Bank of Nigeria for all financial accounts. Your BVN helps us verify your identity and keep your account secure.</p>

        <h3>Step 6: Set Your PIN</h3>
        <p>Create a secure 4-digit PIN for transactions. Choose a PIN that's easy for you to remember but hard for others to guess. Don't use obvious combinations like 1234 or your birth year.</p>

        <h3>Step 7: Enable Biometrics (Optional but Recommended)</h3>
        <p>Set up fingerprint or face recognition for quick and secure login. This adds an extra layer of security to your account.</p>

        <h2>Account Activation</h2>
        <p>Once you've completed all steps, your account will be activated instantly! You'll receive a welcome message and can start:</p>
        <ul>
          <li>Adding money to your account</li>
          <li>Ordering your free debit card</li>
          <li>Making transfers</li>
          <li>Paying bills</li>
          <li>Setting up savings goals</li>
        </ul>

        <h2>Troubleshooting</h2>

        <h3>OTP Not Received</h3>
        <p>If you don't receive the OTP within 2 minutes:</p>
        <ul>
          <li>Check that you entered the correct phone number</li>
          <li>Make sure you have good network coverage</li>
          <li>Wait a few minutes and request a new OTP</li>
        </ul>

        <h3>ID Verification Failed</h3>
        <p>If your ID verification fails:</p>
        <ul>
          <li>Ensure the photo is clear and well-lit</li>
          <li>Make sure all four corners of the ID are visible</li>
          <li>Avoid glare or shadows on the ID</li>
          <li>Take the photo on a plain, contrasting background</li>
        </ul>

        <h3>BVN Not Matching</h3>
        <p>If your BVN verification fails:</p>
        <ul>
          <li>Double-check that you've entered the correct 11-digit number</li>
          <li>Ensure the name you entered matches your BVN records exactly</li>
          <li>Contact your bank if you're unsure of your BVN</li>
        </ul>

        <h2>Next Steps</h2>
        <p>After opening your account, we recommend:</p>
        <ul>
          <li>Adding money to your account via bank transfer</li>
          <li>Ordering your virtual card for online shopping</li>
          <li>Requesting your physical card for in-person payments</li>
          <li>Setting up automatic savings</li>
          <li>Exploring our bill payment features</li>
        </ul>

        <h2>Need Help?</h2>
        <p>If you encounter any issues during account opening, our support team is here to help 24/7. Contact us via:</p>
        <ul>
          <li>In-app chat</li>
          <li>Email: support@paychipa.com</li>
          <li>Phone: Coming soon</li>
        </ul>
      `
    },
    "two-factor-authentication": {
      title: "Setting Up Two-Factor Authentication",
      category: "Security & Privacy",
      content: `
        <p>Two-factor authentication (2FA) adds an extra layer of security to your Paychipa account. Even if someone knows your password, they won't be able to access your account without the second factor.</p>

        <h2>Why Enable 2FA?</h2>
        <p>Two-factor authentication significantly increases your account security by requiring two forms of verification:</p>
        <ul>
          <li><strong>Something you know:</strong> Your password or PIN</li>
          <li><strong>Something you have:</strong> Your phone or authentication app</li>
        </ul>

        <p>This makes it nearly impossible for unauthorized users to access your account, even if they obtain your password.</p>

        <h2>2FA Options in Paychipa</h2>

        <h3>1. SMS Authentication</h3>
        <p>Receive a code via text message each time you log in from a new device.</p>
        <p><strong>Pros:</strong> Easy to use, works on any phone<br />
        <strong>Cons:</strong> Requires cell service, vulnerable to SIM swapping</p>

        <h3>2. Authenticator App</h3>
        <p>Use apps like Google Authenticator or Authy to generate time-based codes.</p>
        <p><strong>Pros:</strong> More secure, works offline<br />
        <strong>Cons:</strong> Requires installing a separate app</p>

        <h3>3. Biometric Authentication</h3>
        <p>Use fingerprint or face recognition for quick verification.</p>
        <p><strong>Pros:</strong> Very fast, highly secure<br />
        <strong>Cons:</strong> Requires compatible device</p>

        <h2>How to Enable 2FA</h2>

        <h3>Using SMS Authentication</h3>
        <ol>
          <li>Open the Paychipa app and go to Settings</li>
          <li>Tap on "Security"</li>
          <li>Select "Two-Factor Authentication"</li>
          <li>Choose "SMS Authentication"</li>
          <li>Verify your phone number</li>
          <li>Enter the code sent to your phone</li>
          <li>2FA is now enabled!</li>
        </ol>

        <h3>Using Authenticator App</h3>
        <ol>
          <li>Download Google Authenticator or Authy (if you don't have it)</li>
          <li>Open Paychipa app and go to Settings > Security</li>
          <li>Select "Two-Factor Authentication"</li>
          <li>Choose "Authenticator App"</li>
          <li>Scan the QR code with your authenticator app</li>
          <li>Enter the 6-digit code from the authenticator app</li>
          <li>Save your backup codes in a safe place</li>
          <li>2FA is now enabled!</li>
        </ol>

        <h3>Using Biometric Authentication</h3>
        <ol>
          <li>Go to Settings > Security in the Paychipa app</li>
          <li>Select "Biometric Login"</li>
          <li>Choose Fingerprint or Face Recognition</li>
          <li>Follow the on-screen prompts to register your biometric</li>
          <li>Biometric login is now enabled!</li>
        </ol>

        <h2>Backup Codes</h2>
        <p>When you enable 2FA, you'll receive backup codes. These are important!</p>
        <ul>
          <li>Save them in a secure location (password manager, safe, etc.)</li>
          <li>Each code can only be used once</li>
          <li>Use them if you lose access to your 2FA method</li>
          <li>Generate new codes if you use all of them</li>
        </ul>

        <h2>What Happens When You Log In</h2>
        <p>With 2FA enabled, logging in requires two steps:</p>
        <ol>
          <li>Enter your email/phone and password/PIN</li>
          <li>Enter the code from SMS, authenticator app, or use biometric</li>
          <li>Access granted!</li>
        </ol>

        <h2>Trusted Devices</h2>
        <p>You can mark devices as "trusted" to skip 2FA on those devices for 30 days. Only do this on devices you own and that are secure.</p>

        <h2>Troubleshooting</h2>

        <h3>Lost Access to 2FA</h3>
        <p>If you lose access to your 2FA method:</p>
        <ul>
          <li>Use one of your backup codes to log in</li>
          <li>Once logged in, disable the old 2FA and set up a new one</li>
          <li>If you don't have backup codes, contact support with proof of identity</li>
        </ul>

        <h3>Codes Not Working</h3>
        <p>If your authenticator codes aren't working:</p>
        <ul>
          <li>Check that your device time is set to automatic</li>
          <li>Time synchronization is crucial for authenticator apps</li>
          <li>Try generating a new code</li>
          <li>Re-sync your authenticator app</li>
        </ul>

        <h2>Best Practices</h2>
        <ul>
          <li>Use authenticator apps instead of SMS when possible</li>
          <li>Keep your backup codes in a secure location</li>
          <li>Don't share your 2FA codes with anyone</li>
          <li>Update your 2FA method if you change phones</li>
          <li>Use unique passwords for different accounts</li>
          <li>Enable biometric login for convenience and security</li>
        </ul>

        <h2>Need Help?</h2>
        <p>If you need assistance with 2FA, contact our support team through the app or email support@paychipa.com.</p>
      `
    },
    "virtual-card-guide": {
      title: "Complete Guide to Paychipa Virtual and Physical Cards",
      category: "Cards & Payments",
      content: `
        <p>Paychipa offers both virtual and physical Mastercard debit cards that work globally. This comprehensive guide covers everything you need to know about getting and using your cards.</p>

        <h2>Virtual Cards</h2>
        <p>Virtual cards are digital-only cards perfect for online shopping and subscriptions. They're generated instantly and can be used immediately.</p>

        <h3>Benefits of Virtual Cards</h3>
        <ul>
          <li><strong>Instant creation:</strong> Get your card details immediately</li>
          <li><strong>Enhanced security:</strong> Create multiple cards for different purposes</li>
          <li><strong>Easy management:</strong> Freeze, delete, or create new cards anytime</li>
          <li><strong>No physical theft risk:</strong> Perfect for online-only use</li>
          <li><strong>Budget control:</strong> Set spending limits on each card</li>
        </ul>

        <h3>How to Create a Virtual Card</h3>
        <ol>
          <li>Open your Paychipa app</li>
          <li>Tap on "Cards" in the menu</li>
          <li>Select "Create Virtual Card"</li>
          <li>Choose your card design</li>
          <li>Set a spending limit (optional)</li>
          <li>Name your card (e.g., "Netflix", "Shopping")</li>
          <li>Tap "Create Card"</li>
        </ol>

        <p>Your virtual card will be created instantly with:</p>
        <ul>
          <li>16-digit card number</li>
          <li>CVV security code</li>
          <li>Expiry date</li>
          <li>Cardholder name</li>
        </ul>

        <h3>Using Your Virtual Card</h3>
        <p>Use your virtual card anywhere Mastercard is accepted online:</p>
        <ul>
          <li>Online shopping (Amazon, Jumia, Konga, etc.)</li>
          <li>Subscription services (Netflix, Spotify, YouTube Premium)</li>
          <li>International purchases</li>
          <li>App store purchases</li>
          <li>Food delivery apps</li>
        </ul>

        <h2>Physical Cards</h2>
        <p>Paychipa physical cards are premium Mastercard debit cards that work at ATMs, POS terminals, and online worldwide.</p>

        <h3>Card Features</h3>
        <ul>
          <li>Contactless payments (tap to pay)</li>
          <li>Chip and PIN security</li>
          <li>Magnetic stripe for older terminals</li>
          <li>Embossed card number and name</li>
          <li>Valid for 3 years</li>
          <li>Free replacement if lost or stolen</li>
        </ul>

        <h3>How to Order Your Physical Card</h3>
        <ol>
          <li>Complete your account verification (BVN, ID, selfie)</li>
          <li>Go to "Cards" section in the app</li>
          <li>Tap "Order Physical Card"</li>
          <li>Choose your card design</li>
          <li>Confirm your delivery address</li>
          <li>Review and submit your order</li>
        </ol>

        <h3>Delivery Timeline</h3>
        <ul>
          <li><strong>Abuja & Lagos:</strong> 3-5 business days</li>
          <li><strong>Major cities:</strong> 5-7 business days</li>
          <li><strong>Other areas:</strong> 7-10 business days</li>
        </ul>

        <h3>Card Activation</h3>
        <p>When your card arrives:</p>
        <ol>
          <li>Open the Paychipa app</li>
          <li>Go to Cards > Physical Card</li>
          <li>Tap "Activate Card"</li>
          <li>Enter the last 4 digits of your card</li>
          <li>Set your 4-digit card PIN</li>
          <li>Confirm activation</li>
        </ol>

        <p>Your card is now ready to use!</p>

        <h2>Card Security Features</h2>

        <h3>Freeze/Unfreeze</h3>
        <p>Instantly freeze your card if you misplace it, then unfreeze when found:</p>
        <ul>
          <li>Go to Cards in the app</li>
          <li>Select the card</li>
          <li>Tap "Freeze Card"</li>
          <li>Card is instantly unusable</li>
          <li>Tap "Unfreeze" to reactivate</li>
        </ul>

        <h3>Transaction Notifications</h3>
        <p>Receive instant alerts for every transaction:</p>
        <ul>
          <li>Push notifications</li>
          <li>SMS alerts</li>
          <li>Email notifications</li>
          <li>In-app transaction history</li>
        </ul>

        <h3>Spending Limits</h3>
        <p>Set daily spending limits to control your budget:</p>
        <ul>
          <li>ATM withdrawal limits</li>
          <li>POS transaction limits</li>
          <li>Online shopping limits</li>
          <li>International transaction limits</li>
        </ul>

        <h2>Card Fees</h2>

        <h3>Virtual Card</h3>
        <ul>
          <li><strong>Creation:</strong> FREE</li>
          <li><strong>Monthly fee:</strong> FREE</li>
          <li><strong>Transactions:</strong> FREE (Nigeria)</li>
          <li><strong>International:</strong> 3.5% + $0.50</li>
        </ul>

        <h3>Physical Card</h3>
        <ul>
          <li><strong>First card:</strong> FREE</li>
          <li><strong>Replacement (lost/stolen):</strong> ₦1,000</li>
          <li><strong>Card maintenance:</strong> ₦500/month (waived with 5+ transactions)</li>
          <li><strong>ATM withdrawals:</strong> 3 free per month, then ₦50 each</li>
          <li><strong>International transactions:</strong> 3.5% fee</li>
        </ul>

        <h2>International Use</h2>

        <h3>Activating International Transactions</h3>
        <ol>
          <li>Go to Card Settings</li>
          <li>Enable "International Transactions"</li>
          <li>Set your travel dates (optional)</li>
          <li>Specify countries (for added security)</li>
        </ol>

        <h3>Supported Countries</h3>
        <p>Your Paychipa card works in 200+ countries wherever Mastercard is accepted.</p>

        <h3>Currency Conversion</h3>
        <p>Transactions are automatically converted to Naira using Mastercard's exchange rate plus 3.5% fee.</p>

        <h2>Troubleshooting</h2>

        <h3>Card Declined</h3>
        <p>If your transaction is declined:</p>
        <ul>
          <li>Check your account balance</li>
          <li>Verify the card isn't frozen</li>
          <li>Check if you've exceeded daily limits</li>
          <li>Ensure international transactions are enabled (if abroad)</li>
          <li>Confirm the merchant accepts Mastercard</li>
        </ul>

        <h3>Lost or Stolen Card</h3>
        <ol>
          <li>Immediately freeze the card in the app</li>
          <li>Report as lost/stolen in Card Settings</li>
          <li>Order a replacement card</li>
          <li>Review recent transactions for unauthorized charges</li>
          <li>Contact support if fraudulent transactions occurred</li>
        </ol>

        <h3>Damaged Card</h3>
        <p>If your physical card is damaged:</p>
        <ul>
          <li>Request a replacement in the app</li>
          <li>Continue using your virtual card</li>
          <li>New card arrives in 5-7 days</li>
          <li>Same card number, new CVV and expiry</li>
        </ul>

        <h2>Best Practices</h2>
        <ul>
          <li>Never share your PIN or CVV with anyone</li>
          <li>Use virtual cards for online subscriptions</li>
          <li>Set spending limits for better budgeting</li>
          <li>Enable transaction notifications</li>
          <li>Freeze your card when not traveling</li>
          <li>Review transactions weekly</li>
          <li>Keep your app updated</li>
          <li>Report suspicious activity immediately</li>
        </ul>

        <h2>Need Help?</h2>
        <p>For card-related issues, contact us:</p>
        <ul>
          <li>In-app chat support (24/7)</li>
          <li>Email: cards@paychipa.com</li>
          <li>Phone hotline (coming soon)</li>
        </ul>
      `
    },
    "savings-account-guide": {
      title: "Paychipa Savings: Grow Your Money with High Interest",
      category: "Savings & Loans",
      content: `
        <p>Paychipa offers flexible savings options with competitive interest rates up to 15% annually. Learn how to maximize your savings and reach your financial goals.</p>

        <h2>Types of Savings Accounts</h2>

        <h3>1. Regular Savings</h3>
        <p>Perfect for emergency funds and short-term goals.</p>
        <ul>
          <li><strong>Interest rate:</strong> 8% per annum</li>
          <li><strong>Minimum balance:</strong> ₦0</li>
          <li><strong>Withdrawals:</strong> Anytime, unlimited</li>
          <li><strong>Interest paid:</strong> Monthly</li>
          <li><strong>Best for:</strong> Emergency funds, flexible savings</li>
        </ul>

        <h3>2. Target Savings</h3>
        <p>Save towards specific goals with automated deposits.</p>
        <ul>
          <li><strong>Interest rate:</strong> 10% per annum</li>
          <li><strong>Minimum deposit:</strong> ₦5,000/month</li>
          <li><strong>Duration:</strong> 3-36 months</li>
          <li><strong>Auto-save:</strong> Daily, weekly, or monthly</li>
          <li><strong>Best for:</strong> Rent, vacation, gadgets, education</li>
        </ul>

        <h3>3. Fixed Deposit</h3>
        <p>Lock funds for guaranteed high returns.</p>
        <ul>
          <li><strong>Interest rate:</strong> 12-15% per annum (depending on tenure)</li>
          <li><strong>Minimum amount:</strong> ₦50,000</li>
          <li><strong>Lock period:</strong> 3, 6, 9, or 12 months</li>
          <li><strong>Early withdrawal:</strong> Penalty applies (lose interest)</li>
          <li><strong>Best for:</strong> Long-term savings, maximum returns</li>
        </ul>

        <h3>4. Group Savings (Ajo/Esusu)</h3>
        <p>Save with friends or family in a digital savings group.</p>
        <ul>
          <li><strong>Interest rate:</strong> 8% per annum</li>
          <li><strong>Group size:</strong> 5-20 members</li>
          <li><strong>Payout:</strong> Rotating monthly payout</li>
          <li><strong>Flexible:</strong> Set your own rules</li>
          <li><strong>Best for:</strong> Community savings, accountability</li>
        </ul>

        <h2>How to Create a Savings Account</h2>

        <h3>Regular Savings</h3>
        <ol>
          <li>Open Paychipa app</li>
          <li>Tap "Savings" on home screen</li>
          <li>Select "Regular Savings"</li>
          <li>Your account is created automatically!</li>
          <li>Start saving by transferring money</li>
        </ol>

        <h3>Target Savings</h3>
        <ol>
          <li>Go to Savings > Create Target</li>
          <li>Name your goal (e.g., "New Laptop")</li>
          <li>Set target amount (e.g., ₦500,000)</li>
          <li>Choose target date</li>
          <li>Set auto-save amount and frequency</li>
          <li>Tap "Create Target"</li>
        </ol>

        <h3>Fixed Deposit</h3>
        <ol>
          <li>Go to Savings > Fixed Deposit</li>
          <li>Enter amount to lock (min. ₦50,000)</li>
          <li>Choose lock duration (3-12 months)</li>
          <li>Review interest rate</li>
          <li>Confirm and fund</li>
        </ol>

        <h2>Auto-Save Features</h2>

        <h3>Round-Up Savings</h3>
        <p>Automatically save the change from every transaction.</p>
        <ul>
          <li>Spend ₦1,450 → Save ₦550 (rounded to ₦2,000)</li>
          <li>Painless micro-savings</li>
          <li>Can save thousands monthly without noticing</li>
        </ul>

        <h3>Percentage Savings</h3>
        <p>Save a percentage of every credit to your account.</p>
        <ul>
          <li>Set 10%, 20%, or any percentage</li>
          <li>Automatic transfer on every income</li>
          <li>Perfect for consistent saving habit</li>
        </ul>

        <h3>Scheduled Savings</h3>
        <p>Automate regular transfers to savings.</p>
        <ul>
          <li>Daily, weekly, or monthly transfers</li>
          <li>Set amount and schedule</li>
          <li>Never miss a savings day</li>
        </ul>

        <h2>Interest Calculation</h2>

        <h3>How Interest is Calculated</h3>
        <p>Interest on Regular and Target Savings:</p>
        <ul>
          <li>Calculated daily on your balance</li>
          <li>Paid monthly to your savings account</li>
          <li>Compound interest (interest earns interest)</li>
        </ul>

        <p><strong>Example:</strong> Save ₦100,000 at 10% annually</p>
        <ul>
          <li>Monthly interest: ₦833</li>
          <li>After 12 months: ₦110,471 (with compounding)</li>
        </ul>

        <h3>Fixed Deposit Interest</h3>
        <p>Interest paid at maturity based on lock period:</p>
        <ul>
          <li>3 months: 12% per annum</li>
          <li>6 months: 13% per annum</li>
          <li>9 months: 14% per annum</li>
          <li>12 months: 15% per annum</li>
        </ul>

        <h2>Withdrawing from Savings</h2>

        <h3>Regular Savings</h3>
        <ul>
          <li>Withdraw anytime, any amount</li>
          <li>Instant transfer to main account</li>
          <li>No penalties or fees</li>
        </ul>

        <h3>Target Savings</h3>
        <ul>
          <li>Withdraw when target is reached</li>
          <li>Emergency withdrawal available</li>
          <li>Small penalty for early withdrawal (2% of interest)</li>
        </ul>

        <h3>Fixed Deposit</h3>
        <ul>
          <li>Funds locked until maturity</li>
          <li>Early withdrawal forfeits all interest</li>
          <li>Principal amount refunded</li>
        </ul>

        <h2>Savings Tips & Best Practices</h2>

        <h3>The 50/30/20 Rule</h3>
        <ul>
          <li>50% for needs (rent, food, bills)</li>
          <li>30% for wants (entertainment, shopping)</li>
          <li>20% for savings and investments</li>
        </ul>

        <h3>Pay Yourself First</h3>
        <p>Save immediately when you receive income, before spending:</p>
        <ul>
          <li>Use auto-save features</li>
          <li>Set percentage savings on all income</li>
          <li>Treat savings as a non-negotiable expense</li>
        </ul>

        <h3>Multiple Savings Goals</h3>
        <p>Create separate target savings for different goals:</p>
        <ul>
          <li>Emergency fund (3-6 months expenses)</li>
          <li>Rent (annual or biannual)</li>
          <li>Vacation fund</li>
          <li>Gadget fund</li>
          <li>Education/professional development</li>
        </ul>

        <h3>Maximize Interest</h3>
        <ul>
          <li>Use fixed deposits for money you won't need soon</li>
          <li>Keep emergency funds in regular savings</li>
          <li>Ladder fixed deposits (mature at different times)</li>
          <li>Reinvest interest to compound returns</li>
        </ul>

        <h2>Safety & Security</h2>

        <h3>Your Savings are Protected</h3>
        <ul>
          <li>Funds held in secure, segregated accounts</li>
          <li>Bank-level encryption</li>
          <li>Regular security audits</li>
          <li>Two-factor authentication</li>
          <li>Preparing for NDIC insurance coverage</li>
        </ul>

        <h2>Tax Implications</h2>
        <p>Interest earned on savings is subject to:</p>
        <ul>
          <li>10% Withholding Tax (WHT) - automatically deducted</li>
          <li>Reported to FIRS annually</li>
          <li>You receive net interest after WHT</li>
        </ul>

        <h2>Troubleshooting</h2>

        <h3>Can't Create Savings</h3>
        <ul>
          <li>Ensure your account is fully verified</li>
          <li>Check minimum balance requirements</li>
          <li>Update app to latest version</li>
        </ul>

        <h3>Auto-Save Not Working</h3>
        <ul>
          <li>Verify sufficient balance in main account</li>
          <li>Check auto-save schedule settings</li>
          <li>Ensure account isn't restricted</li>
        </ul>

        <h3>Interest Not Paid</h3>
        <ul>
          <li>Interest is paid monthly (first week of each month)</li>
          <li>Check transaction history</li>
          <li>Minimum balance required for some accounts</li>
          <li>Contact support if still missing</li>
        </ul>

        <h2>Need Help?</h2>
        <p>For savings-related questions:</p>
        <ul>
          <li>In-app chat support</li>
          <li>Email: savings@paychipa.com</li>
          <li>FAQs section in app</li>
        </ul>
      `
    },
    "troubleshooting-guide": {
      title: "Troubleshooting Common Issues with Paychipa",
      category: "Troubleshooting",
      content: `
        <p>Experiencing issues with your Paychipa account? This comprehensive troubleshooting guide covers solutions to the most common problems.</p>

        <h2>Login Issues</h2>

        <h3>Forgot Password/PIN</h3>
        <p><strong>Solution:</strong></p>
        <ol>
          <li>On login screen, tap "Forgot Password"</li>
          <li>Enter your registered phone number or email</li>
          <li>Receive OTP via SMS/email</li>
          <li>Enter OTP</li>
          <li>Create new password/PIN</li>
          <li>Confirm new password/PIN</li>
        </ol>

        <h3>Account Locked After Multiple Wrong Attempts</h3>
        <p><strong>Solution:</strong></p>
        <ul>
          <li>Wait 30 minutes and try again</li>
          <li>Use "Forgot Password" to reset</li>
          <li>If still locked, contact support with your:</li>
          <li>- Registered phone number</li>
          <li>- BVN (last 4 digits)</li>
          <li>- Valid ID for verification</li>
        </ul>

        <h3>OTP Not Received</h3>
        <p><strong>Possible causes and solutions:</strong></p>
        <ul>
          <li><strong>Network delay:</strong> Wait 2-3 minutes</li>
          <li><strong>Wrong number:</strong> Verify phone number entered correctly</li>
          <li><strong>Network issues:</strong> Check your signal strength</li>
          <li><strong>Message filtering:</strong> Check spam/junk folder (for email OTP)</li>
          <li><strong>DND active:</strong> Some networks block OTP when DND is on - dial *785# to check</li>
          <li><strong>Still not received:</strong> Request new OTP or try email instead</li>
        </ul>

        <h3>Biometric Login Not Working</h3>
        <p><strong>Solution:</strong></p>
        <ul>
          <li>Ensure fingerprint/face unlock is enabled in phone settings</li>
          <li>Re-register your fingerprint/face in app settings</li>
          <li>Clean your phone's fingerprint sensor/camera</li>
          <li>Update to latest app version</li>
          <li>Use PIN login as alternative</li>
        </ul>

        <h2>Transaction Issues</h2>

        <h3>Transfer Failed</h3>
        <p><strong>Common causes and solutions:</strong></p>
        <ul>
          <li><strong>Insufficient balance:</strong> Check your available balance (including pending transactions)</li>
          <li><strong>Daily limit exceeded:</strong> Check your daily transfer limit in settings</li>
          <li><strong>Invalid account number:</strong> Verify recipient's account number</li>
          <li><strong>Network timeout:</strong> Check internet connection and retry</li>
          <li><strong>Recipient bank issues:</strong> Try again later or contact recipient's bank</li>
          <li><strong>Account restricted:</strong> Contact support if account is under review</li>
        </ul>

        <h3>Money Debited But Transfer Failed</h3>
        <p><strong>Important:</strong> Don't panic! This is usually a temporary issue.</p>
        <p><strong>Solution:</strong></p>
        <ol>
          <li>Wait 10-15 minutes - funds often auto-reverse</li>
          <li>Check transaction history for reversal</li>
          <li>If not reversed within 24 hours:</li>
          <li>- Take screenshot of debit alert</li>
          <li>- Take screenshot of failed transaction</li>
          <li>- Contact support with screenshots and transaction reference</li>
          <li>Resolution time: 24-48 hours</li>
        </ol>

        <h3>Transfer Delayed</h3>
        <p><strong>Expected transfer times:</strong></p>
        <ul>
          <li>Paychipa to Paychipa: Instant</li>
          <li>To other banks: Usually instant, max 2 hours</li>
          <li>Weekend/holidays: May experience delays</li>
          <li>Large amounts: May require additional verification</li>
        </ul>

        <p><strong>If delayed beyond expected time:</strong></p>
        <ul>
          <li>Check if recipient bank is having issues</li>
          <li>Verify correct account details were used</li>
          <li>Contact support with transaction reference</li>
        </ul>

        <h3>Card Payment Declined</h3>
        <p><strong>Checklist:</strong></p>
        <ul>
          <li>✓ Sufficient balance in account</li>
          <li>✓ Card not frozen in app</li>
          <li>✓ Daily spending limit not exceeded</li>
          <li>✓ International transactions enabled (if abroad)</li>
          <li>✓ Correct PIN entered</li>
          <li>✓ Card not expired</li>
          <li>✓ Merchant accepts Mastercard</li>
        </ul>

        <p><strong>Still declining?</strong></p>
        <ul>
          <li>Try a different payment method temporarily</li>
          <li>Check with merchant if they're having issues</li>
          <li>Contact support with:</li>
          <li>- Merchant name</li>
          <li>- Transaction amount</li>
          <li>- Error message received</li>
        </ul>

        <h2>Account & Verification Issues</h2>

        <h3>KYC Verification Rejected</h3>
        <p><strong>Common reasons and fixes:</strong></p>

        <p><strong>1. Poor photo quality</strong></p>
        <ul>
          <li>Take photo in good lighting</li>
          <li>Ensure all four corners of ID are visible</li>
          <li>Avoid glare, shadows, or blur</li>
          <li>Use plain contrasting background</li>
          <li>Keep ID flat (no bending or folding)</li>
        </ul>

        <p><strong>2. Name mismatch</strong></p>
        <ul>
          <li>Name must match exactly with BVN records</li>
          <li>Include middle names if present in BVN</li>
          <li>Check for spelling errors</li>
          <li>Use full legal name, not nicknames</li>
        </ul>

        <p><strong>3. BVN issues</strong></p>
        <ul>
          <li>Verify correct 11-digit BVN</li>
          <li>Ensure BVN is not linked to another Paychipa account</li>
          <li>Update BVN details at your bank if information is incorrect</li>
        </ul>

        <p><strong>4. Selfie verification failed</strong></p>
        <ul>
          <li>Face must be clearly visible</li>
          <li>Remove glasses/face coverings</li>
          <li>Good lighting (natural light works best)</li>
          <li>Look directly at camera</li>
          <li>Don't use old photos - must be live selfie</li>
        </ul>

        <h3>Account Restricted/Suspended</h3>
        <p><strong>Common reasons:</strong></p>
        <ul>
          <li>Suspicious activity detected</li>
          <li>Multiple failed login attempts</li>
          <li>Pending KYC verification</li>
          <li>Violation of terms of service</li>
          <li>Chargeback or fraud investigation</li>
        </ul>

        <p><strong>Solution:</strong></p>
        <ul>
          <li>Check email for notification from Paychipa</li>
          <li>Contact support immediately</li>
          <li>Provide requested documents</li>
          <li>Resolution time: 1-3 business days</li>
        </ul>

        <h3>Can't Link Bank Account</h3>
        <p><strong>Solution:</strong></p>
        <ul>
          <li>Ensure account number is correct</li>
          <li>Select correct bank from list</li>
          <li>Account must be in your name (matching BVN)</li>
          <li>Try again after a few minutes</li>
          <li>Some banks require manual verification - contact support</li>
        </ul>

        <h2>App Performance Issues</h2>

        <h3>App Keeps Crashing</h3>
        <p><strong>Solutions:</strong></p>
        <ol>
          <li><strong>Update app:</strong> Check Play Store/App Store for updates</li>
          <li><strong>Clear cache:</strong>
            <ul>
              <li>Android: Settings > Apps > Paychipa > Clear Cache</li>
              <li>iOS: Uninstall and reinstall app</li>
            </ul>
          </li>
          <li><strong>Free up storage:</strong> Ensure at least 500MB free space</li>
          <li><strong>Restart phone:</strong> Simple but often effective</li>
          <li><strong>Reinstall app:</strong> Uninstall and fresh install</li>
          <li><strong>Check OS version:</strong> Ensure phone OS is updated</li>
        </ol>

        <h3>App Running Slow</h3>
        <p><strong>Solutions:</strong></p>
        <ul>
          <li>Close other apps running in background</li>
          <li>Clear app cache</li>
          <li>Check internet connection speed</li>
          <li>Update to latest app version</li>
          <li>Restart your phone</li>
        </ul>

        <h3>Can't Download/Update App</h3>
        <p><strong>Solutions:</strong></p>
        <ul>
          <li>Check phone storage space</li>
          <li>Verify stable internet connection</li>
          <li>Try using WiFi instead of mobile data</li>
          <li>Clear Play Store/App Store cache</li>
          <li>Sign out and back into app store</li>
        </ul>

        <h2>Notifications Issues</h2>

        <h3>Not Receiving Transaction Alerts</h3>
        <p><strong>Solutions:</strong></p>
        <ol>
          <li><strong>Check app notification settings:</strong>
            <ul>
              <li>Paychipa app > Settings > Notifications</li>
              <li>Enable all transaction alerts</li>
            </ul>
          </li>
          <li><strong>Check phone notification settings:</strong>
            <ul>
              <li>Phone Settings > Apps > Paychipa > Notifications</li>
              <li>Ensure all notification types are allowed</li>
            </ul>
          </li>
          <li><strong>Enable SMS/Email alerts:</strong>
            <ul>
              <li>Go to Settings in app</li>
              <li>Enable SMS and Email notifications</li>
            </ul>
          </li>
          <li><strong>Check battery optimization:</strong>
            <ul>
              <li>Disable battery optimization for Paychipa</li>
              <li>Prevents phone from stopping notifications</li>
            </ul>
          </li>
        </ol>

        <h2>Card Issues</h2>

        <h3>Virtual Card Not Working Online</h3>
        <p><strong>Checklist:</strong></p>
        <ul>
          <li>Card has sufficient funds</li>
          <li>Card is not frozen</li>
          <li>Entered correct card details (number, CVV, expiry)</li>
          <li>Website accepts Mastercard</li>
          <li>Try 3D Secure authentication if prompted</li>
          <li>Disable VPN if active</li>
        </ul>

        <h3>Physical Card Not Received</h3>
        <p><strong>Timeline:</strong> 3-10 business days depending on location</p>
        <p><strong>If delayed:</strong></p>
        <ul>
          <li>Check order status in app</li>
          <li>Verify delivery address is correct</li>
          <li>Contact support after 10 business days</li>
          <li>Tracking number will be provided</li>
        </ul>

        <h3>ATM Won't Accept Card</h3>
        <p><strong>Solutions:</strong></p>
        <ul>
          <li>Check if card is activated</li>
          <li>Ensure card is not frozen</li>
          <li>Try a different ATM</li>
          <li>Clean card chip with soft cloth</li>
          <li>Check if you've exceeded daily withdrawal limit</li>
          <li>Verify sufficient balance (including ATM fees)</li>
        </ul>

        <h2>Contact Support</h2>

        <h3>Before Contacting Support, Have Ready:</h3>
        <ul>
          <li>Your registered phone number/email</li>
          <li>Transaction reference (if applicable)</li>
          <li>Screenshots of issue/error messages</li>
          <li>Date and time of issue</li>
          <li>Steps you've already tried</li>
        </ul>

        <h3>How to Contact Us:</h3>
        <ul>
          <li><strong>In-app chat:</strong> Fastest response (24/7)</li>
          <li><strong>Email:</strong> support@paychipa.com</li>
          <li><strong>Social media:</strong> @paychipa (Twitter, Instagram, Facebook)</li>
          <li><strong>Phone:</strong> Coming soon in 2025</li>
        </ul>

        <h3>Expected Response Times:</h3>
        <ul>
          <li>Chat: Within 5 minutes (24/7)</li>
          <li>Email: Within 2 hours (business hours)</li>
          <li>Complex issues: 24-48 hours</li>
          <li>Refunds: 3-5 business days</li>
        </ul>

        <h2>Preventive Tips</h2>

        <p>Avoid issues by:</p>
        <ul>
          <li>Keeping app updated to latest version</li>
          <li>Maintaining strong internet connection during transactions</li>
          <li>Setting up transaction limits</li>
          <li>Enabling two-factor authentication</li>
          <li>Regularly checking transaction history</li>
          <li>Keeping phone number and email updated</li>
          <li>Not sharing PIN, password, or OTP with anyone</li>
          <li>Reading transaction summaries before confirming</li>
        </ul>

        <h2>Emergency Situations</h2>

        <h3>Unauthorized Transaction</h3>
        <p><strong>Immediate actions:</strong></p>
        <ol>
          <li>Freeze all cards in app immediately</li>
          <li>Change password and PIN</li>
          <li>Enable 2FA if not already active</li>
          <li>Contact support URGENTLY with transaction details</li>
          <li>File a dispute within 24 hours</li>
          <li>Check for other suspicious transactions</li>
        </ol>

        <h3>Lost Phone</h3>
        <p><strong>Immediate actions:</strong></p>
        <ol>
          <li>Use another device to log into Paychipa web (if available)</li>
          <li>Freeze all cards</li>
          <li>Change password</li>
          <li>Log out all sessions</li>
          <li>Monitor account for suspicious activity</li>
          <li>Contact support to secure account</li>
        </ol>

        <h2>Still Having Issues?</h2>
        <p>If none of these solutions work, please contact our support team with detailed information about your issue. We're here to help 24/7!</p>
      `
    },
    "request-pos-terminal": {
      title: "Requesting Your First POS Terminal",
      category: "Business Accounts",
      content: `
        <p>Getting your free POS terminal from Paychipa is simple. This guide walks you through the entire process, from request to installation.</p>

        <h2>Eligibility</h2>
        <p>To request a free POS terminal, you need:</p>
        <ul>
          <li>An active Paychipa business account</li>
          <li>Completed business verification</li>
          <li>A valid business address for delivery</li>
          <li>To process at least ₦50,000 in monthly transactions (waived for first 3 months)</li>
        </ul>

        <h2>Step-by-Step Request Process</h2>

        <h3>Step 1: Open a Business Account</h3>
        <p>If you don't have one already, open a Paychipa business account:</p>
        <ul>
          <li>Download the Paychipa app</li>
          <li>Select "Business Account" during signup</li>
          <li>Provide business information and documentation</li>
          <li>Complete business verification</li>
        </ul>

        <h3>Step 2: Request Your Terminal</h3>
        <ol>
          <li>Log into your Paychipa business account</li>
          <li>Go to "Business Tools"</li>
          <li>Select "POS Terminals"</li>
          <li>Click "Request Free Terminal"</li>
          <li>Choose your terminal model</li>
        </ol>

        <h3>Step 3: Provide Delivery Information</h3>
        <p>Enter your delivery details:</p>
        <ul>
          <li>Business address</li>
          <li>Contact person name</li>
          <li>Phone number for delivery updates</li>
          <li>Preferred delivery time</li>
          <li>Any special delivery instructions</li>
        </ul>

        <h3>Step 4: Confirm Your Request</h3>
        <p>Review all information and confirm. You'll receive:</p>
        <ul>
          <li>Instant confirmation via app notification</li>
          <li>Email confirmation with tracking details</li>
          <li>SMS with estimated delivery date</li>
        </ul>

        <h2>Terminal Models Available</h2>

        <h3>Paychipa Lite</h3>
        <p>Perfect for: Small shops, market stalls, mobile vendors</p>
        <ul>
          <li>Compact and portable</li>
          <li>All-day battery life</li>
          <li>4G connectivity</li>
          <li>Contactless payments supported</li>
          <li>Built-in receipt printer</li>
        </ul>

        <h3>Paychipa Pro</h3>
        <p>Perfect for: Restaurants, retail stores, service businesses</p>
        <ul>
          <li>Larger screen for easier use</li>
          <li>Extended battery (2-day life)</li>
          <li>WiFi + 4G connectivity</li>
          <li>Fast thermal printer</li>
          <li>Tip functionality</li>
          <li>Email receipt option</li>
        </ul>

        <h3>Paychipa Max</h3>
        <p>Perfect for: High-volume businesses, supermarkets, hotels</p>
        <ul>
          <li>Premium large touchscreen</li>
          <li>Dual SIM support</li>
          <li>Extra-fast processor</li>
          <li>Advanced reporting</li>
          <li>Multiple payment apps supported</li>
          <li>Customer-facing display option</li>
        </ul>

        <h2>Delivery Timeline</h2>
        <ul>
          <li><strong>Abuja:</strong> 24-48 hours</li>
          <li><strong>Lagos:</strong> 24-48 hours</li>
          <li><strong>Port Harcourt:</strong> 48-72 hours</li>
          <li><strong>Other major cities:</strong> 2-4 days</li>
          <li><strong>Remote areas:</strong> 3-7 days</li>
        </ul>

        <h2>What's Included</h2>
        <p>Your POS terminal package includes:</p>
        <ul>
          <li>POS terminal device</li>
          <li>Power adapter and cable</li>
          <li>Thermal paper rolls (3 rolls)</li>
          <li>SIM card (pre-installed and activated)</li>
          <li>Quick start guide</li>
          <li>Merchant agreement</li>
        </ul>

        <h2>Setup and Activation</h2>

        <h3>On Delivery</h3>
        <ol>
          <li>Verify the package contents</li>
          <li>Sign the delivery receipt</li>
          <li>The terminal is pre-configured and ready to use</li>
        </ol>

        <h3>First Use</h3>
        <ol>
          <li>Power on the terminal</li>
          <li>Log in using your Paychipa business credentials</li>
          <li>Terminal automatically syncs with your account</li>
          <li>You're ready to accept payments!</li>
        </ol>

        <h2>Making Your First Sale</h2>
        <ol>
          <li>Enter the transaction amount</li>
          <li>Customer inserts/taps their card</li>
          <li>Customer enters PIN (if required)</li>
          <li>Transaction processes instantly</li>
          <li>Receipt prints automatically</li>
          <li>Funds settle to your account within 24 hours</li>
        </ol>

        <h2>Fees and Charges</h2>
        <p>Terminal fees:</p>
        <ul>
          <li><strong>Terminal cost:</strong> FREE</li>
          <li><strong>Monthly rental:</strong> FREE (as long as you maintain minimum transaction volume)</li>
          <li><strong>Transaction fees:</strong> 1.5% (capped at ₦2,000 per transaction)</li>
          <li><strong>Settlement:</strong> Next business day</li>
        </ul>

        <h2>Support and Training</h2>
        <p>We provide comprehensive support:</p>
        <ul>
          <li>Video tutorials in the app</li>
          <li>24/7 customer support</li>
          <li>Free replacement if defective</li>
          <li>Software updates (automatic)</li>
          <li>Technical support hotline</li>
        </ul>

        <h2>Troubleshooting</h2>

        <h3>Terminal Won't Turn On</h3>
        <ul>
          <li>Charge for at least 2 hours</li>
          <li>Try a different power outlet</li>
          <li>Contact support if still not working</li>
        </ul>

        <h3>Transaction Failed</h3>
        <ul>
          <li>Check internet connectivity</li>
          <li>Verify customer has sufficient funds</li>
          <li>Try again or use a different card</li>
          <li>Contact support if repeated failures</li>
        </ul>

        <h3>Paper Jam</h3>
        <ul>
          <li>Open printer cover</li>
          <li>Remove jammed paper carefully</li>
          <li>Reload paper correctly</li>
          <li>Close cover firmly</li>
        </ul>

        <h2>Additional Terminals</h2>
        <p>Need more terminals? You can request additional terminals once you've been using your first one for 30 days and maintaining good transaction volume.</p>

        <h2>Need Help?</h2>
        <p>Contact our business support team:</p>
        <ul>
          <li>Email: business@paychipa.com</li>
          <li>In-app chat support</li>
          <li>Phone support (coming soon)</li>
        </ul>
      `
    }
  };

  const article = slug ? articles[slug] : null;

  if (!article) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl text-white mb-4">Article Not Found</h1>
          <Link to="/help">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full">
              Back to Help Center
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/help" className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Help Center
          </Link>

          <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 rounded-full border border-purple-400/30 mb-6">
            <HelpCircle className="w-3 h-3 text-purple-300" />
            <span className="text-xs text-purple-300">{article.category}</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            {article.title}
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div 
          className="prose prose-invert prose-lg max-w-none
            prose-headings:text-white prose-headings:font-semibold
            prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-6
            prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4
            prose-p:text-gray-300 prose-p:leading-relaxed prose-p:mb-6
            prose-ul:text-gray-300 prose-ul:my-6 prose-ul:list-disc prose-ul:pl-6
            prose-ol:text-gray-300 prose-ol:my-6 prose-ol:list-decimal prose-ol:pl-6
            prose-li:my-2
            prose-strong:text-white
            prose-a:text-purple-400 prose-a:no-underline hover:prose-a:text-purple-300"
          dangerouslySetInnerHTML={{ __html: article.content }}
        />

        {/* Helpful Feedback */}
        <div className="mt-16 pt-8 border-t border-white/10">
          <div className="text-center">
            <p className="text-lg text-white mb-4">Was this article helpful?</p>
            <div className="flex gap-4 justify-center">
              <Button
                variant="outline"
                className={`rounded-full ${
                  helpful === true
                    ? "bg-green-500/20 border-green-500/50 text-green-400"
                    : "bg-white/5 border-white/10 hover:bg-white/10 text-white"
                }`}
                onClick={() => setHelpful(true)}
              >
                <ThumbsUp className="w-4 h-4 mr-2" />
                Yes
              </Button>
              <Button
                variant="outline"
                className={`rounded-full ${
                  helpful === false
                    ? "bg-red-500/20 border-red-500/50 text-red-400"
                    : "bg-white/5 border-white/10 hover:bg-white/10 text-white"
                }`}
                onClick={() => setHelpful(false)}
              >
                <ThumbsDown className="w-4 h-4 mr-2" />
                No
              </Button>
            </div>
            {helpful !== null && (
              <p className="text-gray-400 mt-4">
                {helpful ? "Glad we could help!" : "We're sorry. Contact support for more help."}
              </p>
            )}
          </div>
        </div>

        {/* Contact Support CTA */}
        <div className="mt-8 bg-gradient-to-r from-purple-900/20 to-pink-900/20 backdrop-blur-xl rounded-3xl p-8 border border-white/10 text-center">
          <h3 className="text-2xl text-white mb-4">Still need help?</h3>
          <p className="text-gray-300 mb-6">Our support team is ready to assist you 24/7.</p>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8">
            Contact Support
          </Button>
        </div>
      </div>
    </div>
  );
}
