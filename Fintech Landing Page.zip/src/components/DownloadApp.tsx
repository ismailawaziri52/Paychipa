import { Button } from "./ui/button";
import { Apple, Smartphone, Sparkles, Zap, Shield, CreditCard, Twitter, Instagram, Facebook, Linkedin } from "lucide-react";

export function DownloadApp() {
  return (
    <div className="py-32 bg-black relative overflow-hidden">
      {/* Animated gradient orbs */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-purple-600/30 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-600/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#2D1E36]/20 rounded-full blur-3xl"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Main glassy card */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-12 shadow-2xl">
            <div className="text-center space-y-8">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full">
                <Sparkles className="w-4 h-4 text-purple-300" />
                <span className="text-sm text-white">Launching Soon</span>
              </div>
              
              {/* Title */}
              <div className="space-y-4">
                <h2 className="text-5xl sm:text-6xl lg:text-7xl text-white">
                  Coming Soon
                </h2>
                <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
                  We're putting the finishing touches on Paychipa. Join the waitlist to be the first to know when we launch.
                </p>
              </div>
              
              {/* App Store Badges */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md text-white px-8 py-4 rounded-2xl border border-white/20 cursor-not-allowed">
                  <Apple className="h-8 w-8" />
                  <div className="text-left">
                    <div className="text-xs text-gray-300">Coming to</div>
                    <div className="text-base">App Store</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md text-white px-8 py-4 rounded-2xl border border-white/20 cursor-not-allowed">
                  <Smartphone className="h-8 w-8" />
                  <div className="text-left">
                    <div className="text-xs text-gray-300">Coming to</div>
                    <div className="text-base">Google Play</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-lg text-white mb-2">Lightning Fast</h3>
              <p className="text-sm text-gray-400">Instant transfers and settlements. Money moves at the speed of light.</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-lg text-white mb-2">100% Secure</h3>
              <p className="text-sm text-gray-400">Advanced security measures to keep your transactions and data safe.</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <CreditCard className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-lg text-white mb-2">Free Everything</h3>
              <p className="text-sm text-gray-400">Free cards, free POS, zero setup fees. Banking without the burden.</p>
            </div>
          </div>
          
          {/* Social Media Follow */}
          <div className="mt-16 space-y-6">
            <div className="text-center">
              <p className="text-lg text-white mb-4">Stay updated on our launch</p>
              <p className="text-sm text-gray-400 mb-6">Follow us @paychipa on social media for exclusive updates, tips, and launch announcements</p>
              <div className="flex gap-4 justify-center">
                <a href="https://twitter.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/5 border border-white/10 hover:border-blue-500 hover:bg-blue-500/10 rounded-full flex items-center justify-center transition-all group" aria-label="Follow @paychipa on Twitter/X">
                  <Twitter className="h-5 w-5 text-gray-400 group-hover:text-blue-400" />
                </a>
                <a href="https://instagram.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/5 border border-white/10 hover:border-pink-500 hover:bg-pink-500/10 rounded-full flex items-center justify-center transition-all group" aria-label="Follow @paychipa on Instagram">
                  <Instagram className="h-5 w-5 text-gray-400 group-hover:text-pink-400" />
                </a>
                <a href="https://facebook.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/5 border border-white/10 hover:border-purple-500 hover:bg-purple-500/10 rounded-full flex items-center justify-center transition-all group" aria-label="Follow @paychipa on Facebook">
                  <Facebook className="h-5 w-5 text-gray-400 group-hover:text-purple-400" />
                </a>
                <a href="https://linkedin.com/company/paychipa" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-white/5 border border-white/10 hover:border-blue-500 hover:bg-blue-500/10 rounded-full flex items-center justify-center transition-all group" aria-label="Follow @paychipa on LinkedIn">
                  <Linkedin className="h-5 w-5 text-gray-400 group-hover:text-blue-400" />
                </a>
              </div>
            </div>
            
            {/* Timeline indicator */}
            <div className="text-center">
              <div className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                  <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                </div>
                <span className="text-sm text-gray-300 ml-2">Expected Launch: 2026</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
