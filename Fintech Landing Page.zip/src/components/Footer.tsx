import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";
import logo from "figma:asset/40129bf43fa7da5796f6f47604326ccc122652dc.png";

export function Footer() {
  return (
    <footer className="bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="inline-block -ml-4 sm:-ml-6 lg:-ml-8">
              <img 
                src={logo} 
                alt="Paychipa" 
                className="h-24 w-auto" 
              />
            </Link>
            <p className="text-gray-400 leading-relaxed max-w-sm">
              Making payments simple and accessible for everyone in Nigeria. Bank smarter with Paychipa.
            </p>
            <div className="flex gap-3">
              <a href="https://facebook.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 border border-white/10 hover:border-purple-500 hover:bg-purple-500/10 rounded-full flex items-center justify-center transition-colors group" aria-label="Follow @paychipa on Facebook">
                <Facebook className="h-5 w-5 text-gray-400 group-hover:text-purple-400" />
              </a>
              <a href="https://twitter.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 border border-white/10 hover:border-purple-500 hover:bg-purple-500/10 rounded-full flex items-center justify-center transition-colors group" aria-label="Follow @paychipa on Twitter/X">
                <Twitter className="h-5 w-5 text-gray-400 group-hover:text-purple-400" />
              </a>
              <a href="https://instagram.com/paychipa" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 border border-white/10 hover:border-purple-500 hover:bg-purple-500/10 rounded-full flex items-center justify-center transition-colors group" aria-label="Follow @paychipa on Instagram">
                <Instagram className="h-5 w-5 text-gray-400 group-hover:text-purple-400" />
              </a>
              <a href="https://linkedin.com/company/paychipa" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 border border-white/10 hover:border-purple-500 hover:bg-purple-500/10 rounded-full flex items-center justify-center transition-colors group" aria-label="Follow @paychipa on LinkedIn">
                <Linkedin className="h-5 w-5 text-gray-400 group-hover:text-purple-400" />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-white mb-4">Products</h3>
            <ul className="space-y-3 text-sm">
              <li><Link to="/personal" className="text-gray-400 hover:text-white transition-colors">Personal Account</Link></li>
              <li><Link to="/business" className="text-gray-400 hover:text-white transition-colors">Business Account</Link></li>
              <li><Link to="/pos-terminals" className="text-gray-400 hover:text-white transition-colors">POS Terminals</Link></li>
              <li><Link to="/cards" className="text-gray-400 hover:text-white transition-colors">Cards</Link></li>
              <li><Link to="/savings" className="text-gray-400 hover:text-white transition-colors">Savings</Link></li>
              <li><Link to="/loans" className="text-gray-400 hover:text-white transition-colors">Loans</Link></li>
              <li><Link to="/escrow" className="text-gray-400 hover:text-white transition-colors">Escrow</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white mb-4">Company</h3>
            <ul className="space-y-3 text-sm">
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/careers" className="text-gray-400 hover:text-white transition-colors">Careers</Link></li>
              <li><Link to="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link></li>
              <li><Link to="/press" className="text-gray-400 hover:text-white transition-colors">Press</Link></li>
              <li><Link to="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2 text-gray-400">
                <Mail className="h-4 w-4 mt-0.5 flex-shrink-0 text-purple-400" />
                <a href="mailto:hello@paychipa.com" className="hover:text-white transition-colors">
                  hello@paychipa.com
                </a>
              </li>
              <li className="flex items-start gap-2 text-gray-400">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0 text-purple-400" />
                <a href="tel:+2349012345678" className="hover:text-white transition-colors">
                  +234 901 234 5678
                </a>
              </li>
              <li className="flex items-start gap-2 text-gray-400">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-purple-400" />
                <span>Abuja, Nigeria</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
            <p>© 2025 Paychipa. All rights reserved.</p>
            <div className="flex gap-6">
              <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
              <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
              <Link to="/security" className="hover:text-white transition-colors">Security</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
