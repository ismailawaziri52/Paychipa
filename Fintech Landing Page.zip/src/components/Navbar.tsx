import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import { Menu, X, ChevronDown } from "lucide-react";
import logo from "figma:asset/40129bf43fa7da5796f6f47604326ccc122652dc.png";
import { Waitlist } from "./Waitlist";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);
  const [companyOpen, setCompanyOpen] = useState(false);

  return (
    <>
    <nav className="fixed top-0 left-0 right-0 bg-black/80 backdrop-blur-xl border-b border-white/10 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center -ml-4 sm:-ml-6 lg:-ml-8">
            <Link to="/">
              <img src={logo} alt="Paychipa" className="h-24 w-auto" />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {/* Products Dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 text-gray-300 hover:text-white transition-colors">
                Products
                <ChevronDown className="w-4 h-4" />
              </button>
              <div className="absolute top-full left-0 mt-2 w-56 bg-black/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all py-2">
                <Link to="/personal" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Personal Account
                </Link>
                <Link to="/business" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Business Account
                </Link>
                <Link to="/pos-terminals" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  POS Terminals
                </Link>
                <Link to="/cards" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Cards
                </Link>
                <Link to="/savings" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Savings
                </Link>
                <Link to="/loans" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Loans
                </Link>
                <Link to="/escrow" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Escrow
                </Link>
              </div>
            </div>

            {/* Company Dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 text-gray-300 hover:text-white transition-colors">
                Company
                <ChevronDown className="w-4 h-4" />
              </button>
              <div className="absolute top-full left-0 mt-2 w-48 bg-black/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all py-2">
                <Link to="/about" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  About Us
                </Link>
                <Link to="/contact" className="block px-6 py-3 text-gray-300 hover:bg-purple-500/10 hover:text-white transition-colors">
                  Contact
                </Link>
              </div>
            </div>
          </div>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <Button 
              onClick={() => setIsWaitlistOpen(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 rounded-full shadow-lg shadow-purple-500/50"
            >
              Join Waitlist
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden py-6 border-t border-white/10">
            <div className="flex flex-col gap-4">
              {/* Products Section */}
              <div>
                <button 
                  onClick={() => setProductsOpen(!productsOpen)}
                  className="flex items-center justify-between w-full text-gray-300 hover:text-white transition-colors py-2"
                >
                  <span>Products</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${productsOpen ? 'rotate-180' : ''}`} />
                </button>
                {productsOpen && (
                  <div className="pl-4 mt-2 space-y-2">
                    <Link to="/personal" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Personal Account
                    </Link>
                    <Link to="/business" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Business Account
                    </Link>
                    <Link to="/pos-terminals" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      POS Terminals
                    </Link>
                    <Link to="/cards" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Cards
                    </Link>
                    <Link to="/savings" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Savings
                    </Link>
                    <Link to="/loans" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Loans
                    </Link>
                    <Link to="/escrow" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Escrow
                    </Link>
                  </div>
                )}
              </div>

              {/* Company Section */}
              <div>
                <button 
                  onClick={() => setCompanyOpen(!companyOpen)}
                  className="flex items-center justify-between w-full text-gray-300 hover:text-white transition-colors py-2"
                >
                  <span>Company</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${companyOpen ? 'rotate-180' : ''}`} />
                </button>
                {companyOpen && (
                  <div className="pl-4 mt-2 space-y-2">
                    <Link to="/about" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      About Us
                    </Link>
                    <Link to="/contact" onClick={() => setIsOpen(false)} className="block text-gray-400 hover:text-white py-2">
                      Contact
                    </Link>
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
                <Button 
                  onClick={() => {
                    setIsOpen(false);
                    setIsWaitlistOpen(true);
                  }}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white w-full rounded-full shadow-lg shadow-purple-500/50"
                >
                  Join Waitlist
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
    
    <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </>
  );
}
