import { Smartphone, CreditCard, Zap, PiggyBank, Receipt, Users, TrendingUp, Shield, BadgeCheck } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Instant Transfers",
    description: "Send money to any bank in Nigeria instantly at zero cost.",
    gradient: "from-gray-400 to-slate-500"
  },
  {
    icon: CreditCard,
    title: "Virtual & Physical Cards",
    description: "Get instant virtual cards and physical debit cards for all your payments.",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: PiggyBank,
    title: "Smart Savings",
    description: "Automated savings with up to 15% annual interest. Reach your goals faster.",
    gradient: "from-green-500 to-emerald-600"
  },
  {
    icon: Receipt,
    title: "Bill Payments",
    description: "Pay for airtime, data, electricity, cable TV, and more in seconds.",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: BadgeCheck,
    title: "X & Meta Verification",
    description: "Get verified on X (Twitter) Blue and Meta platforms directly from the app.",
    gradient: "from-blue-400 to-indigo-500"
  },
  {
    icon: Users,
    title: "Business Tools",
    description: "Accept payments, manage inventory, and track sales with ease.",
    gradient: "from-indigo-500 to-purple-600"
  },
  {
    icon: Smartphone,
    title: "POS Terminals",
    description: "Get POS machines for your business with instant settlement.",
    gradient: "from-pink-500 to-rose-500"
  },
  {
    icon: TrendingUp,
    title: "Loans & Credit",
    description: "Access instant loans up to ₦5M with flexible repayment options.",
    gradient: "from-gray-500 to-slate-600"
  },
  {
    icon: Shield,
    title: "Secure & Protected",
    description: "Advanced security measures to keep your transactions and data safe.",
    gradient: "from-teal-500 to-green-600"
  }
];

export function Features() {
  return (
    <div className="py-24 bg-black relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-600/5 to-transparent"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm border border-white/10 rounded-full text-sm text-purple-300 mb-4">
            All-in-One Platform
          </div>
          <h2 className="text-4xl sm:text-5xl text-white mb-4">
            Everything you need, one app
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            From everyday payments to business growth, Paychipa has you covered
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl hover:shadow-purple-500/10 hover:-translate-y-1 transition-all duration-300"
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                <feature.icon className="h-7 w-7 text-white" />
              </div>
              
              <h3 className="text-lg text-white mb-2">
                {feature.title}
              </h3>
              
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
