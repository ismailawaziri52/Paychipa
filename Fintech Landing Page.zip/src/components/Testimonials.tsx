import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Small Business Owners",
    role: "Retail & Services",
    content: "Free POS terminals that actually work, instant settlement, and zero setup fees. Finally, a payment solution designed for Nigerian businesses.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1655720360377-b97f6715e1ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwbWFuJTIwbW9iaWxlJTIwcGF5bWVudHxlbnwxfHx8fDE3NjA2ODUyNDd8MA&ixlib=rb-4.1.0&q=80&w=400&h=400&fit=crop"
  },
  {
    name: "Freelancers & Creatives",
    role: "Digital Entrepreneurs",
    content: "Virtual cards for online payments, instant transfers, and bill payments all in one app. Everything we need to run our businesses smoothly.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1710115529093-1188449565f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwd29tYW4lMjBzbWlsaW5nJTIwYnVzaW5lc3N8ZW58MXx8fHwxNzYwNjg1MjQ4fDA&ixlib=rb-4.1.0&q=80&w=400&h=400&fit=crop"
  },
  {
    name: "Everyday Nigerians",
    role: "Personal Banking",
    content: "Smart savings, automated transfers, and easy bill payments. Banking that actually makes our lives easier, not harder.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1657448759741-700b27b372da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdlcmlhbiUyMGVudHJlcHJlbmV1ciUyMGhhcHB5fGVufDF8fHx8MTc2MDY4NTI0OHww&ixlib=rb-4.1.0&q=80&w=400&h=400&fit=crop"
  }
];

export function Testimonials() {
  return (
    <div className="py-24 bg-black relative overflow-hidden">
      {/* Background gradients */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm border border-white/10 rounded-full text-sm text-purple-300 mb-4">
            Why Paychipa?
          </div>
          <h2 className="text-4xl sm:text-5xl text-white mb-4">
            Built for Nigerians
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Banking should be simple, fast, and accessible to everyone
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="relative bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl hover:shadow-purple-500/10 transition-all duration-300"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>
              
              <div className="flex items-center gap-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-14 h-14 rounded-full object-cover border-2 border-white/20 shadow-md"
                />
                <div>
                  <div className="text-white">{testimonial.name}</div>
                  <div className="text-sm text-gray-400">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
        

      </div>
    </div>
  );
}
