# 🚀 paychipa - Vercel Deployment Guide

Complete guide to deploy your paychipa fintech app to Vercel and connect paychipa.com domain.

---

## 📋 Prerequisites

✅ Vercel account (sign up at [vercel.com](https://vercel.com))  
✅ paychipa.com domain registered with Hostinger  
✅ Your Supabase credentials (already configured)  
✅ All project files from Figma Make

---

## 🎯 Deployment Options

### **Option A: Deploy via Vercel CLI (Fastest)**

#### Step 1: Install Vercel CLI
```bash
npm install -g vercel
```

#### Step 2: Navigate to Project Directory
```bash
cd /path/to/paychipa
```

#### Step 3: Install Dependencies
```bash
npm install
```

#### Step 4: Create `.env` File
Create a file named `.env` in the root directory:
```env
VITE_SUPABASE_URL=https://ycromgthpitsvmvrfxpv.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inljcm9tZ3RocGl0c3ZtdnJmeHB2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExNTE4MjcsImV4cCI6MjA3NjcyNzgyN30.Y5wBq7i2RX0aZQCHdQe-md52zaXO_pjjfhBVh5IN1Ss
```

#### Step 5: Test Locally (Optional)
```bash
npm run dev
```
Open http://localhost:3000 to verify everything works.

#### Step 6: Deploy to Vercel
```bash
vercel --prod
```

Follow the prompts:
- **Set up and deploy?** Yes
- **Which scope?** Your Vercel account
- **Link to existing project?** No
- **Project name?** paychipa
- **Directory?** ./
- **Override settings?** No

The CLI will deploy and give you a URL like: `https://paychipa.vercel.app`

---

### **Option B: Deploy via Vercel Dashboard**

#### Step 1: Prepare Your Code
1. Download all files from Figma Make
2. Ensure you have all the files including:
   - `package.json`
   - `vite.config.ts`
   - `tsconfig.json`
   - `vercel.json`
   - All `/components`, `/pages`, `/utils` folders

#### Step 2: Upload to GitHub (Recommended)
1. Create a new repository on GitHub
2. Upload all project files
3. Push to main branch

#### Step 3: Import to Vercel
1. Go to [vercel.com/new](https://vercel.com/new)
2. Click **"Import Git Repository"**
3. Select your GitHub repository
4. Vercel will auto-detect it's a Vite project

#### Step 4: Configure Environment Variables
In the Vercel dashboard, add:

| Key | Value |
|-----|-------|
| `VITE_SUPABASE_URL` | `https://ycromgthpitsvmvrfxpv.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inljcm9tZ3RocGl0c3ZtdnJmeHB2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExNTE4MjcsImV4cCI6MjA3NjcyNzgyN30.Y5wBq7i2RX0aZQCHdQe-md52zaXO_pjjfhBVh5IN1Ss` |

#### Step 5: Deploy
Click **"Deploy"** and wait 2-3 minutes.

---

## 🌐 Connect paychipa.com Domain

### Step 1: Add Domain in Vercel
1. Go to your project in Vercel dashboard
2. Click **Settings** → **Domains**
3. Add both domains:
   - `paychipa.com`
   - `www.paychipa.com`

### Step 2: Update DNS in Hostinger
Vercel will show you DNS records to add. Log into Hostinger:

#### For Root Domain (paychipa.com)
1. Go to **Domains** → **paychipa.com** → **DNS Zone**
2. Add **A Record**:
   ```
   Type: A
   Name: @
   Value: 76.76.21.21
   TTL: 14400 (or default)
   ```

#### For www Subdomain (www.paychipa.com)
3. Add **CNAME Record**:
   ```
   Type: CNAME
   Name: www
   Value: cname.vercel-dns.com
   TTL: 14400 (or default)
   ```

### Step 3: Wait for DNS Propagation
- **Time**: 1-48 hours (usually 2-6 hours)
- **Check status**: Use [dnschecker.org](https://dnschecker.org)

### Step 4: Verify in Vercel
Once DNS propagates, Vercel will automatically verify and issue SSL certificate.

---

## ✅ What Works After Deployment

✅ **All 14 pages** - Navigation, routing, everything  
✅ **Supabase backend** - Waitlist, contact forms save to database  
✅ **Admin dashboard** - Access at `paychipa.com/#/admin/dashboard`  
✅ **PWA functionality** - Users can install on mobile  
✅ **SEO meta tags** - Google indexing ready  
✅ **SSL certificate** - Automatic HTTPS from Vercel  
✅ **Global CDN** - Fast loading worldwide  
✅ **Auto-deploy** - Push to GitHub = auto deployment (if using Git)

---

## 🔧 Post-Deployment Checklist

### Test Everything
- [ ] Visit `paychipa.com` - Homepage loads
- [ ] Test navigation - All 14 pages work
- [ ] Submit waitlist form - Check `/admin/dashboard`
- [ ] Submit contact form - Verify in Supabase
- [ ] Test on mobile - Responsive design works
- [ ] Install PWA - Click "Add to Home Screen"
- [ ] Check social links - All point to @paychipa

### Update Settings
- [ ] Add Google Analytics (optional)
- [ ] Submit sitemap to Google Search Console
- [ ] Update social media bios with paychipa.com
- [ ] Test from Nigeria - VPN or ask a friend

---

## 📱 URLs After Deployment

| Page | URL |
|------|-----|
| Home | `paychipa.com/#/` |
| POS Terminals | `paychipa.com/#/pos-terminals` |
| Cards | `paychipa.com/#/cards` |
| Personal Account | `paychipa.com/#/personal` |
| Business Account | `paychipa.com/#/business` |
| Savings | `paychipa.com/#/savings` |
| Loans | `paychipa.com/#/loans` |
| Escrow | `paychipa.com/#/escrow` |
| About | `paychipa.com/#/about` |
| Contact | `paychipa.com/#/contact` |
| Careers | `paychipa.com/#/careers` |
| Blog | `paychipa.com/#/blog` |
| Press | `paychipa.com/#/press` |
| Help Center | `paychipa.com/#/help` |
| Admin Dashboard | `paychipa.com/#/admin/dashboard` |

**Note**: The `#` in URLs is from HashRouter - this is normal for static deployments!

---

## 🛠️ Troubleshooting

### Build Fails
**Error**: `Module not found`
**Solution**: Run `npm install` locally first, check for missing dependencies

### Environment Variables Not Working
**Error**: Supabase connection fails
**Solution**: Verify you added `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Vercel dashboard

### Domain Not Connecting
**Error**: "This domain is not verified"
**Solution**: 
1. Check DNS settings in Hostinger match Vercel's instructions exactly
2. Wait 24 hours for DNS propagation
3. Remove and re-add domain in Vercel

### 404 on Page Refresh
**Error**: Refreshing a page shows 404
**Solution**: Already fixed with `vercel.json` rewrites - all routes redirect to `index.html`

### Admin Dashboard Not Working
**Error**: Can't access `/admin/dashboard`
**Solution**: Use `paychipa.com/#/admin/dashboard` (note the `#`)

---

## 🚀 Next Steps After Deployment

1. **Share your link**: Post paychipa.com on Twitter, Instagram, LinkedIn
2. **Collect signups**: Monitor waitlist growth in admin dashboard
3. **Gather feedback**: Share with friends, family, potential users
4. **Track analytics**: Add Google Analytics to see visitor data
5. **Plan for 2026 launch**: Start working on CBN licensing, banking partnerships

---

## 🔐 Security Notes

✅ **Supabase keys are safe** - They're meant to be public (anon key)  
✅ **HTTPS enforced** - Vercel provides free SSL  
✅ **Environment variables** - Sensitive data in Vercel dashboard, not code  
✅ **Row Level Security** - Your Supabase database has RLS enabled  

---

## 📞 Support

**Vercel Issues**: [vercel.com/support](https://vercel.com/support)  
**Supabase Issues**: [supabase.com/support](https://supabase.com/support)  
**DNS Issues**: Hostinger support chat  

---

## 🎉 Success!

Once deployed, your paychipa fintech app will be live at **paychipa.com** for the world to see!

**Share it proudly:**
- Twitter: "Just launched paychipa.com - Smart payments for Africans! 🚀 Join our waitlist for 2026. #Fintech #Nigeria @paychipa"
- Instagram: Screenshot your homepage + "Coming 2026! Link in bio 💳"
- LinkedIn: Professional announcement about your fintech startup

---

**Built with**: React + Vite + Tailwind CSS + Supabase + Vercel  
**Powered by**: Stripe + Flutterwave  
**Made for**: Everyday Nigerians 🇳🇬
