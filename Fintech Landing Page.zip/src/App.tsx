import { useEffect } from "react";
import { HashRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { Toaster } from "./components/ui/sonner";
import { PWAInstallPrompt } from "./components/PWAInstallPrompt";
import { HomePage } from "./pages/HomePage";
import { PersonalAccountPage } from "./pages/PersonalAccountPage";
import { BusinessAccountPage } from "./pages/BusinessAccountPage";
import { POSTerminalsPage } from "./pages/POSTerminalsPage";
import { CardsPage } from "./pages/CardsPage";
import { SavingsPage } from "./pages/SavingsPage";
import { LoansPage } from "./pages/LoansPage";
import { EscrowPage } from "./pages/EscrowPage";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { CareersPage } from "./pages/CareersPage";
import { BlogPage } from "./pages/BlogPage";
import { BlogPostPage } from "./pages/BlogPostPage";
import { PressPage } from "./pages/PressPage";
import { PressReleasePage } from "./pages/PressReleasePage";
import { HelpCenterPage } from "./pages/HelpCenterPage";
import { HelpArticlePage } from "./pages/HelpArticlePage";
import { PrivacyPolicyPage } from "./pages/PrivacyPolicyPage";
import { TermsOfServicePage } from "./pages/TermsOfServicePage";
import { SecurityPage } from "./pages/SecurityPage";
import { AdminDashboardPage } from "./pages/AdminDashboardPage";
import { ScrollToTop } from "./components/ScrollToTop";
import { initPWA } from "./utils/pwa";

export default function App() {
  // Initialize PWA on app mount
  useEffect(() => {
    initPWA();
  }, []);

  return (
    <Router>
      <ScrollToTop />
      <div className="size-full">
        <Navbar />
        <main className="pt-16">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/personal" element={<PersonalAccountPage />} />
            <Route path="/business" element={<BusinessAccountPage />} />
            <Route path="/pos-terminals" element={<POSTerminalsPage />} />
            <Route path="/cards" element={<CardsPage />} />
            <Route path="/savings" element={<SavingsPage />} />
            <Route path="/loans" element={<LoansPage />} />
            <Route path="/escrow" element={<EscrowPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/careers" element={<CareersPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<BlogPostPage />} />
            <Route path="/press" element={<PressPage />} />
            <Route path="/press/:slug" element={<PressReleasePage />} />
            <Route path="/help" element={<HelpCenterPage />} />
            <Route path="/help/:slug" element={<HelpArticlePage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsOfServicePage />} />
            <Route path="/security" element={<SecurityPage />} />
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
        <Toaster position="top-center" />
        <PWAInstallPrompt />
      </div>
    </Router>
  );
}
