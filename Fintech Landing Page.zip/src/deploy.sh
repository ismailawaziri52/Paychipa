#!/bin/bash

# paychipa Vercel Deployment Script
# This script helps you deploy paychipa to Vercel with one command

echo "🚀 paychipa Deployment Script"
echo "=============================="
echo ""

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null
then
    echo "❌ Vercel CLI not found. Installing..."
    npm install -g vercel
    echo "✅ Vercel CLI installed!"
    echo ""
fi

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    echo "✅ Dependencies installed!"
    echo ""
fi

# Test build locally
echo "🔨 Testing build..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo ""
else
    echo "❌ Build failed. Please fix errors before deploying."
    exit 1
fi

# Deploy to Vercel
echo "🚀 Deploying to Vercel..."
echo ""
echo "You'll be asked a few questions:"
echo "1. Set up and deploy? → Y (Yes)"
echo "2. Which scope? → Select your account"
echo "3. Link to existing project? → N (No)"
echo "4. Project name? → paychipa (or press Enter)"
echo "5. Directory? → Press Enter"
echo "6. Override settings? → N (No)"
echo ""
echo "Starting deployment in 3 seconds..."
sleep 3

vercel --prod

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 SUCCESS! Your paychipa app is now live!"
    echo ""
    echo "Next steps:"
    echo "1. Copy the deployment URL from above"
    echo "2. Go to Vercel dashboard to add your custom domain"
    echo "3. Configure DNS in Hostinger"
    echo ""
    echo "Full instructions: See VERCEL-DEPLOYMENT.md"
else
    echo ""
    echo "❌ Deployment failed. Check the errors above."
fi
