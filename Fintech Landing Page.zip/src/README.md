# 🇳🇬 paychipa - Smart Payments for Africans

Next-generation fintech platform for everyday Nigerians. POS terminals, cards, transfers, savings, loans & more.

**Status**: Pre-launch | **Launch**: 2026 | **Powered by**: Stripe + Flutterwave

---

## 🚀 Quick Start

### Local Development

```bash
# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Start development server
npm run dev
```

Visit http://localhost:3000

### Build for Production

```bash
npm run build
npm run preview
```

---

## 📦 Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS v4
- **Routing**: React Router v6 (HashRouter)
- **UI Components**: shadcn/ui + Radix UI
- **Backend**: Supabase (Database + Edge Functions)
- **Icons**: Lucide React
- **Charts**: Recharts
- **Deployment**: Vercel

---

## 🌐 Deployment

### Deploy to Vercel

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Deploy**
   ```bash
   vercel --prod
   ```

3. **Add Environment Variables** (in Vercel dashboard)
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

4. **Connect Domain** (paychipa.com)
   - Add domain in Vercel dashboard
   - Update DNS in Hostinger:
     - A Record: `@` → `76.76.21.21`
     - CNAME: `www` → `cname.vercel-dns.com`

**Full deployment guide**: See `/VERCEL-DEPLOYMENT.md`

---

## 📱 Features

✅ **14 Pages**: Home, Products, About, Blog, Press, Help, Admin  
✅ **PWA Support**: Installable on mobile & desktop  
✅ **SEO Optimized**: Meta tags, sitemap, robots.txt  
✅ **Backend Integration**: Supabase for waitlist & contact forms  
✅ **Admin Dashboard**: View all submissions at `/admin/dashboard`  
✅ **Glassmorphism Design**: Black glassy aesthetic with purple/pink gradients  
✅ **Responsive**: Mobile-first design

---

## 📂 Project Structure

```
paychipa/
├── components/          # Reusable React components
├── pages/              # Page components (14 pages)
├── public/             # Static assets (PWA, SEO files)
├── styles/             # Tailwind CSS configuration
├── utils/              # Utilities (PWA, Supabase)
├── supabase/           # Backend server functions
├── App.tsx             # Main app component
├── main.tsx            # Entry point
└── package.json        # Dependencies
```

---

## 🔐 Environment Variables

Create a `.env` file with:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these from your Supabase project settings.

---

## 📄 Pages

| Route | Page |
|-------|------|
| `/` | Home |
| `/personal` | Personal Account |
| `/business` | Business Account |
| `/pos-terminals` | POS Terminals |
| `/cards` | Virtual & Physical Cards |
| `/savings` | Savings |
| `/loans` | Loans |
| `/escrow` | Escrow Services |
| `/about` | About Us |
| `/contact` | Contact |
| `/careers` | Careers |
| `/blog` | Blog |
| `/press` | Press Releases |
| `/help` | Help Center |
| `/admin/dashboard` | Admin Dashboard |

---

## 🛠️ Available Scripts

```bash
npm run dev       # Start development server
npm run build     # Build for production
npm run preview   # Preview production build
```

---

## 🌍 Social Media

All platforms: **@paychipa**

- Twitter: [@paychipa](https://twitter.com/paychipa)
- Instagram: [@paychipa](https://instagram.com/paychipa)
- Facebook: [@paychipa](https://facebook.com/paychipa)
- LinkedIn: [@paychipa](https://linkedin.com/company/paychipa)
- TikTok: [@paychipa](https://tiktok.com/@paychipa)

---

## 📍 Location

**Headquarters**: Abuja, Nigeria 🇳🇬

---

## ⚠️ Legal Notice

**paychipa is a pre-launch fintech startup.**

- Not yet licensed by Central Bank of Nigeria (CBN)
- Not yet insured by Nigeria Deposit Insurance Corporation (NDIC)
- Expected launch: 2026
- Currently collecting waitlist signups

---

## 📞 Support

- **Email**: hello@paychipa.com
- **Website**: [paychipa.com](https://paychipa.com)

---

## 📜 License

© 2025 paychipa. All rights reserved.

---

**Built with ❤️ for Africans, by Africans.**
