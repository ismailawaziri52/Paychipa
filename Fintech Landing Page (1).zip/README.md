
  # Fintech Landing Page

  This is a code bundle for Fintech Landing Page. The original project is available at https://www.figma.com/design/GfSYz6F4T1HAoJwcL7brir/Fintech-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  