# 🚀 Deploy paychipa in 3 Steps (No GitHub Required!)

## ⚡ Super Fast Method (5 Minutes)

### Step 1: Install Vercel CLI

**Mac/Linux:**
```bash
npm install -g vercel
```

**Windows:**
```cmd
npm install -g vercel
```

Wait for installation to complete (30 seconds - 1 minute).

---

### Step 2: Login to Vercel

```bash
vercel login
```

This will:
1. Open your browser
2. Ask you to sign in (choose GitHub, GitLab, Bitbucket, or Email)
3. Confirm authorization
4. Return to terminal when done

---

### Step 3: Deploy!

**Mac/Linux:**
```bash
chmod +x deploy.sh
./deploy.sh
```

**Windows:**
```cmd
deploy.bat
```

**OR manually:**
```bash
vercel --prod
```

The script will:
- ✅ Install dependencies
- ✅ Test your build
- ✅ Deploy to Vercel
- ✅ Give you a live URL!

---

## 📋 What You'll Be Asked

When deploying, Vercel CLI asks 6 quick questions:

| Question | Answer |
|----------|--------|
| **Set up and deploy "~/path/paychipa"?** | Type `Y` and press Enter |
| **Which scope do you want to deploy to?** | Select your Vercel account (use arrow keys) |
| **Link to existing project?** | Type `N` (No) |
| **What's your project's name?** | Type `paychipa` or press Enter |
| **In which directory is your code located?** | Press Enter (uses `./`) |
| **Want to modify these settings?** | Type `N` (No) |

That's it! Vercel will deploy and give you a URL like:
```
https://paychipa.vercel.app
```

---

## 🌐 Connect paychipa.com Domain

### In Vercel Dashboard:

1. Go to [vercel.com/dashboard](https://vercel.com/dashboard)
2. Click your **paychipa** project
3. Click **Settings** → **Domains**
4. Click **Add Domain**
5. Type: `paychipa.com` → Click **Add**
6. Click **Add Domain** again
7. Type: `www.paychipa.com` → Click **Add**

### In Hostinger:

1. Login to [hostinger.com](https://hostinger.com)
2. Go to **Domains** → **paychipa.com**
3. Click **DNS Zone** or **Manage DNS**
4. **Delete** any existing A or CNAME records for `@` and `www`
5. **Add** these new records:

#### A Record:
```
Type: A
Name: @ (or blank)
Points to: 76.76.21.21
TTL: 14400 (or Auto)
```

#### CNAME Record:
```
Type: CNAME
Name: www
Points to: cname.vercel-dns.com
TTL: 14400 (or Auto)
```

6. Click **Save**
7. **Wait 2-24 hours** for DNS to update
8. Check status at [dnschecker.org/paychipa.com](https://dnschecker.org/#A/paychipa.com)

---

## ✅ Test Your Deployment

Once live, test these:

```
✅ https://paychipa.vercel.app (or paychipa.com after DNS)
✅ Try all 14 pages
✅ Submit a waitlist form
✅ Check admin dashboard: /#/admin/dashboard
✅ Test on mobile
✅ Install as PWA (Add to Home Screen)
```

---

## 🎯 Deployment Checklist

**Before deploying:**
- [x] `.env` file created ✅
- [x] `.env.example` exists ✅
- [x] `.gitignore` configured ✅
- [x] All files ready ✅

**After deploying:**
- [ ] Test homepage loads
- [ ] Test all 14 pages work
- [ ] Submit test waitlist entry
- [ ] Check admin dashboard shows data
- [ ] Test Supabase connection
- [ ] Add custom domain in Vercel
- [ ] Update DNS in Hostinger
- [ ] Wait for DNS propagation
- [ ] Test paychipa.com works
- [ ] Share on social media! 🎉

---

## 🆘 Troubleshooting

### "Command not found: vercel"
**Solution:** 
```bash
npm install -g vercel
```
Then try again.

### "Build failed"
**Solution:**
1. Test locally first:
   ```bash
   npm install
   npm run build
   ```
2. Fix any errors shown
3. Try deploying again

### "Invalid project name"
**Solution:** Just press Enter when asked for project name.

### Environment Variables Not Working
**After deployment:**
1. Go to Vercel dashboard
2. Your project → **Settings** → **Environment Variables**
3. Add:
   - `VITE_SUPABASE_URL` = `https://ycromgthpitsvmvrfxpv.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inljcm9tZ3RocGl0c3ZtdnJmeHB2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExNTE4MjcsImV4cCI6MjA3NjcyNzgyN30.Y5wBq7i2RX0aZQCHdQe-md52zaXO_pjjfhBVh5IN1Ss`
4. Redeploy: `vercel --prod`

### Domain Not Connecting
**Solution:**
1. Wait 24 hours minimum
2. Check DNS with: [dnschecker.org](https://dnschecker.org/#A/paychipa.com)
3. Verify DNS records match exactly
4. Contact Hostinger support if still not working

---

## 🎉 You're Done!

**Once deployed, your paychipa fintech app is LIVE!**

Share it:
- **Twitter:** "Just launched paychipa.com 🚀 Smart payments for Nigerians! Join the waitlist for 2026. #Fintech #Nigeria"
- **Instagram:** Post screenshot + "Coming 2026! paychipa.com"
- **LinkedIn:** Professional announcement about your fintech startup

**Next steps:**
1. Monitor waitlist signups in admin dashboard
2. Collect feedback from early users
3. Plan for 2026 full launch with CBN licensing

---

## 📞 Need Help?

- **Vercel Issues:** [vercel.com/support](https://vercel.com/support)
- **DNS Issues:** Hostinger support chat
- **Supabase Issues:** Check admin dashboard

---

**Ready?** Run the deploy script NOW! 🚀🇳🇬

```bash
# Mac/Linux
./deploy.sh

# Windows
deploy.bat

# Or manually
vercel --prod
```
