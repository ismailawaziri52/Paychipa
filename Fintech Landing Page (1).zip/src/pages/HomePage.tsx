import { SEO } from "../components/SEO";
import { Hero } from "../components/Hero";
import { Features } from "../components/Features";
import { ProductShowcase } from "../components/ProductShowcase";
import { Testimonials } from "../components/Testimonials";
import { DownloadApp } from "../components/DownloadApp";

export function HomePage() {
  return (
    <>
      <SEO />
      <Hero />
      <Features />
      <ProductShowcase />
      <Testimonials />
      <DownloadApp />
    </>
  );
}
