import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, DollarSign, Clock, Shield, Calculator, Zap, TrendingDown } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function LoansPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Quick Loans - Paychipa | Personal & Business Loans in Nigeria"
        description="Get instant loans up to ₦5M with flexible repayment. Low interest rates, no hidden fees, instant approval. Personal loans, business loans, and salary advances."
        keywords="quick loan nigeria, instant loan, personal loan nigeria, business loan, salary advance, low interest loan"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-cyan-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
              <DollarSign className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-blue-300">Instant Loans</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Get instant loans
              <span className="block bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
                up to ₦5 Million
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Fast approval, low interest rates, and flexible repayment terms. Get the money you need in minutes, not days.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white group px-8 rounded-full shadow-xl shadow-blue-500/50"
              >
                Apply for Loan
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
              >
                Check Eligibility
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Instant approval</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Low interest</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">No collateral</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Loan Options */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Choose your loan amount
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Flexible loan options with competitive interest rates
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Quick Loan */}
            <div className="bg-gradient-to-br from-blue-600/10 to-cyan-600/10 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-8 hover:from-blue-600/20 hover:to-cyan-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Quick Loan</h3>
              <div className="text-3xl text-blue-400 mb-2">₦10K - ₦500K</div>
              <p className="text-gray-400 mb-6">
                Perfect for emergencies and small expenses. Get approved in seconds.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">5% monthly interest</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">1-3 months repayment</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Instant approval</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">No paperwork</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-full shadow-lg shadow-blue-500/50"
              >
                Apply Now
              </Button>
            </div>

            {/* Standard Loan */}
            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 hover:from-purple-600/20 hover:to-pink-600/20 transition-all relative">
              <div className="absolute top-4 right-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs px-3 py-1 rounded-full">
                Most Popular
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Standard Loan</h3>
              <div className="text-3xl text-purple-400 mb-2">₦500K - ₦2M</div>
              <p className="text-gray-400 mb-6">
                For larger expenses with better rates and longer repayment periods.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">3% monthly interest</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">3-12 months repayment</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Fast approval</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Flexible terms</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full shadow-lg shadow-purple-500/50"
              >
                Apply Now
              </Button>
            </div>

            {/* Premium Loan */}
            <div className="bg-gradient-to-br from-green-600/10 to-emerald-600/10 backdrop-blur-xl border border-green-500/20 rounded-3xl p-8 hover:from-green-600/20 hover:to-emerald-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/50">
                <TrendingDown className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Premium Loan</h3>
              <div className="text-3xl text-green-400 mb-2">₦2M - ₦5M</div>
              <p className="text-gray-400 mb-6">
                For major expenses with the best rates and extended repayment.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">2% monthly interest</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">6-24 months repayment</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Low interest rate</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Dedicated support</span>
                </li>
              </ul>
              <Button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-full shadow-lg shadow-green-500/50"
              >
                Apply Now
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1675358965394-d9e42b72c696?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwcGVyc29uJTIwZmluYW5jaWFsJTIwc3VjY2Vzc3xlbnwxfHx8fDE3NjExNDY5ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="African person celebrating financial success"
                  className="rounded-2xl w-full h-auto"
                />
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl text-white">
                Why choose Paychipa Loans?
              </h2>
              <p className="text-xl text-gray-400">
                Fast, fair, and transparent lending for everyone
              </p>
              
              <div className="space-y-4">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/50">
                      <Clock className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Instant Approval</h3>
                      <p className="text-gray-400">
                        Get approved in minutes with our AI-powered credit assessment
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/50">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">No Collateral Needed</h3>
                      <p className="text-gray-400">
                        Get loans based on your transaction history, not your assets
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-500/50">
                      <Calculator className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Flexible Repayment</h3>
                      <p className="text-gray-400">
                        Choose your repayment schedule and pay early without penalties
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Get your loan in 3 simple steps
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/50">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="text-xl text-white mb-3">Apply Online</h3>
              <p className="text-gray-400">
                Fill out a simple application form in under 2 minutes
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="text-xl text-white mb-3">Get Approved</h3>
              <p className="text-gray-400">
                Receive instant approval and loan offer based on your profile
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-emerald-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/50">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="text-xl text-white mb-3">Receive Money</h3>
              <p className="text-gray-400">
                Accept the offer and get money deposited instantly to your account
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Need money urgently?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Get instant access to funds with our fast and easy loan application
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-full px-8 shadow-xl shadow-blue-500/50"
          >
            Apply for Loan Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
