import { SEO } from "../components/SEO";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Calendar, Clock, ArrowRight, Sparkles } from "lucide-react";

export function BlogPage() {
  const featuredPost = {
    slug: "introducing-paychipa",
    title: "Introducing Paychipa: The Future of Digital Banking in Nigeria",
    excerpt: "We're building a new kind of bank - one that's simple, fast, and designed for everyday Nigerians. Learn about our journey and vision.",
    author: "Paychipa Team",
    date: "January 15, 2025",
    readTime: "5 min read",
    category: "Company News",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop"
  };

  const posts = [
    {
      slug: "choosing-pos-terminal",
      title: "How to Choose the Right POS Terminal for Your Business",
      excerpt: "A comprehensive guide to selecting the perfect POS terminal that meets your business needs and budget.",
      author: "Product Team",
      date: "January 10, 2025",
      readTime: "8 min read",
      category: "Business Tips",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=300&fit=crop"
    },
    {
      slug: "save-money-digital-banking",
      title: "5 Ways to Save Money with Digital Banking",
      excerpt: "Discover how switching to digital banking can help you save money and manage your finances better.",
      author: "Finance Team",
      date: "January 8, 2025",
      readTime: "6 min read",
      category: "Personal Finance",
      image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=400&h=300&fit=crop"
    },
    {
      title: "Understanding Escrow Services: A Complete Guide",
      excerpt: "Learn how escrow services protect buyers and sellers in online transactions and why they're essential.",
      author: "Product Team",
      date: "January 5, 2025",
      readTime: "7 min read",
      category: "Product Education",
      image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=400&h=300&fit=crop"
    },
    {
      title: "Building Financial Resilience: Smart Savings Strategies",
      excerpt: "Practical tips and strategies to build your savings and create a strong financial foundation.",
      author: "Finance Team",
      date: "January 3, 2025",
      readTime: "10 min read",
      category: "Personal Finance",
      image: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?w=400&h=300&fit=crop"
    },
    {
      title: "The Rise of Cashless Payments in Nigeria",
      excerpt: "Exploring the growing trend of digital payments and what it means for businesses and consumers.",
      author: "Research Team",
      date: "December 28, 2024",
      readTime: "12 min read",
      category: "Industry Insights",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&h=300&fit=crop"
    },
    {
      title: "Launching in 2026: What to Expect from Paychipa",
      excerpt: "Get an exclusive preview of the features and services we're building for our 2026 launch.",
      author: "Paychipa Team",
      date: "December 25, 2024",
      readTime: "5 min read",
      category: "Company News",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop"
    }
  ];

  const categories = [
    "All Posts",
    "Company News",
    "Product Education",
    "Personal Finance",
    "Business Tips",
    "Industry Insights"
  ];

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Blog - Paychipa | Fintech Insights & Digital Banking News"
        description="Read the latest from Paychipa. Digital banking insights, fintech trends, product updates, and stories from Nigeria's financial technology revolution."
        keywords="paychipa blog, fintech nigeria blog, digital banking news, financial technology insights, nigeria fintech"
      />
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full border border-white/10">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">Stories & Insights</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              The Paychipa
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                Blog
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              News, insights, and tips to help you make the most of your money and grow your business.
            </p>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="py-8 bg-black border-b border-white/10 sticky top-20 backdrop-blur-xl z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-6 py-2 rounded-full whitespace-nowrap transition-all ${
                  index === 0
                    ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                    : "bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Post */}
      <div className="py-16 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to={`/blog/${featuredPost.slug}`}>
            <div className="bg-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer">
              <div className="grid lg:grid-cols-2 gap-8">
                <div className="h-64 lg:h-full bg-gradient-to-br from-purple-600/20 to-pink-600/20">
                  <img 
                    src={featuredPost.image} 
                    alt={featuredPost.title}
                    className="w-full h-full object-cover opacity-80"
                  />
                </div>
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 rounded-full border border-purple-400/30 w-fit mb-4">
                    <span className="text-xs text-purple-300">Featured</span>
                  </div>
                  <h2 className="text-3xl lg:text-4xl text-white mb-4 group-hover:text-purple-400 transition-colors">
                    {featuredPost.title}
                  </h2>
                  <p className="text-lg text-gray-400 mb-6">
                    {featuredPost.excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-gray-400 mb-6">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {featuredPost.date}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {featuredPost.readTime}
                    </div>
                  </div>
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full w-fit">
                    Read Article
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Blog Posts Grid */}
      <div className="py-16 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl text-white mb-2">Latest Articles</h2>
            <p className="text-gray-400">Stay updated with our latest insights and news</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <Link to={`/blog/${post.slug}`} key={index}>
                <div 
                  className="bg-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 hover:border-purple-500/50 transition-all group cursor-pointer"
                >
                  <div className="h-48 bg-gradient-to-br from-purple-600/20 to-pink-600/20 overflow-hidden">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 rounded-full border border-purple-400/30 w-fit">
                      <span className="text-xs text-purple-300">{post.category}</span>
                    </div>
                    <h3 className="text-xl text-white group-hover:text-purple-400 transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-400 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center gap-4 text-sm text-gray-500 pt-4 border-t border-white/10">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3 h-3" />
                        {post.date}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3 h-3" />
                        {post.readTime}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              size="lg"
              className="bg-white/10 backdrop-blur-xl border border-white/20 hover:bg-white/20 text-white px-8 rounded-full"
            >
              Load More Articles
            </Button>
          </div>
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="py-24 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Stay in the loop
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Get the latest articles, product updates, and industry insights delivered to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input 
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <Button 
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 rounded-full shadow-lg shadow-purple-500/50"
            >
              Subscribe
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
