import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, CreditCard, Smartphone, Globe, Lock, Zap, RefreshCcw } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";
import cardImage from "figma:asset/637ac4400082a667625a5495d4d889559b8095a4.png";

export function CardsPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Virtual & Physical Cards - Paychipa | Mastercard Debit Cards"
        description="Get instant virtual cards and premium physical Mastercard debit cards. Shop online, pay bills, and withdraw cash globally. Contactless payments, global acceptance."
        keywords="virtual card nigeria, mastercard nigeria, debit card, online shopping card, physical card nigeria, contactless payment"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
                <CreditCard className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-purple-300">Payment Cards</span>
              </div>
              
              <h1 className="text-5xl sm:text-6xl text-white">
                Cards for every
                <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                  need and purpose
                </span>
              </h1>
              
              <p className="text-xl text-gray-300 leading-relaxed">
                Get instant virtual cards for online shopping and physical Mastercard debit cards delivered to your door. Shop anywhere in the world with confidence.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => setIsWaitlistOpen(true)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
                >
                  Get Your Card
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <Button 
                  size="lg" 
                  className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
                >
                  Compare Cards
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-3xl blur-3xl"></div>
              <img
                src={cardImage}
                alt="Paychipa Cards"
                className="relative rounded-3xl shadow-2xl shadow-purple-500/30 w-full h-auto border border-white/10"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Card Types */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Choose the perfect card for you
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Whether you shop online or offline, we have a card that fits your lifestyle
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Virtual Card */}
            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 text-white relative overflow-hidden hover:from-purple-600/20 hover:to-pink-600/20 transition-all">
              <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl"></div>
              <div className="relative">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/50">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl">Virtual Card</h3>
                </div>
                
                <p className="text-gray-300 mb-6">
                  Create instant virtual cards for online payments. Perfect for subscriptions, online shopping, and digital services.
                </p>

                <div className="space-y-3 mb-8">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Created instantly in the app</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Dollar & Naira cards available</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Freeze/unfreeze anytime</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Create multiple cards</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Set spending limits</span>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  onClick={() => setIsWaitlistOpen(true)}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full shadow-lg shadow-purple-500/50"
                >
                  Get Virtual Card
                </Button>
              </div>
            </div>

            {/* Physical Card */}
            <div className="bg-gradient-to-br from-blue-600/10 to-cyan-600/10 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-8 text-white relative overflow-hidden hover:from-blue-600/20 hover:to-cyan-600/20 transition-all">
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl"></div>
              <div className="relative">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/50">
                    <CreditCard className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl">Physical Card</h3>
                </div>
                
                <p className="text-gray-300 mb-6">
                  Premium Mastercard debit card delivered free to your location. Use at ATMs, POS terminals, and online worldwide.
                </p>

                <div className="space-y-3 mb-8">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Free delivery to your address</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Contactless payments enabled</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Works at all ATMs nationwide</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Global acceptance - Mastercard network</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-green-400" />
                    <span className="text-gray-300">Chip & PIN security</span>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  onClick={() => setIsWaitlistOpen(true)}
                  className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-full shadow-lg shadow-blue-500/50"
                >
                  Request Physical Card
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Powerful card features
            </h2>
            <p className="text-xl text-gray-400">
              Built for security, convenience, and global acceptance
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Advanced Security</h3>
              <p className="text-gray-400">
                3D Secure authentication, fraud monitoring, and instant transaction alerts keep your money safe.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Global Acceptance</h3>
              <p className="text-gray-400">
                Shop anywhere in the world with Mastercard's global network covering millions of merchants.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/50">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Instant Control</h3>
              <p className="text-gray-400">
                Freeze, unfreeze, or delete cards instantly from the app. You're always in control.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-gray-600 to-slate-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-gray-500/50">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Mobile Payments</h3>
              <p className="text-gray-400">
                Add your card to Apple Pay, Google Pay, and Samsung Pay for contactless payments.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-rose-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/50">
                <RefreshCcw className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Auto-Top Up</h3>
              <p className="text-gray-400">
                Set up automatic card funding from your main account for seamless spending.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/50">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Multiple Cards</h3>
              <p className="text-gray-400">
                Create multiple virtual cards for different purposes - budgeting made easy.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Fees Section */}
      <div className="py-24 bg-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl text-white mb-4">
              Transparent pricing
            </h2>
            <p className="text-xl text-gray-400">
              No hidden fees. Know exactly what you'll pay.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl text-white mb-6">Virtual Card</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">Card Creation</span>
                    <span className="text-white">Free</span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">Monthly Fee</span>
                    <span className="text-white">₦0</span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">Online Transactions</span>
                    <span className="text-white">Free</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Foreign Transactions</span>
                    <span className="text-white">3% fee</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl text-white mb-6">Physical Card</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">Card Issuance</span>
                    <span className="text-white">₦1,000</span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">Delivery</span>
                    <span className="text-white">Free</span>
                  </div>
                  <div className="flex justify-between items-center pb-4 border-b border-white/10">
                    <span className="text-gray-400">ATM Withdrawals</span>
                    <span className="text-white">₦35/transaction</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">POS Payments</span>
                    <span className="text-white">Free</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Ready to get your card?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of Nigerians shopping smarter with Paychipa cards
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => setIsWaitlistOpen(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8 shadow-xl shadow-purple-500/50"
            >
              Get Virtual Card
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              onClick={() => setIsWaitlistOpen(true)}
              className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full px-8"
            >
              Request Physical Card
            </Button>
          </div>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
