import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { Check, ArrowRight, Shield, Lock, Users, FileCheck, Clock, AlertCircle, ShoppingBag, Home, Briefcase } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function EscrowPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Secure Escrow Services - Paychipa | Safe Transactions for Everyone"
        description="Protect your transactions with Paychipa escrow. Perfect for property deals, marketplace sales, freelance payments. Buyer and seller protection guaranteed."
        keywords="escrow service nigeria, secure payment, property escrow, marketplace escrow, freelance payment, safe transaction"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full">
              <Shield className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-purple-300">Secure Escrow</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white">
              Trade with confidence
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                secure escrow protection
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Buy and sell safely with Paychipa Escrow. Your money is protected until both parties are satisfied. Perfect for online marketplace transactions, freelance work, and high-value purchases.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
              >
                Start Secure Transaction
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full"
              >
                How It Works
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 justify-center pt-4">
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Buyer protection</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Seller security</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-4 py-2">
                <Check className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Dispute resolution</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* What is Escrow Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1689152496131-9cecc95cde25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYnVzaW5lc3MlMjBoYW5kc2hha2UlMjBhZ3JlZW1lbnR8ZW58MXx8fHwxNzYxMTQ3MjgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="African business people shaking hands"
                  className="rounded-2xl w-full h-auto"
                />
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl text-white">
                What is Paychipa Escrow?
              </h2>
              <p className="text-xl text-gray-400 leading-relaxed">
                Escrow is a secure payment method where we hold your money until both the buyer and seller are satisfied with the transaction.
              </p>
              
              <div className="space-y-4">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/50">
                      <Lock className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Protected Payments</h3>
                      <p className="text-gray-400">
                        Money is held securely until the buyer confirms they received the product or service as described.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/50">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Fair for Everyone</h3>
                      <p className="text-gray-400">
                        Buyers get what they pay for. Sellers get paid for what they deliver. Win-win.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/50">
                      <FileCheck className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl text-white mb-2">Dispute Resolution</h3>
                      <p className="text-gray-400">
                        If something goes wrong, our expert team steps in to investigate and resolve the issue fairly.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              How Escrow works
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Simple, secure, and transparent - protecting both buyers and sellers
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="text-lg text-white mb-2">Buyer & Seller Agree</h3>
              <p className="text-sm text-gray-400">
                Both parties agree on transaction terms and amount
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="text-lg text-white mb-2">Buyer Pays</h3>
              <p className="text-sm text-gray-400">
                Buyer sends money to Paychipa Escrow account
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="text-lg text-white mb-2">Seller Delivers</h3>
              <p className="text-sm text-gray-400">
                Seller ships product or completes service
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">4</span>
              </div>
              <h3 className="text-lg text-white mb-2">Buyer Confirms</h3>
              <p className="text-sm text-gray-400">
                Buyer inspects and confirms satisfaction
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/50">
                <span className="text-2xl">5</span>
              </div>
              <h3 className="text-lg text-white mb-2">Seller Gets Paid</h3>
              <p className="text-sm text-gray-400">
                Money is released to seller's account
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Use Cases */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Perfect for every transaction
            </h2>
            <p className="text-xl text-gray-400">
              Use Paychipa Escrow for secure transactions across different scenarios
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 hover:from-purple-600/20 hover:to-pink-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <ShoppingBag className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Online Marketplace</h3>
              <p className="text-gray-400 mb-6">
                Buy and sell on Instagram, Facebook, Jiji, Jumia, or any platform with complete peace of mind.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Phones & electronics</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Fashion & accessories</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Used cars & vehicles</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Furniture & appliances</span>
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-blue-600/10 to-cyan-600/10 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-8 hover:from-blue-600/20 hover:to-cyan-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/50">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Freelance Services</h3>
              <p className="text-gray-400 mb-6">
                Protect payments for freelance work until the job is completed to satisfaction.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Web & app development</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Graphic design & branding</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Content writing</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Digital marketing</span>
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-pink-600/10 to-purple-600/10 backdrop-blur-xl border border-pink-500/20 rounded-3xl p-8 hover:from-pink-600/20 hover:to-purple-600/20 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/50">
                <Home className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-white mb-3">Property & Rentals</h3>
              <p className="text-gray-400 mb-6">
                Secure rent payments and property deposits with verified landlords and tenants.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Apartment rent payments</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Security deposits</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Land purchases</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Event venue bookings</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-white mb-4">
              Why choose Paychipa Escrow?
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Industry-leading protection for all your transactions
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">100% Protection</h3>
              <p className="text-gray-400">
                Your money is held in a secure escrow account until both parties fulfill their obligations.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Fast Releases</h3>
              <p className="text-gray-400">
                Once confirmed, sellers receive their payment instantly - no waiting for bank processing.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <FileCheck className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Expert Dispute Team</h3>
              <p className="text-gray-400">
                If there's a disagreement, our trained team investigates and resolves issues fairly.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Real-Time Updates</h3>
              <p className="text-gray-400">
                Track your transaction status with instant notifications at every step of the process.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Bank-Level Security</h3>
              <p className="text-gray-400">
                Military-grade encryption and industry-standard security protocols protect your funds.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/50">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-white mb-3">Verified Users</h3>
              <p className="text-gray-400">
                All parties are verified with BVN and ID confirmation for added security and trust.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl text-white mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-xl text-gray-400">
              Fair fees for maximum protection
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl">
            <div className="text-center mb-8">
              <div className="text-5xl text-white mb-2">2.5%</div>
              <p className="text-gray-400">per transaction (split between buyer & seller)</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Transactions up to ₦100,000</span>
                <span className="text-white">1.5% each</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Transactions ₦100K - ₦1M</span>
                <span className="text-white">2% each</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Transactions above ₦1M</span>
                <span className="text-white">2.5% each</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <span className="text-gray-400">Dispute Resolution</span>
                <span className="text-white">Free</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Money Release</span>
                <span className="text-white">Instant & Free</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-6">
              <h4 className="text-white mb-3">Example Transaction</h4>
              <p className="text-sm text-gray-400 mb-3">
                For a ₦50,000 transaction:
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Transaction amount</span>
                  <span className="text-white">₦50,000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Buyer pays (1.5% fee)</span>
                  <span className="text-white">₦50,750</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Seller fee (1.5%)</span>
                  <span className="text-white">₦750</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-purple-500/20">
                  <span className="text-white">Seller receives</span>
                  <span className="text-white">₦49,250</span>
                </div>
              </div>
            </div>

            <div className="text-center mt-8">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
              >
                Start Using Escrow
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-black relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Ready to trade safely?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Start using Paychipa Escrow for secure, protected transactions today
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-8 shadow-xl shadow-purple-500/50"
          >
            Create Escrow Transaction
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
