import { SEO } from "../components/SEO";
import { Button } from "../components/ui/button";
import { ArrowRight, Target, Users, TrendingUp, Heart, Zap, Shield } from "lucide-react";
import { useState } from "react";
import { Waitlist } from "../components/Waitlist";

export function AboutPage() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-50/30">
      <SEO 
        title="About Us - Paychipa | Building the Future of Digital Banking in Nigeria"
        description="Learn about Paychipa's mission to make digital banking accessible to all Nigerians. Powered by Stripe and Flutterwave, launching in 2025. Based in Abuja, Nigeria."
        keywords="about paychipa, digital banking nigeria, fintech startup nigeria, paychipa team, about us"
      />
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-white to-blue-50 pt-32 pb-20">
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-300/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-300/20 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full">
              <Heart className="w-4 h-4 text-[#2D1E36]" />
              <span className="text-sm text-[#2D1E36]">About Paychipa</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-[#2D1E36]">
              Banking for
              <span className="block bg-gradient-to-r from-purple-600 via-[#2D1E36] to-blue-600 bg-clip-text text-transparent">
                everyday Nigerians
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We're building the future of digital banking in Nigeria - simple, fast, and accessible to everyone.
            </p>
          </div>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div className="bg-gradient-to-br from-purple-50 to-white p-12 rounded-3xl border border-purple-100">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl text-[#2D1E36] mb-4">Our Mission</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                To provide simple, accessible, and affordable financial services to every Nigerian, empowering individuals and businesses to achieve their financial goals.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-white p-12 rounded-3xl border border-blue-100">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl flex items-center justify-center mb-6">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl text-[#2D1E36] mb-4">Our Vision</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                To become the most trusted and widely used digital banking platform in Africa, transforming how people manage, save, and grow their money.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Our Story */}
      <div className="py-24 bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl text-[#2D1E36] mb-4">Our Story</h2>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl">
            <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
              <p>
                Paychipa was born out of frustration with traditional banking in Nigeria. Long queues, high fees, poor customer service, and limited access to financial products. We knew there had to be a better way.
              </p>
              <p>
                In 2024, our founders came together with a simple vision: make banking as easy as sending a message. We wanted to build a platform that would give every Nigerian access to world-class financial services right from their phone.
              </p>
              <p>
                Today, we're building towards that vision with a team of passionate individuals who believe that everyone deserves access to simple, affordable, and reliable banking services.
              </p>
              <p>
                Launching in 2026, Paychipa will offer everything from instant transfers and bill payments to savings, loans, and business tools - all designed with the Nigerian user in mind.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Our Values */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-[#2D1E36] mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Customer First</h3>
              <p className="text-gray-600">
                Everything we build starts with understanding what our customers need. Your success is our success.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Zap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Move Fast</h3>
              <p className="text-gray-600">
                We believe in speed and agility. Quick approvals, instant transfers, and rapid innovation.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Trust & Security</h3>
              <p className="text-gray-600">
                Your money and data are sacred. We employ bank-level security to keep everything safe.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-gray-600 to-slate-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Target className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Simplicity</h3>
              <p className="text-gray-600">
                Banking should be simple. We remove complexity so anyone can manage their finances easily.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-pink-600 to-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Inclusivity</h3>
              <p className="text-gray-600">
                Financial services for everyone. No minimum balance, no discrimination, just fair banking.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <TrendingUp className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-[#2D1E36] mb-3">Innovation</h3>
              <p className="text-gray-600">
                We constantly push boundaries to create better products and experiences for our users.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-24 bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-[#2D1E36] mb-4">
              Building Something Big
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="bg-white rounded-2xl p-8 text-center shadow-lg">
              <div className="text-5xl text-[#2D1E36] mb-2">2026</div>
              <div className="text-gray-600">Launch Year</div>
            </div>

            <div className="bg-white rounded-2xl p-8 text-center shadow-lg">
              <div className="text-5xl text-[#2D1E36] mb-2">10K+</div>
              <div className="text-gray-600">Waitlist Sign-ups</div>
            </div>

            <div className="bg-white rounded-2xl p-8 text-center shadow-lg">
              <div className="text-5xl text-[#2D1E36] mb-2">15%</div>
              <div className="text-gray-600">Savings Interest</div>
            </div>

            <div className="bg-white rounded-2xl p-8 text-center shadow-lg">
              <div className="text-5xl text-[#2D1E36] mb-2">24/7</div>
              <div className="text-gray-600">Support</div>
            </div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-[#2D1E36] mb-4">
              Backed by Expertise
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our team brings together decades of experience in banking, technology, and customer service
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-3xl p-12 text-center">
            <p className="text-lg text-gray-600 mb-6">
              We're building Paychipa with support from industry experts, backed by partnerships with Stripe and Flutterwave to ensure world-class payment infrastructure.
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <div className="bg-white px-6 py-3 rounded-full shadow-sm">
                <span className="text-[#2D1E36]">Powered by Stripe</span>
              </div>
              <div className="bg-white px-6 py-3 rounded-full shadow-sm">
                <span className="text-[#2D1E36]">Powered by Flutterwave</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-gradient-to-br from-[#2D1E36] via-purple-900 to-purple-950 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl text-white mb-6">
            Join us on this journey
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
            Be part of the future of banking in Nigeria. Join our waitlist and be the first to experience Paychipa.
          </p>
          <Button 
            size="lg" 
            onClick={() => setIsWaitlistOpen(true)}
            className="bg-white text-[#2D1E36] hover:bg-gray-100 rounded-full px-8 shadow-xl"
          >
            Join the Waitlist
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </div>
  );
}
