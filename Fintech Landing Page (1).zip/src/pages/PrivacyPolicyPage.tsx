import { SEO } from "../components/SEO";
import { Link } from "react-router-dom";
import { Shield, Lock, Eye, FileText, Users, AlertCircle } from "lucide-react";

export function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-black">
      <SEO 
        title="Privacy Policy - Paychipa | Your Privacy Matters"
        description="Read Paychipa's privacy policy. Learn how we collect, use, protect, and manage your personal information. GDPR and NDPR compliant."
        keywords="privacy policy, data protection, gdpr, ndpr, paychipa privacy, data security"
        type="website"
      />
      {/* Hero Section */}
      <div className="relative py-20 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-600/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full mb-6">
            <Shield className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-gray-300">Last Updated: January 15, 2025</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white mb-6">
            Privacy Policy
          </h1>
          
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Your privacy and data security are our top priorities. Learn how we collect, use, and protect your information.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Introduction */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <FileText className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h2 className="text-2xl text-white mb-3">Introduction</h2>
              <p className="text-gray-300 leading-relaxed">
                Paychipa ("we," "us," or "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and services. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the application.
              </p>
            </div>
          </div>
        </div>

        {/* Information We Collect */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Eye className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">Information We Collect</h2>
          </div>
          
          <div className="space-y-6 ml-16">
            <div>
              <h3 className="text-lg text-white mb-3">Personal Information</h3>
              <p className="text-gray-300 mb-3">
                We collect personal information that you provide to us when you:
              </p>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Register for an account (name, email, phone number, date of birth)</li>
                <li>Complete your KYC verification (BVN, NIN, government-issued ID)</li>
                <li>Link your bank account or debit card</li>
                <li>Make transactions through our platform</li>
                <li>Contact our customer support team</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Financial Information</h3>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Bank account details and transaction history</li>
                <li>Payment card information (securely tokenized)</li>
                <li>Transaction amounts, dates, and merchant information</li>
                <li>Savings and loan account details</li>
                <li>Credit score and financial history (for loan applications)</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg text-white mb-3">Device and Usage Information</h3>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Device type, operating system, and unique device identifiers</li>
                <li>IP address and location data (with your permission)</li>
                <li>App usage patterns and feature interactions</li>
                <li>Log data including access times and error reports</li>
              </ul>
            </div>
          </div>
        </div>

        {/* How We Use Your Information */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Users className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">How We Use Your Information</h2>
          </div>
          
          <div className="space-y-4 ml-16 text-gray-300">
            <p>We use the information we collect to:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Process your transactions and manage your account</li>
              <li>Verify your identity and prevent fraud</li>
              <li>Comply with legal and regulatory requirements (CBN regulations, AML/KYC)</li>
              <li>Provide customer support and respond to your inquiries</li>
              <li>Send you important updates about our services</li>
              <li>Improve our products and develop new features</li>
              <li>Assess creditworthiness for loan applications</li>
              <li>Detect and prevent fraudulent or illegal activities</li>
              <li>Personalize your experience and provide relevant offers</li>
            </ul>
          </div>
        </div>

        {/* Information Sharing */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Lock className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">Information Sharing and Disclosure</h2>
          </div>
          
          <div className="space-y-6 ml-16">
            <div>
              <h3 className="text-lg text-white mb-3">We may share your information with:</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span><strong className="text-white">Payment Processors:</strong> Stripe and Flutterwave for processing transactions</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span><strong className="text-white">Banks and Financial Institutions:</strong> To facilitate transfers and payments</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span><strong className="text-white">Regulatory Authorities:</strong> CBN, EFCC, and other regulatory bodies when required by law</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span><strong className="text-white">Service Providers:</strong> Third-party vendors who help us operate our business</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span><strong className="text-white">Credit Bureaus:</strong> For loan application processing and credit assessment</span>
                </li>
              </ul>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  We never sell your personal information to third parties. All data sharing is done securely and only as necessary to provide our services or comply with legal obligations.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Data Security */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-500/20 border border-purple-400/30 rounded-xl flex items-center justify-center flex-shrink-0">
              <Shield className="h-6 w-6 text-purple-400" />
            </div>
            <h2 className="text-2xl text-white">Data Security</h2>
          </div>
          
          <div className="space-y-4 ml-16 text-gray-300">
            <p>
              We implement industry-standard security measures to protect your information, including:
            </p>
            <ul className="space-y-2 list-disc list-inside">
              <li>256-bit SSL encryption for all data transmission</li>
              <li>Encrypted storage of sensitive financial data</li>
              <li>Multi-factor authentication for account access</li>
              <li>Regular security audits and penetration testing</li>
              <li>Secure data centers with 24/7 monitoring</li>
              <li>Employee background checks and confidentiality agreements</li>
            </ul>
            <p className="pt-2">
              However, no method of transmission over the internet is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.
            </p>
          </div>
        </div>

        {/* Your Rights */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-6">Your Privacy Rights</h2>
          
          <div className="space-y-4 text-gray-300">
            <p>Under Nigerian data protection laws (NDPR), you have the right to:</p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Access your personal information we hold</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your data (subject to legal obligations)</li>
              <li>Object to processing of your data</li>
              <li>Withdraw consent for data processing</li>
              <li>Request data portability</li>
            </ul>
            <p className="pt-4">
              To exercise these rights, contact us at <a href="mailto:privacy@paychipa.com" className="text-purple-400 hover:text-purple-300">privacy@paychipa.com</a>
            </p>
          </div>
        </div>

        {/* Data Retention */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-4">Data Retention</h2>
          <p className="text-gray-300 leading-relaxed">
            We retain your personal information for as long as necessary to provide our services and comply with legal obligations. Transaction records are kept for a minimum of 7 years as required by Nigerian financial regulations. When you close your account, we will delete or anonymize your information within 90 days, except where retention is required by law.
          </p>
        </div>

        {/* Children's Privacy */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-4">Children's Privacy</h2>
          <p className="text-gray-300 leading-relaxed">
            Our services are not intended for individuals under 18 years of age. We do not knowingly collect personal information from children. If you believe we have collected information from a child, please contact us immediately.
          </p>
        </div>

        {/* Changes to Policy */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 mb-8">
          <h2 className="text-2xl text-white mb-4">Changes to This Privacy Policy</h2>
          <p className="text-gray-300 leading-relaxed">
            We may update this Privacy Policy from time to time. We will notify you of any material changes by email or through the app. Your continued use of our services after changes are made constitutes acceptance of the updated policy.
          </p>
        </div>

        {/* Contact */}
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
          <h2 className="text-2xl text-white mb-4">Contact Us</h2>
          <p className="text-gray-300 mb-4">
            If you have questions about this Privacy Policy or our data practices, please contact us:
          </p>
          <div className="space-y-2 text-gray-300">
            <p><strong className="text-white">Email:</strong> <a href="mailto:privacy@paychipa.com" className="text-purple-400 hover:text-purple-300">privacy@paychipa.com</a></p>
            <p><strong className="text-white">Phone:</strong> <a href="tel:+2349012345678" className="text-purple-400 hover:text-purple-300">+234 901 234 5678</a></p>
            <p><strong className="text-white">Address:</strong> Abuja, Nigeria</p>
          </div>
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
