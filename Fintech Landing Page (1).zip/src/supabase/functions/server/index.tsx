import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

app.use('*', logger(console.log));

// Health check
app.get('/make-server-8addffcd/health', (c) => {
  return c.json({ status: 'ok', service: 'Paychipa API' });
});

// Waitlist endpoint - Save email signups
app.post('/make-server-8addffcd/waitlist', async (c) => {
  try {
    const body = await c.req.json();
    const { email, name, phone } = body;

    if (!email) {
      return c.json({ error: 'Email is required' }, 400);
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return c.json({ error: 'Invalid email format' }, 400);
    }

    // Create unique key for waitlist entry
    const timestamp = Date.now();
    const waitlistKey = `waitlist:${email.toLowerCase()}`;
    const waitlistEntryKey = `waitlist-entry:${timestamp}`;

    // Check if email already exists
    const existing = await kv.get(waitlistKey);
    if (existing) {
      return c.json({ 
        message: 'You are already on the waitlist!',
        alreadyExists: true 
      }, 200);
    }

    // Save waitlist data
    const waitlistData = {
      email: email.toLowerCase(),
      name: name || '',
      phone: phone || '',
      timestamp,
      joinedAt: new Date().toISOString(),
      source: 'website',
      status: 'pending'
    };

    // Save with both keys for easy lookup
    await kv.mset([
      [waitlistKey, waitlistData],
      [waitlistEntryKey, waitlistData]
    ]);

    console.log(`✅ New waitlist signup: ${email}`);

    return c.json({ 
      message: 'Successfully joined the waitlist!',
      success: true 
    }, 201);

  } catch (error) {
    console.error('Error saving waitlist entry:', error);
    return c.json({ 
      error: 'Failed to join waitlist. Please try again.',
      details: error.message 
    }, 500);
  }
});

// Get waitlist count
app.get('/make-server-8addffcd/waitlist/count', async (c) => {
  try {
    const entries = await kv.getByPrefix('waitlist:');
    return c.json({ 
      count: entries.length,
      message: `${entries.length} people on the waitlist` 
    });
  } catch (error) {
    console.error('Error getting waitlist count:', error);
    return c.json({ error: 'Failed to get count' }, 500);
  }
});

// Contact form endpoint
app.post('/make-server-8addffcd/contact', async (c) => {
  try {
    const body = await c.req.json();
    const { name, email, phone, subject, message } = body;

    if (!name || !email || !message) {
      return c.json({ error: 'Name, email, and message are required' }, 400);
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return c.json({ error: 'Invalid email format' }, 400);
    }

    const timestamp = Date.now();
    const contactKey = `contact:${timestamp}`;

    const contactData = {
      name,
      email: email.toLowerCase(),
      phone: phone || '',
      subject: subject || 'General Inquiry',
      message,
      timestamp,
      submittedAt: new Date().toISOString(),
      status: 'new',
      read: false
    };

    await kv.set(contactKey, contactData);

    console.log(`✅ New contact form submission from: ${name} (${email})`);

    return c.json({ 
      message: 'Message sent successfully! We will get back to you soon.',
      success: true 
    }, 201);

  } catch (error) {
    console.error('Error saving contact form:', error);
    return c.json({ 
      error: 'Failed to send message. Please try again.',
      details: error.message 
    }, 500);
  }
});

// Get all contact messages (for admin use)
app.get('/make-server-8addffcd/contact/all', async (c) => {
  try {
    const messages = await kv.getByPrefix('contact:');
    
    // Sort by timestamp (newest first)
    const sorted = messages.sort((a, b) => b.timestamp - a.timestamp);
    
    return c.json({ 
      messages: sorted,
      count: sorted.length 
    });
  } catch (error) {
    console.error('Error getting contact messages:', error);
    return c.json({ error: 'Failed to get messages' }, 500);
  }
});

// Analytics - Track page views (optional)
app.post('/make-server-8addffcd/analytics/pageview', async (c) => {
  try {
    const body = await c.req.json();
    const { page, referrer, userAgent } = body;

    const timestamp = Date.now();
    const analyticsKey = `analytics:${timestamp}`;

    await kv.set(analyticsKey, {
      page,
      referrer: referrer || '',
      userAgent: userAgent || '',
      timestamp,
      date: new Date().toISOString()
    });

    return c.json({ success: true });
  } catch (error) {
    console.error('Error tracking pageview:', error);
    return c.json({ error: 'Failed to track' }, 500);
  }
});

// Get analytics summary
app.get('/make-server-8addffcd/analytics/summary', async (c) => {
  try {
    const views = await kv.getByPrefix('analytics:');
    const waitlist = await kv.getByPrefix('waitlist:');
    const contacts = await kv.getByPrefix('contact:');

    return c.json({
      totalPageViews: views.length,
      waitlistSignups: waitlist.length,
      contactSubmissions: contacts.length,
      summary: {
        engagement: views.length + waitlist.length + contacts.length,
        conversionRate: waitlist.length > 0 
          ? ((waitlist.length / views.length) * 100).toFixed(2) + '%' 
          : '0%'
      }
    });
  } catch (error) {
    console.error('Error getting analytics:', error);
    return c.json({ error: 'Failed to get analytics' }, 500);
  }
});

// Export all data (for admin/backup)
app.get('/make-server-8addffcd/export/all', async (c) => {
  try {
    const waitlist = await kv.getByPrefix('waitlist-entry:');
    const contacts = await kv.getByPrefix('contact:');
    const analytics = await kv.getByPrefix('analytics:');

    return c.json({
      exported: new Date().toISOString(),
      data: {
        waitlist: waitlist.sort((a, b) => b.timestamp - a.timestamp),
        contacts: contacts.sort((a, b) => b.timestamp - a.timestamp),
        analytics: analytics.sort((a, b) => b.timestamp - a.timestamp)
      },
      counts: {
        waitlist: waitlist.length,
        contacts: contacts.length,
        analytics: analytics.length
      }
    });
  } catch (error) {
    console.error('Error exporting data:', error);
    return c.json({ error: 'Failed to export data' }, 500);
  }
});

// 404 handler
app.notFound((c) => {
  return c.json({ error: 'Not found' }, 404);
});

// Error handler
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal server error',
    message: err.message 
  }, 500);
});

Deno.serve(app.fetch);
