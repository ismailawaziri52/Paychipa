import { Button } from "./ui/button";
import { ArrowRight, Sparkles, Zap, Shield } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import heroImage from "figma:asset/d8ce1bb564fe21ade802eb173282ad3bb9b48ca6.png";
import { useState } from "react";
import { Waitlist } from "./Waitlist";

export function Hero() {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <>
    <div className="relative overflow-hidden bg-black pt-20">
      {/* Animated background elements */}
      <div className="absolute top-40 right-20 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-700"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-purple-600/10 to-pink-600/10 rounded-full blur-3xl"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm rounded-full border border-white/10">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-gray-200">Now Available in Nigeria</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl text-white leading-tight">
              Banking for
              <span className="block bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                Everyone
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 leading-relaxed max-w-lg">
              Send money, pay bills, save & invest with our all-in-one payment platform built for Nigerians.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group px-8 rounded-full shadow-xl shadow-purple-500/50"
              >
                Join Waitlist
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-white/20 text-white hover:bg-white/10 rounded-full backdrop-blur-sm"
                disabled
              >
                App Coming Soon
              </Button>
            </div>
            
            {/* Trust badges */}
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2">
                <Zap className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-200">Instant Transfers</span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2">
                <Shield className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-200">100% Secure</span>
              </div>
            </div>
          </div>
          
          {/* Right image */}
          <div className="relative lg:h-[600px] flex items-center justify-center">
            <div className="relative">
              {/* Floating card 1 */}
              <div className="absolute -top-8 -left-8 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl p-4 w-48 z-10 animate-float">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-green-500/20 backdrop-blur-sm border border-green-400/30 rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Transfer</div>
                    <div className="text-sm text-green-400">Successful</div>
                  </div>
                </div>
                <div className="text-2xl text-white">₦50,000</div>
              </div>
              
              {/* Main hero image */}
              <img
                src={heroImage}
                alt="Paychipa mobile app"
                className="relative rounded-3xl shadow-2xl shadow-purple-500/20 w-full max-w-md object-cover border border-white/10"
              />
              
              {/* Floating card 2 */}
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl shadow-2xl shadow-purple-500/50 border border-white/10 p-4 w-56 animate-float-delayed">
                <div className="text-xs opacity-90 mb-1">Monthly Savings</div>
                <div className="text-3xl mb-2">₦2.5M</div>
                <div className="flex items-center gap-1 text-xs">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                  <span>+15% this month</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 pt-12 border-t border-white/10">
          <div className="text-center">
            <div className="text-4xl text-white mb-2">Free</div>
            <div className="text-sm text-gray-400">POS Terminals</div>
          </div>
          <div className="text-center">
            <div className="text-4xl text-white mb-2">0%</div>
            <div className="text-sm text-gray-400">Setup Fees</div>
          </div>
          <div className="text-center">
            <div className="text-4xl text-white mb-2">Instant</div>
            <div className="text-sm text-gray-400">Account Opening</div>
          </div>
          <div className="text-center">
            <div className="text-4xl text-white mb-2">24/7</div>
            <div className="text-sm text-gray-400">Support</div>
          </div>
        </div>

        {/* Powered by */}
        <div className="flex items-center justify-center gap-2 mt-12 pt-8">
          <span className="text-sm text-gray-400" style={{fontFamily: 'Montserrat, sans-serif'}}>Powered by</span>
          <span className="text-sm bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent" style={{fontFamily: 'Montserrat, sans-serif', fontWeight: 600}}>Stripe and Flutterwave</span>
        </div>
      </div>
      
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float 3s ease-in-out infinite;
          animation-delay: 1.5s;
        }
      `}</style>
    </div>
    
    <Waitlist open={isWaitlistOpen} onOpenChange={setIsWaitlistOpen} />
    </>
  );
}
