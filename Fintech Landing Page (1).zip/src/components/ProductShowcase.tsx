import { Check, ArrowRight, Smartphone, Shield } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Link } from "react-router-dom";
import posImage from "figma:asset/fb38f2d0070b359e13036a84d99c5f1a42758171.png";
import cardImage from "figma:asset/637ac4400082a667625a5495d4d889559b8095a4.png";
import personalBankingImage from "figma:asset/faca6947b31523f0eda12602ffa6e7421959c13e.png";

export function ProductShowcase() {
  return (
    <div className="bg-black">
      {/* POS Terminal Section */}
      <div id="pos" className="py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-3xl blur-3xl"></div>
              <img
                src={posImage}
                alt="POS Terminal"
                className="relative rounded-3xl shadow-2xl shadow-purple-500/20 w-full h-auto border border-white/10"
              />
            </div>
            
            <div className="space-y-6">
              <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-white/10 rounded-full">
                <span className="text-sm text-purple-300">For Businesses</span>
              </div>
              
              <h2 className="text-4xl sm:text-5xl text-white">
                Accept payments anywhere with our POS terminals
              </h2>
              
              <p className="text-xl text-gray-300 leading-relaxed">
                Get a free POS machine and start accepting card payments from your customers. Instant settlement directly to your account.
              </p>
              
              <ul className="space-y-4">
                {[
                  "Free POS terminal with zero setup cost",
                  "Accept all card types - Mastercard, Visa, Verve",
                  "Instant settlement to your bank account",
                  "24/7 customer support and maintenance",
                  "Real-time sales tracking on your phone",
                  "Multiple terminals for multiple locations"
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="mt-0.5 flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 border border-green-400/30 flex items-center justify-center">
                      <Check className="h-4 w-4 text-green-400" />
                    </div>
                    <span className="text-gray-300">{item}</span>
                  </li>
                ))}
              </ul>
              
              <Link to="/pos-terminals">
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group mt-6 rounded-full px-8 shadow-lg shadow-purple-500/50">
                  Learn More About POS
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Cards Section */}
      <div id="cards" className="py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6 order-2 lg:order-1">
              <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm border border-white/10 rounded-full">
                <span className="text-sm text-blue-300">Smart Cards</span>
              </div>
              
              <h2 className="text-4xl sm:text-5xl text-white">
                Physical & virtual cards for all your needs
              </h2>
              
              <p className="text-xl text-gray-300 leading-relaxed">
                Get instant virtual cards for online shopping and physical debit cards delivered to your doorstep. Shop online and offline with ease.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4 shadow-lg">
                    <Smartphone className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg text-white mb-2">Virtual Cards</h3>
                  <p className="text-sm text-gray-400 mb-4">Instant virtual cards for online payments. Create multiple cards for different purposes.</p>
                  <ul className="space-y-2 text-sm text-gray-300">
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Created instantly
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Dollar & Naira cards
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Freeze/unfreeze anytime
                    </li>
                  </ul>
                </div>
                
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mb-4 shadow-lg">
                    <svg className="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  </div>
                  <h3 className="text-lg text-white mb-2">Physical Cards</h3>
                  <p className="text-sm text-gray-400 mb-4">Mastercard debit cards delivered to you. Use at ATMs and POS terminals nationwide.</p>
                  <ul className="space-y-2 text-sm text-gray-300">
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Free delivery
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Contactless payments
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-400" />
                      Worldwide acceptance
                    </li>
                  </ul>
                </div>
              </div>
              
              <Link to="/cards">
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group rounded-full px-8 shadow-lg shadow-purple-500/50">
                  Explore Cards
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
            
            <div className="relative order-1 lg:order-2">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-3xl blur-3xl"></div>
              <img
                src={cardImage}
                alt="Payment cards"
                className="relative rounded-3xl shadow-2xl shadow-blue-500/20 w-full h-auto border border-white/10"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Personal Banking */}
      <div id="personal" className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl p-8 lg:p-16">
            <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/30 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#2D1E36]/20 rounded-full blur-3xl"></div>
            
            <div className="relative grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full mb-2">
                  <span className="text-sm text-purple-300">Personal Banking</span>
                </div>
                
                <h2 className="text-4xl sm:text-5xl text-white">
                  Send money, pay bills, save & invest
                </h2>
                <p className="text-xl text-gray-300 leading-relaxed">
                  Open a free account in minutes. No paperwork, no minimum balance. Just simple, fast banking.
                </p>
                
                <div className="space-y-3 pt-4">
                  {[
                    "Free transfers to all banks in Nigeria",
                    "Automated savings with 15% interest",
                    "Pay bills - airtime, data, electricity, cable",
                    "Request and send money with ease",
                    "Instant loans up to ₦5M",
                    "Investment options with high returns"
                  ].map((item, index) => (
                    <div key={index} className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-3 hover:bg-white/10 transition-all">
                      <div className="flex items-center gap-3">
                        <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                        <span className="text-white">{item}</span>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Link to="/personal">
                  <Button size="lg" className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 rounded-full px-8 mt-6">
                    Discover Personal Banking
                  </Button>
                </Link>
              </div>
              
              <div className="relative">
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl">
                  <img
                    src={personalBankingImage}
                    alt="African man using laptop for mobile banking"
                    className="rounded-xl w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Escrow Services */}
      <div id="escrow" className="py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6 order-2 lg:order-1">
              <div className="inline-block px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-white/10 rounded-full">
                <span className="text-sm text-purple-300">Secure Transactions</span>
              </div>
              
              <h2 className="text-4xl sm:text-5xl text-white">
                Trade with confidence using Escrow protection
              </h2>
              
              <p className="text-xl text-gray-300 leading-relaxed">
                Buy and sell safely online. Your money is held securely until both buyer and seller are satisfied. Perfect for marketplace transactions and high-value purchases.
              </p>
              
              <div className="space-y-3 pt-4">
                {[
                  "100% buyer & seller protection",
                  "Secure payment holding",
                  "Expert dispute resolution",
                  "Perfect for online marketplaces",
                  "Instant release after confirmation",
                  "Verified user transactions"
                ].map((item, index) => (
                  <div key={index} className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-3 hover:bg-white/10 transition-all">
                    <div className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                      <span className="text-white">{item}</span>
                    </div>
                  </div>
                ))}
              </div>
              
              <Link to="/escrow">
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white group rounded-full px-8 shadow-lg shadow-purple-500/50">
                  Learn About Escrow
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
            
            <div className="relative order-1 lg:order-2">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-3xl"></div>
              <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl shadow-purple-500/20">
                <div className="flex items-center justify-center h-80">
                  <div className="text-center space-y-6">
                    <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-purple-500/50">
                      <Shield className="w-12 h-12 text-white" />
                    </div>
                    <div>
                      <h3 className="text-3xl text-white mb-2">Secure Escrow</h3>
                      <p className="text-gray-400">Your protection guarantee</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 text-center">
                        <div className="text-2xl text-purple-400 mb-1">100%</div>
                        <div className="text-xs text-gray-400">Protected</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 text-center">
                        <div className="text-2xl text-purple-400 mb-1">24/7</div>
                        <div className="text-xs text-gray-400">Support</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 text-center">
                        <div className="text-2xl text-purple-400 mb-1">Fast</div>
                        <div className="text-xs text-gray-400">Release</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
