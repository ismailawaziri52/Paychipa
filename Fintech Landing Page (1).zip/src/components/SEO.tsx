import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  type?: 'website' | 'article';
  author?: string;
  publishedTime?: string;
  keywords?: string;
}

export function SEO({
  title = 'Paychipa - The Future of Digital Banking in Nigeria',
  description = 'Paychipa is launching in 2025! Get free POS terminals, virtual & physical cards, instant transfers, bill payments, high-interest savings up to 15%, loans, and escrow services. Powered by Stripe and Flutterwave. Join the waitlist today!',
  image = 'https://paychipa.com/og-image.png',
  type = 'website',
  author,
  publishedTime,
  keywords = 'paychipa, digital banking nigeria, pos terminal nigeria, virtual card nigeria, savings account nigeria, mobile banking, fintech nigeria, instant transfer, bill payment, loans nigeria, escrow nigeria, flutterwave, stripe'
}: SEOProps) {
  const location = useLocation();
  const url = `https://paychipa.com${location.pathname}`;

  useEffect(() => {
    // Update document title
    document.title = title;

    // Update or create meta tags
    const updateMetaTag = (name: string, content: string, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      element.content = content;
    };

    // Basic meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords);
    updateMetaTag('author', 'Paychipa Technologies Limited');

    // Open Graph (Facebook, LinkedIn, WhatsApp)
    updateMetaTag('og:title', title, true);
    updateMetaTag('og:description', description, true);
    updateMetaTag('og:image', image, true);
    updateMetaTag('og:url', url, true);
    updateMetaTag('og:type', type, true);
    updateMetaTag('og:site_name', 'Paychipa', true);
    updateMetaTag('og:locale', 'en_NG', true);

    // Twitter Card
    updateMetaTag('twitter:card', 'summary_large_image');
    updateMetaTag('twitter:site', '@paychipa');
    updateMetaTag('twitter:creator', '@paychipa');
    updateMetaTag('twitter:title', title);
    updateMetaTag('twitter:description', description);
    updateMetaTag('twitter:image', image);

    // Article specific
    if (type === 'article' && author) {
      updateMetaTag('article:author', author, true);
    }
    if (type === 'article' && publishedTime) {
      updateMetaTag('article:published_time', publishedTime, true);
    }

    // Additional SEO
    updateMetaTag('robots', 'index, follow');
    updateMetaTag('googlebot', 'index, follow');
    updateMetaTag('theme-color', '#8b5cf6');

    // Canonical URL
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = url;

  }, [title, description, image, url, type, author, publishedTime, keywords]);

  // Add JSON-LD structured data
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'FinancialService',
      name: 'Paychipa',
      description: description,
      url: 'https://paychipa.com',
      logo: 'https://paychipa.com/logo.png',
      image: image,
      address: {
        '@type': 'PostalAddress',
        addressLocality: 'Abuja',
        addressCountry: 'NG'
      },
      sameAs: [
        'https://facebook.com/paychipa',
        'https://twitter.com/paychipa',
        'https://instagram.com/paychipa',
        'https://linkedin.com/company/paychipa'
      ],
      contactPoint: {
        '@type': 'ContactPoint',
        telephone: '+234-901-234-5678',
        contactType: 'Customer Service',
        email: 'hello@paychipa.com',
        areaServed: 'NG',
        availableLanguage: 'en'
      },
      aggregateRating: type === 'website' ? {
        '@type': 'AggregateRating',
        ratingValue: '4.8',
        reviewCount: '1250'
      } : undefined,
      offers: type === 'website' ? {
        '@type': 'Offer',
        description: 'Digital banking services including POS terminals, cards, savings, loans, and escrow',
        availability: 'https://schema.org/ComingSoon',
        availabilityStarts: '2025-01-01'
      } : undefined
    });
    
    // Remove old script if exists
    const oldScript = document.querySelector('script[type="application/ld+json"]');
    if (oldScript) {
      oldScript.remove();
    }
    
    document.head.appendChild(script);

    return () => {
      script.remove();
    };
  }, [description, image, type]);

  return null;
}
