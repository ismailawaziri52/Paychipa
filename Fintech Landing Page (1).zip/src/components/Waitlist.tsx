import { useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { CheckCircle2, Mail, User, Phone, Briefcase, Sparkles, X, Gift, Zap, Star } from "lucide-react";
import { toast } from "sonner@2.0.3";
import * as VisuallyHidden from "@radix-ui/react-visually-hidden";
import { projectId, publicAnonKey } from "../utils/supabase/info";

interface WaitlistProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function Waitlist({ open, onOpenChange }: WaitlistProps) {
  const [submitted, setSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    userType: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.fullName || !formData.email || !formData.phone || !formData.userType) {
      toast.error("Please fill in all fields");
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    // Phone validation (Nigerian format)
    const phoneRegex = /^(\+234|0)[789][01]\d{8}$/;
    if (!phoneRegex.test(formData.phone)) {
      toast.error("Please enter a valid Nigerian phone number");
      return;
    }

    setIsLoading(true);
    
    try {
      // Call Supabase backend to save waitlist entry
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-8addffcd/waitlist`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            email: formData.email,
            name: formData.fullName,
            phone: formData.phone,
            accountType: formData.userType
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to join waitlist');
      }

      if (data.alreadyExists) {
        toast.info(data.message);
      } else {
        toast.success(data.message);
      }

      setSubmitted(true);
    } catch (error) {
      console.error('Error joining waitlist:', error);
      toast.error(error.message || 'Failed to join waitlist. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        userType: "",
      });
    }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto p-0 gap-0 border-0 bg-white">
        {/* Accessibility titles - visually hidden */}
        <VisuallyHidden.Root>
          <DialogTitle>
            {submitted ? "Successfully Joined Waitlist" : "Join Paychipa Waitlist"}
          </DialogTitle>
          <DialogDescription>
            {submitted 
              ? "You have successfully joined the Paychipa waitlist. We will notify you when we launch."
              : "Sign up for early access to Paychipa. Fill out the form to join our exclusive waitlist and receive launch notifications."
            }
          </DialogDescription>
        </VisuallyHidden.Root>

        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute right-4 top-4 z-50 rounded-full p-2 bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 transition-all"
          aria-label="Close dialog"
        >
          <X className="h-4 w-4" />
        </button>

        {!submitted ? (
          <>
            {/* Header */}
            <div className="relative overflow-hidden bg-gradient-to-br from-[#2D1E36] via-purple-900 to-purple-950 px-8 py-12">
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl"></div>
              
              <div className="relative z-10 text-center space-y-4">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-sm text-white mb-2">
                  <Sparkles className="w-4 h-4 text-gray-300" />
                  <span>Limited Early Access Spots</span>
                </div>
                
                <h2 className="text-4xl text-white">
                  Join the Waitlist
                </h2>
                
                <p className="text-lg text-purple-100 max-w-md mx-auto">
                  Be among the first 10,000 Nigerians to experience the future of digital banking
                </p>
              </div>
            </div>

            {/* Form Section */}
            <div className="px-8 py-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Form Grid */}
                <div className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="fullName" className="text-sm text-gray-700">
                      Full Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="fullName"
                        placeholder="John Doe"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        className="pl-12 h-14 border-gray-200 focus:border-[#2D1E36] focus:ring-[#2D1E36] rounded-xl bg-gray-50 hover:bg-white transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm text-gray-700">
                      Email Address
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="pl-12 h-14 border-gray-200 focus:border-[#2D1E36] focus:ring-[#2D1E36] rounded-xl bg-gray-50 hover:bg-white transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-sm text-gray-700">
                      Phone Number
                    </Label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="08012345678"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="pl-12 h-14 border-gray-200 focus:border-[#2D1E36] focus:ring-[#2D1E36] rounded-xl bg-gray-50 hover:bg-white transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="userType" className="text-sm text-gray-700">
                      Account Type
                    </Label>
                    <div className="relative">
                      <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 z-10" />
                      <Select value={formData.userType} onValueChange={(value) => setFormData({ ...formData, userType: value })}>
                        <SelectTrigger className="pl-12 h-14 border-gray-200 focus:border-[#2D1E36] focus:ring-[#2D1E36] rounded-xl bg-gray-50 hover:bg-white transition-colors">
                          <SelectValue placeholder="Select account type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="individual">Individual User</SelectItem>
                          <SelectItem value="business">Business Owner</SelectItem>
                          <SelectItem value="freelancer">Freelancer</SelectItem>
                          <SelectItem value="student">Student</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Benefits Section */}
                <div className="bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 rounded-2xl p-6 border border-purple-100">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                      <Gift className="w-4 h-4 text-white" />
                    </div>
                    <h4 className="text-[#2D1E36]">Early Access Benefits</h4>
                  </div>
                  
                  <div className="grid gap-3">
                    <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm rounded-xl p-3 border border-purple-100/50">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">Priority Access</p>
                        <p className="text-xs text-gray-600">Be the first to use Paychipa when we launch</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm rounded-xl p-3 border border-purple-100/50">
                      <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Star className="w-4 h-4 text-yellow-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">₦1,000 Welcome Bonus</p>
                        <p className="text-xs text-gray-600">Free cash added to your account at launch</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm rounded-xl p-3 border border-purple-100/50">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Zap className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">Free POS Terminal</p>
                        <p className="text-xs text-gray-600">For first 500 businesses (worth ₦50,000)</p>
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full h-14 bg-gradient-to-r from-[#2D1E36] to-purple-900 hover:from-[#1F1426] hover:to-purple-950 text-white rounded-xl shadow-lg shadow-[#2D1E36]/30 transition-all hover:shadow-xl hover:shadow-[#2D1E36]/40"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Joining...</span>
                    </div>
                  ) : (
                    "Join the Waitlist"
                  )}
                </Button>

                <p className="text-xs text-center text-gray-500 leading-relaxed">
                  By joining, you agree to receive updates about Paychipa. Unsubscribe anytime. We respect your privacy.
                </p>
              </form>
            </div>
          </>
        ) : (
          // Success State
          <div className="px-8 py-12">
            <div className="text-center space-y-6">
              {/* Success Icon */}
              <div className="relative mx-auto w-24 h-24">
                <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full animate-pulse"></div>
                <div className="relative w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-xl">
                  <CheckCircle2 className="w-12 h-12 text-white" />
                </div>
              </div>
              
              {/* Success Message */}
              <div className="space-y-3">
                <h3 className="text-3xl text-[#2D1E36]">
                  You're In! 🎉
                </h3>
                <p className="text-lg text-gray-600 max-w-md mx-auto">
                  Welcome to Paychipa's exclusive early access list. We'll notify you at{" "}
                  <span className="text-[#2D1E36]">{formData.email}</span> when we launch.
                </p>
              </div>

              {/* Next Steps */}
              <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 text-left border border-purple-100">
                <h4 className="text-[#2D1E36] mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  What happens next?
                </h4>
                <div className="space-y-3">
                  <div className="flex gap-3">
                    <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-sm">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">Check your email</p>
                      <p className="text-xs text-gray-600 mt-0.5">We've sent you a confirmation email</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-sm">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">Share with friends</p>
                      <p className="text-xs text-gray-600 mt-0.5">Move up the list by inviting others</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-sm">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">Get ready for 2026</p>
                      <p className="text-xs text-gray-600 mt-0.5">We'll keep you updated on our progress</p>
                    </div>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleClose}
                className="w-full h-14 bg-gradient-to-r from-[#2D1E36] to-purple-900 hover:from-[#1F1426] hover:to-purple-950 text-white rounded-xl shadow-lg"
              >
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
